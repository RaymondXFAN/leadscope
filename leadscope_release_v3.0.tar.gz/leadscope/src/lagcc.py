#!/usr/bin/env python3
"""
lagcc.py v1.1 — Lagged Cross-Correlation 弱监督信号生成器 (LeadScope-Net 核心)

科学假设: 双人舞/双人交互中, follower 的运动是 leader 运动的时滞复制。
         对两人信号做滞后互相关, 使相关系数最大的滞后量 τ* 即为"领导-跟随"时滞:
             τ* = argmax_τ corr(A[t], B[t+τ])
         τ* > 0  → B 滞后于 A → A 是 leader
         τ* < 0  → A 滞后于 B → B 是 leader
         |τ*| ≈ 0 → 无明确主从关系(同步/独立)

v1.1 变更:
  - role_lag 支持任意 2D 输入 (T, D), 不再依赖 (T, J, 3) 的通道排序假设
    (适配 Bigand 数据集: 通道为 [舞者A的N通道 | 舞者B的N通道], 排序未知)
  - 新增 role_lag_detail(): 返回 (滞后量, 峰值相关系数, 通道一致性, 相关曲线)
  - 新增 consensus 指标: 各通道独立估计与主估计一致的比例 (衡量信号质量)
  - 默认对速度信号(一阶差分)做相关, 抑制位置信号的低频漂移

错误标记约定 (调用方捕获后回传):
  [LAGCC-ERR-01] 输入长度不足 (< 2*max_lag + 4)
  [LAGCC-ERR-02] 信号为常数 (std≈0), 相关系数无定义
"""

import numpy as np

__all__ = [
    "lagged_cross_corr", "role_lag", "role_lag_detail", "batch_role_lag",
    "normalize_segment", "velocity_energy",
]


def _as2d(x):
    """统一为 (T, D) 二维数组: (T,J,3) 自动摊平为 (T, J*3)"""
    a = np.asarray(x, dtype=np.float64)
    if a.ndim == 1:
        a = a[:, None]
    elif a.ndim == 3:
        a = a.reshape(a.shape[0], -1)
    elif a.ndim > 3:
        raise ValueError(f"[LAGCC-ERR-01] 不支持的输入维度: {a.ndim}")
    return a


def lagged_cross_corr(x, y, max_lag=10):
    """
    一维信号的滞后互相关。

    参数
        x, y: 一维序列, 等长
        max_lag: 最大滞后帧数 (搜索范围 [-max_lag, +max_lag])

    返回
        lags:  滞后量数组
        corrs: 对应相关系数
        best:  使相关系数最大的滞后量 (int)
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    y = np.asarray(y, dtype=np.float64).ravel()
    if x.size != y.size:
        raise ValueError(f"[LAGCC-ERR-01] 长度不等: {x.size} vs {y.size}")
    T = x.size
    if T < 2 * max_lag + 4:
        raise ValueError(f"[LAGCC-ERR-01] 序列过短: T={T}, 需要 >= {2 * max_lag + 4}")

    lags = np.arange(-max_lag, max_lag + 1)
    corrs = np.full(lags.size, np.nan)
    for i, L in enumerate(lags):
        if L >= 0:
            a, b = x[: T - L], y[L:]
        else:
            a, b = x[-L:], y[: T + L]
        sa, sb = np.std(a), np.std(b)
        if sa < 1e-12 or sb < 1e-12:
            corrs[i] = np.nan          # 常数信号, 相关无定义
            continue
        corrs[i] = float(np.corrcoef(a, b)[0, 1])
    if np.all(np.isnan(corrs)):
        raise ValueError("[LAGCC-ERR-02] 信号为常数或全 NaN, 相关系数无定义")
    best = int(lags[int(np.nanargmax(corrs))])
    return lags, corrs, best


def role_lag_detail(segA, segB, max_lag=10, use_velocity=True):
    """
    估计双人运动信号的领导-跟随时滞 (详细版)。

    参数
        segA, segB: (T, D) 或 (T, J, 3) 的两人信号, T 为时间轴
        max_lag:    最大滞后帧数
        use_velocity: True 时对一阶差分(速度)做相关, 抑制低频漂移

    返回
        lag:        最佳滞后量 (int), >0 表示 B 滞后于 A (A 为 leader)
        peak_r:     该滞后处的平均相关系数 (耦合强度, 0-1)
        consensus:  各通道独立估计与全局估计一致的比例 (0-1, 信号质量)
        lags:       滞后量数组
        curve:      平均相关曲线
    """
    A = _as2d(segA)
    B = _as2d(segB)
    if A.shape[0] != B.shape[0]:
        raise ValueError(f"[LAGCC-ERR-01] 时间长度不等: {A.shape[0]} vs {B.shape[0]}")
    if A.shape[1] != B.shape[1]:
        raise ValueError(f"[LAGCC-ERR-01] 通道数不等: {A.shape[1]} vs {B.shape[1]}")
    if use_velocity:
        A = np.diff(A, axis=0)
        B = np.diff(B, axis=0)

    D = A.shape[1]
    n_lag = 2 * max_lag + 1
    curves = np.full((n_lag, D), np.nan)
    per_ch_best = np.full(D, np.nan)
    for d in range(D):
        try:
            _, c, b = lagged_cross_corr(A[:, d], B[:, d], max_lag)
            curves[:, d] = c
            per_ch_best[d] = b
        except ValueError:
            continue                    # 该通道为常数, 跳过

    lags = np.arange(-max_lag, max_lag + 1)
    with np.errstate(invalid="ignore"):
        curve = np.nanmean(curves, axis=1)
    if np.all(np.isnan(curve)):
        raise ValueError("[LAGCC-ERR-02] 所有通道均为常数信号")
    best = int(lags[int(np.nanargmax(curve))])
    peak_r = float(np.nanmax(curve))
    valid = ~np.isnan(per_ch_best)
    consensus = float(np.mean(per_ch_best[valid] == best)) if valid.any() else 0.0
    return best, peak_r, consensus, lags, curve


def role_lag(segA, segB, max_lag=10, use_velocity=True):
    """
    简化接口 (兼容 v1.0): 返回 (滞后量, 各通道独立估计数组)
    """
    A = _as2d(segA)
    B = _as2d(segB)
    if use_velocity:
        A = np.diff(A, axis=0)
        B = np.diff(B, axis=0)
    D = A.shape[1]
    per_ch = np.full(D, np.nan)
    for d in range(D):
        try:
            per_ch[d] = lagged_cross_corr(A[:, d], B[:, d], max_lag)[2]
        except ValueError:
            continue
    try:
        best = role_lag_detail(segA, segB, max_lag, use_velocity)[0]
    except ValueError:
        best = 0
    return best, per_ch


def _one(args):
    segA, segB, max_lag, use_velocity = args
    try:
        lag, r, cons, _, _ = role_lag_detail(segA, segB, max_lag, use_velocity)
        return (lag, r, cons)
    except Exception:
        return (0, 0.0, 0.0)


def batch_role_lag(pairs, max_lag=10, use_velocity=True, n_jobs=-1, verbose=0):
    """
    批量并行估计多段双人信号的时滞。

    参数
        pairs: [(segA, segB), ...] 列表
        n_jobs: -1 表示用满所有 CPU 核 (虎博服务器 12-16 核)
    返回
        [(lag, peak_r, consensus), ...]
    """
    tasks = [(a, b, max_lag, use_velocity) for a, b in pairs]
    try:
        from joblib import Parallel, delayed
        return Parallel(n_jobs=n_jobs, verbose=verbose)(
            delayed(_one)(t) for t in tasks)
    except ImportError:
        return [_one(t) for t in tasks]


def normalize_segment(seg, eps=1e-8):
    """逐通道 z-score 归一化, 保持形状不变"""
    a = np.asarray(seg, dtype=np.float32)
    mean = a.mean(axis=0, keepdims=True)
    std = a.std(axis=0, keepdims=True)
    return (a - mean) / (std + eps)


def velocity_energy(seg):
    """逐帧运动能量: 所有关节速度模长之和, 返回 (T-1,)"""
    a = _as2d(seg)
    v = np.diff(a, axis=0)
    return np.sqrt((v ** 2).sum(axis=1)) if v.shape[1] % 3 else np.abs(v).sum(axis=1)
