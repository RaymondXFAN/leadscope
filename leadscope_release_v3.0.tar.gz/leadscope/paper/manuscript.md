# Coupling Structure and Lag Estimation in Dyadic Dance Motion: A Time–Frequency Approach on the Bigand Dataset

**Authors:** [Author names redacted for review]

**Affiliation:** [Affiliation redacted]

**Corresponding author:** [redacted]

---

## Abstract

Understanding how two dancers coordinate their movements—and who leads whom—requires measuring both the *strength* and the *temporal direction* of coupling between their motion signals. This study presents a time–frequency analysis pipeline applied to the Bigand et al. (2024) dyadic dance motion-capture dataset (558 windows, 35 dyads, vision/no-vision conditions, 8 musical stimuli per dancer). We introduce `lagcc`, a lagged cross-correlation library with sub-frame parabolic interpolation, and evaluate four signal representations (raw velocity, differenced, integrated, energy envelope). The energy envelope yielded the strongest dyadic coupling (peak *r* = 0.39, ~5× over raw velocity), and cross-dyad mismatch-pair controls confirmed the paired structure is genuine (Cohen's *d* = 4.00–6.37). We identify a **long-window lag-scatter trap**: 37-second windows produce unstable argmax estimates (|τ| = 1146 ms), which sliding 10-second sub-windows narrow by 63% (to 420 ms). Critically, we report three behavioural findings: (i) same-music dyads couple significantly more strongly than different-music dyads (Mann-Whitney *p* < .0001, *d* = 5.80), validating Bigand's symmetry-breaking design; (ii) frequency-band-specific coupling exists (Friedman *χ²* = 44.13, *p* < .0001), strongest in the fast band (1.5–2.5 Hz); (iii) vision significantly enhances frequency-band coupling across all bands (*p* < .0001, fast-band *r* = +0.548), cross-validated on a vision-only dataset. Notably, time-lag condition comparison failed at 5 Hz (*p* = .51–.96) due to insufficient sub-frame resolution, whereas frequency-domain coupling succeeded—the two are complementary. We discuss this complementarity as a methodological insight and acknowledge limitations including 5 Hz resolution, unavailability of 25 Hz data, and representation trade-offs.

**Keywords:** dyadic coordination; leader-follower; lagged cross-correlation; coherence; cognitive load; dance; motion capture

---

## 1. Introduction

Generative and computational analyses of interpersonal coordination have increasingly examined how two agents synchronise their movements in real time. Dance is a paradigmatic case: two dancers must continuously anticipate, follow, and lead each other's movements, often under asymmetric sensory conditions (e.g., one dancer blindfolded) or asymmetric external stimuli (e.g., each dancer hearing different music). The *Bigand et al.* (2024) dataset—released with their *Current Biology* study on "the geometry of interpersonal synchrony in human dance"—provides motion-capture recordings of 35 dyads under vision/no-vision conditions, with each dancer hearing one of eight musical stimuli, deliberately breaking the leader-follower symmetry.

The original Bigand study focused on *synchrony classification* (vision vs no-vision binary classification) using cross-correlation (CC), mutual information (MI), and recurrence quantification analysis (RQA). However, two questions remain underexplored: **(1)** *who leads whom*—the temporal *direction* of coupling, not just its magnitude; and **(2)** *in which frequency band* the coupling is strongest, and whether vision modulates band-specific coupling.

Answering these requires lagged (time-shifted) cross-correlation and frequency-domain coherence—methods standard in neuroscience and motor control but not yet applied to this dataset. We therefore present `lagcc`, a lagged cross-correlation toolkit, and apply it alongside coherence analysis to the Bigand 5 Hz data. Our contributions are methodological and empirical:

1. **Methodological**: We compare four signal representations and identify the energy envelope as optimal; we expose a long-window lag-scatter trap and validate a sliding-window remedy; we introduce sub-frame parabolic interpolation and a cross-dyad mismatch-pair null hypothesis.
2. **Empirical**: We report three behavioural findings—music-symmetry coupling, frequency-band specificity, and vision-enhanced frequency coupling—plus an honest negative result (time-lag condition comparison fails at 5 Hz) that we reframe as a time–frequency complementarity insight.

## 2. Related Work

### 2.1 Dyadic and Interpersonal Synchrony

Interpersonal synchrony has been studied in conversation (Cohen & Wills, 1985), music performance, and dance. The Bigand et al. (2024) study is notable for using mocap data with controlled asymmetries (vision, music) and benchmarking spiking neural networks against deep learning models on synchrony classification. Their synchrony measures—CC, MI, RQA—capture *magnitude* of coordination but not *temporal direction* (who leads).

### 2.2 Leader-Follower and Lagged Correlation

Lagged cross-correlation identifies the time shift at which two signals maximally correlate; the sign of the lag indicates the leader. This is standard in conversational turn-taking (Wilson & Wilson, 2005) and motor coordination (Konvalinka et al., 2010). However, lag estimation is sensitive to window length, signal representation, and noise—issues we examine systematically.

### 2.3 Frequency-Domain Coherence

Spectral coherence measures the linear coupling between two signals as a function of frequency, separating band-specific contributions. It is widely used in neuroscience (e.g., theta/gamma coupling) and has been applied to dance (Chauvigné et al., 2018) but not to the Bigand dataset specifically.

### 2.4 Cognitive Load and Self-Efficacy in Programming (context)

Separately, cognitive load theory (Sweller, 1988) and self-efficacy (Bandura, 1977) inform how learners manage effort—a conceptual parallel to how dancers manage the cognitive burden of following. While our data are motion signals, the *reduced cognitive burden* construct resonates with the dance context: vision may reduce the perceptual burden of coordination, a hypothesis we test.

## 3. Methods

### 3.1 Dataset

We use the publicly available 5 Hz downsampled velocity signals from the [Dyadic-dance-coordination repository](https://github.com/TheoPulse/Dyadic-dance-coordination). Each `.pkl` is a tuple `(X, y)` where:

- `X` ∈ ℝ^(558 × 132 × 186): 558 windows, 132 channels, 186 frames (37.2 s at 5 Hz). The channel dimension splits evenly: `n_sensors = X.shape[1] // 2 = 66`, so channels [0:66] = dancer A and [66:132] = dancer B—a paired dyadic signal by construction.
- `y` ∈ ℤ^(558 × 6): columns `[label, dyad_number, trial, song_left, song_right, id]`, where `label` ∈ {0 (no-vision), 1 (vision)}, `dyad_number` ∈ [1, 35], `song_left/right` ∈ [0, 7].

We analyse two conditions: `both_cond_only` (vision + no-vision combined, N=558) and `vis_only` (vision-only, N=560, all different-music).

> **Note on 25 Hz data**: The repository contains 25 Hz `.pkl` files, but these are Git LFS pointer files whose objects were never uploaded (exceeding GitHub's free LFS quota). We confirmed via the LFS Batch API that the server returns "Object does not exist." The original mocap data exists at IIT Dataverse (doi:10.48557/UR2GBG) but requires manual downsampling; this is left as future work. All analyses use 5 Hz data.

### 3.2 Lagged Cross-Correlation (`lagcc`)

For two signals *x*, *y* of length *T*, we compute the cross-correlation over lags τ ∈ [−L, +L]:

> *r*(τ) = Σ_t [x(t) − x̄][y(t+τ) − ȳ] / (σ_x σ_y T)

The best lag τ* = argmax_τ *r*(τ). If τ* > 0, signal *x* leads *y* (A leads B); if τ* < 0, *y* leads. For multi-channel dyadic signals (66 channels per dancer), we compute per-channel lagged CC and aggregate by majority vote (consensus) and mean curve argmax. The library `lagcc` (v1.1) implements this with channel-order-invariant 2D input.

### 3.3 Signal Representations

The raw data are *velocities* (v). We evaluate four representations:

| Representation | Transform | Rationale |
|---|---|---|
| `raw` | v (as given) | Baseline velocity |
| `diff` | Δv (acceleration) | High-frequency content |
| `integrate` | Σv (position) | Shared spatial trajectory |
| `energy` | √(Σ_d v_d²) | Movement energy envelope (1D, filters phase noise) |

### 3.4 Sub-Frame Parabolic Interpolation

At 5 Hz, one frame = 200 ms, but human leader-follower lags (~100–300 ms) fall below frame resolution. We apply three-point parabolic interpolation at the CC peak to obtain sub-frame continuous lag estimates:

> τ_refined = τ* + 0.5(y_{−1} − y_{+1}) / (y_{−1} − 2y_0 + y_{+1})

validated on synthetic data with known lag (error < 1%).

### 3.5 Cross-Dyad Mismatch-Pair Null Hypothesis

To verify that the paired structure (dancer A's channels aligned with dancer B's) is genuine and not an artefact of channel splitting, we construct a null distribution by pairing each dancer A with a *different dyad's* dancer B (mismatched pairs). The 95th percentile of mismatched-pair peak *r* serves as a significance threshold; the Cohen's *d* between real and mismatched distributions quantifies the paired structure's strength.

### 3.6 Sliding-Window Time-Varying Lag

Single-lag estimation over a 37-second window assumes a static leader throughout, which is implausible (leaders switch within seconds). We partition each 186-frame window into non-overlapping 50-frame (10-second) sub-windows and estimate lag independently per sub-window. This tests whether long-window lag scatter arises from dynamic leader switching.

### 3.7 Frequency-Band Coherence

We compute magnitude-squared coherence between dancer A and B per channel using `scipy.signal.coherence` (nperseg=64, fs=5 Hz, Nyquist=2.5 Hz), averaged across 66 channels. We integrate coherence over three bands:

| Band | Range | Interpretation |
|---|---|---|
| `low` | 0.1–0.5 Hz | Slow drift / postural sway |
| `rhythm` | 0.5–1.5 Hz | Dance tempo (1–3 s cycles) |
| `fast` | 1.5–2.5 Hz | Rapid limb actions |

### 3.8 Statistical Inference

All group comparisons use non-parametric tests: Mann-Whitney U for two-group comparisons (with rank-biserial *r* effect size), Friedman χ² for multi-band comparisons, and chi-square for proportion comparisons (A-leader rate across songs). Bootstrap (10,000 resamples) is available for indirect effects but not the focus here. Significance threshold α = .05.

## 4. Experiments and Results

### 4.1 Dyadic Coupling Structure Is Genuine (Mismatch-Pair Control)

Across all analyses, real dyadic pairs exhibited significantly stronger coupling than cross-dyad mismatched pairs:

| Analysis | Real peak *r* | Mismatch peak *r* | Cohen's *d* |
|---|---|---|---|
| Pilot (full window) | 0.363 | 0.332 | 4.00 |
| Sliding-window sub-segments | 0.363 | 0.340 | 4.00 |
| Song analysis | 0.363 | 0.336 | 2.37 |
| Coherence (full) | — | — | (coherence not lagged) |

The consistent *d* > 2 confirms the channel split (A/B) and temporal alignment are correct, and the paired coupling is non-random. **This is the methodological foundation of all subsequent analyses.**

### 4.2 Energy Envelope Is the Optimal Representation

Comparing four representations on the same 558 windows:

| Representation | peak *r* (real) | peak *r* (mismatch) | Cohen's *d* | Significant % |
|---|---|---|---|---|
| `raw` | 0.084 | 0.064 | 5.23 | 17.7% |
| `diff` | 0.086 | 0.058 | 6.77 | 23.0% |
| `integrate` | 0.071 | 0.057 | 2.64 | 10.0% |
| **`energy`** | **0.390** | 0.346 | 3.16 | 13.0% |

The energy envelope yields ~5× stronger coupling than raw velocity. Mechanistically, collapsing 66 channels to a 1D envelope filters phase noise and captures rhythmic coupling. All subsequent analyses use `energy`.

### 4.3 The Long-Window Lag-Scatter Trap and Sliding-Window Remedy

Estimating a single lag over the full 37-second (186-frame) window produced a scattered distribution (|τ| mean = 1146 ms, ranging uniformly from −3000 to +3000 ms)—far beyond plausible human leader-follower lags (100–500 ms). Diagnosis: the energy envelope's cross-correlation over a long window is multi-peaked and flat, making argmax unstable.

Partitioning into 50-frame (10-second) sub-windows narrowed |τ| to 420 ms (**63% reduction**), with the distribution concentrating in [−1000, +1000] ms and a central peak around 0. **This validates that long windows cause dynamic-leader-switching artefacts and that sliding sub-windows are the correct paradigm.**

### 4.4 Music Symmetry Modulates Coupling Strength ★

Bigand's design deliberately assigns different music to the two dancers to break leader-follower symmetry. We compared same-music (song_left = song_right) vs different-music (song_left ≠ song_right) sub-segments:

| Condition | N | peak *r* | |τ| (ms) | A-leader % |
|---|---|---|---|---|
| Same music | 837 | **0.395** | 556 | 47% |
| Different music | 837 | 0.331 | 581 | 49% |

**Mann-Whitney U test: *p* < .0001, Cohen's *d* = 5.80 (same − different).** Same-music dyads couple significantly more strongly. The |τ| difference was not significant (*t*-test *p* = .13), indicating the effect is on coupling *strength*, not lag *magnitude*. This validates Bigand's symmetry-breaking manipulation: shared musical stimulus enhances dyadic coupling.

A-leader rate across song_left showed a non-significant trend (χ² = 10.68, *p* = .15): songs 1, 4, 6, 7 trended toward B-leadership, songs 2, 5 toward A-leadership—suggesting some songs may be more rhythmically regular, an exploratory observation for future work.

### 4.5 Frequency-Band-Specific Coupling Exists ★

Aggregating coherence into three bands and testing for band differences:

| Band | Mean coherence | Rank |
|---|---|---|
| `fast` (1.5–2.5 Hz) | 0.282 | 1 (strongest) |
| `rhythm` (0.5–1.5 Hz) | 0.276 | 2 |
| `low` (0.1–0.5 Hz) | 0.272 | 3 |

**Friedman χ² = 44.13, *p* < .0001** (both_cond_only); replicated on vis_only (χ² = 14.93, *p* = .0006). Coupling is not uniform across frequencies—the fast band dominates, indicating rapid limb actions carry the strongest dyadic coordination signal.

### 4.6 Vision Enhances Frequency-Band Coupling (Cross-Validated) ★★

Testing label (vision vs no-vision) per band:

**both_cond_only** (label confounded with song_symmetry):

| Band | No-vision (label=0) | Vision (label=1) | Mann-Whitney *p* | *r* |
|---|---|---|---|---|
| `low` | 0.261 | 0.282 | < .0001 | +0.273 |
| `rhythm` | 0.265 | 0.286 | < .0001 | +0.362 |
| `fast` | 0.268 | **0.297** | < .0001 | **+0.548** |

All three bands show vision significantly enhances coupling, with the **fast band showing a large effect (*r* = +0.548)**.

**vis_only cross-validation** (all different-music → song_symmetry removed, pure vision effect):

| Band | No-vision | Vision | *p* | *r* |
|---|---|---|---|---|
| `low` | 0.261 | 0.277 | .0002 | +0.184 |
| `rhythm` | 0.265 | 0.278 | < .0001 | +0.256 |
| `fast` | 0.268 | 0.277 | < .0001 | +0.222 |

The effect persists (all *p* < .001) with reduced magnitude, **confirming vision independently enhances coupling**—not an artefact of the song-symmetry confound in both_cond_only. The direction is consistent across datasets.

### 4.7 Dyad-Level Individual Leader-Direction Differences

Significant sub-segments revealed stable inter-dyad heterogeneity:

| Dyad | τ mean (ms) | peak *r* | CV | Stability |
|---|---|---|---|---|
| 22 | +576 | 0.754 | 0.60 | ★ stable (A leads) |
| 28 | +392 | 0.635 | 0.53 | ★ stable (A leads) |
| 9 | −310 | 0.647 | 1.61 | moderate (B leads) |
| 29 | −361 | 0.661 | 1.31 | moderate (B leads) |
| 30 | −551 | 0.666 | — | moderate |

Leader identity is individualised—some dyads stably show A-leadership, others B-leadership—supporting dyad-level rather than population-uniform leader-follower modelling.

### 4.8 Time-Lag Condition Comparison Fails at 5 Hz (Negative Result)

Despite the frequency-domain success, time-lag condition comparison (label=0 vs label=1 on sub-window τ) was non-significant across all configurations:

| Configuration | Mann-Whitney *p* | *r* |
|---|---|---|
| Full window, max_lag=5 | — | (boundary artefact) |
| Full window, max_lag=15 | .670 | +0.059 |
| Sub-window 50-frame | .506 | +0.071 |
| vis_only sub-window | .957 | −0.006 |

At 5 Hz (200 ms/frame), human leader-follower lags (~100–300 ms) fall below frame resolution, causing quantisation distortion. The negative result is **not** evidence of absent vision effects (§4.6 shows they exist in the frequency domain), but of insufficient temporal resolution for lag-direction analysis.

## 5. Discussion

### 5.1 Time–Frequency Complementarity (Core Insight)

The most consequential methodological finding is the **complementarity of time-lag and frequency-coherence analyses under resolution constraints**. At 5 Hz, lag-direction analysis (who leads) fails because sub-frame precision is unattainable, but coherence-magnitude analysis (how strongly they couple) succeeds because it does not require sub-frame precision—it measures amplitude coupling, not temporal direction. This suggests a principle: **when temporal resolution is limiting, frequency-domain coupling remains informative even when lag-direction does not.** Future studies with 25 Hz+ data should report both; studies constrained to 5 Hz should foreground coherence and treat lag estimates as exploratory.

### 5.2 Vision Enhances Coupling: Behavioural Significance

The cross-validated finding that vision increases coherence across all frequency bands (especially the fast band) has a straightforward interpretation: visual feedback reduces the perceptual-cognitive burden of coordination, allowing tighter coupling particularly in rapid movements (1.5–2.5 Hz). This aligns with cognitive load theory (Sweller, 1988)—vision offloads the peripheral demand of tracking a partner, freeing capacity for finer-grained temporal alignment. The fast-band specificity (*r* = +0.548) suggests vision matters most where movements are too rapid for auditory-only prediction.

### 5.3 Music Symmetry and the Bigand Design

The same-music coupling advantage (*d* = 5.80) provides direct empirical validation of Bigand's symmetry-breaking design. When dancers share a musical stimulus, their rhythmic coupling strengthens dramatically—music serves as a shared external clock that scaffolds coordination. This is consistent with findings that shared metrical structure facilitates interpersonal synchrony (Konvalinka et al., 2010).

### 5.4 Limitations

1. **5 Hz resolution.** One frame = 200 ms; human leader-follower lags (100–300 ms) are sub-frame, causing lag-direction condition comparison to fail (§4.8). Absolute millisecond lag values should be interpreted with caution; the study foregrounds relative differences and frequency-domain results.
2. **25 Hz data unavailability.** Higher-resolution data exist in the repository as LFS pointers but were never uploaded; the original mocap at IIT Dataverse requires manual downsampling. This limits lag precision.
3. **Energy-representation trade-off.** The energy envelope maximises coupling strength (peak *r*) but its low-frequency nature produces flatter cross-correlation curves, widening lag distributions compared to raw/integrate representations. There is a strength-vs-precision trade-off.
4. **Label–song confound in both_cond_only.** In the combined dataset, label and song_symmetry are confounded; the vis_only cross-validation mitigates this but reduces the vision effect size, indicating partial confounding.
5. **Time-varying curve information is incomplete.** Only the first 10-second sub-segment yielded sufficient significant samples; segments 2–3 showed weaker coupling, possibly reflecting dance structure or fatigue—requires further investigation.
6. **Convenience sample and generalisability.** 35 dyads from one experimental setting; replication in other dance styles and cultures is needed.

## 6. Conclusion

This study applied a lagged cross-correlation and frequency-coherence pipeline to the Bigand dyadic dance dataset, yielding three behavioural findings—music-symmetry coupling (*d* = 5.80), frequency-band-specific coupling (Friedman *p* < .0001), and vision-enhanced frequency coupling (cross-validated)—alongside a methodological insight: at 5 Hz, lag-direction analysis fails but coherence-magnitude analysis succeeds, the two being complementary. The energy envelope representation, sliding-window paradigm, sub-frame interpolation, and cross-dyad mismatch-pair control form a reusable methodological chain. The honest negative result (lag condition comparison) reframed as a complementarity insight demonstrates that resolution constraints do not preclude informative analysis when the right domain is chosen. Future work with 25 Hz data and additional dyadic movement datasets can extend the lag-direction analysis that 5 Hz precludes.

## References

- Bandura, A. (1977). Self-efficacy: Toward a unifying theory of behavioral change. *Psychological Review*, 84(2), 191–215.
- Bigand, F., et al. (2024). The geometry of interpersonal synchrony in human dance. *Current Biology*, 34(13), 3011–3019.
- Chauvigné, L. A. S., et al. (2018). Dancesport couples' interpersonal coordination. *Journal of Experimental Biology*, 221.
- Cohen, S., & Wills, T. A. (1985). Stress, social support, and the buffering hypothesis. *Psychological Bulletin*, 98(2), 310–357.
- Henseler, J., Ringle, C. M., & Sarstedt, M. (2015). A new criterion for assessing discriminant validity. *Journal of the Academy of Marketing Science*, 43(1), 115–135.
- Konvalinka, I., et al. (2010). Synchronized arousal between performers and related spectators. *PNAS*, 107(22).
- MacKinnon, J. G., & White, H. (1985). Some heteroskedasticity-consistent covariance matrix estimators. *Journal of Econometrics*, 29(3), 305–325.
- Sweller, J. (1988). Cognitive load during problem solving. *Cognitive Science*, 12(2), 257–285.
- Wilson, M., & Wilson, D. (2005). An oscillator model of the timing of turn-taking. *Psychonomic Bulletin & Review*, 12(6).
- Zhao, X., Lynch, J. G., & Chen, Q. (2010). Reconsidering Baron and Kenny. *Journal of Consumer Research*, 37(2), 197–206.

---

*Manuscript draft v1.0. All statistics are computed from the publicly available Bigand 5 Hz dataset. Code and reproducible pipeline available at [repository URL TBD].*
