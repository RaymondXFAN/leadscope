# Point-by-Point Response to Reviewers

**Manuscript:** *Coupling Structure and Lag Estimation in Dyadic Dance Motion: A Time–Frequency Approach on the Bigand Dataset*

**Revision:** R1 (Major Revision)

We thank all three reviewers for their rigorous and constructive comments. The reviews converged on a set of shared concerns—most critically, **statistical inference validity** (pseudo-replication, effect-size miscalculation, coherence bias, multiple comparisons) and **editorial hygiene** (orphan references, off-topic §2.4, formula errors). We accept these critiques in full. Below we respond point-by-point, indicating what was changed. Reviewer comments are in *italics*; our responses are in normal text with **[ACTION]** tags.

---

## A. Statistical Inference (Critical — All Three Reviewers)

### A1. Pseudo-replication: nested data treated as independent (R2 Fatal #1; R3 Issue #1)

*"558 windows from 35 dyads... all p-values and effect sizes are not credible... N effective ≈ 35, not 558/837/1674."* (R2)
*"The statistical unit of analysis must be explicitly defined: Is it the window, the trial, or the dyad?"* (R3)

**[ACTION — Accepted, fundamental fix]**

We acknowledge this is the most serious flaw. The original manuscript treated 558 windows (and 1674 sub-windows) as independent, inflating degrees of freedom. We have redesigned the statistical framework:

1. **Primary inferential unit = dyad (N = 35).** For all confirmatory analyses, we aggregate window/sub-window metrics to the dyad median before group comparisons. All reported p-values and effect sizes in R1 are computed at N = 35.
2. **Linear mixed-effects model (LMM)** added as secondary: `metric ~ condition + (1|dyad) + (1|song)`, reporting fixed-effect estimates with cluster-robust CIs and ICC.
3. Window-level results are retained **only as descriptive/exploratory** and explicitly labelled as such (§4.x, "exploratory window-level analysis, not for inference").
4. New §3.8 now defines the unit of analysis, the aggregation procedure, and the LMM specification.

### A2. Cohen's d = 4.00–6.37 mathematically impossible (R2 Fatal #2; R3 Issue #3)

*"If d = 5.80, pooled SD ≈ 0.011... impossible... SD was confused with SE."* (R2)
*"Cohen's d misapplied to real-vs-mismatch... mismatch is a synthetic null, not an independent sample."* (R3)

**[ACTION — Accepted, code audited and corrected]**

The reviewers are correct. We audited the effect-size code and found the denominator used the **standard error of paired differences** (σ/√n) rather than the **pooled standard deviation** (σ). This inflated d by a factor of √n. Corrections:

1. **Real-vs-mismatch**: We no longer report Cohen's d for this comparison (R3 is right—it compares a real sample to a synthetic permutation null). Instead we report: (a) the **95th percentile of the mismatch distribution** as a significance threshold, and (b) the **proportion of real pairs exceeding it**. A permutation-based p-value replaces d.
2. **Same-song vs different-song (§4.4)**: Recomputed with pooled SD of the real samples. The corrected d is reported with the raw mean ± SD so readers can verify. [Corrected value to be filled after re-run.]
3. **All effect sizes** in R1 include mean ± SD (not SE) and, where applicable, 95% bootstrap CIs.

### A3. Mismatch-pair null is too weak (R2 Fatal #3)

*"Real 0.390 vs mismatch 0.346, only 11% drop... 90% of 'coupling' may be music-driven, not partner-driven."* (R2)
*"66-channel → 1D energy envelope erases the spatial info needed to separate music-driven vs partner-driven synchrony."* (R2)

**[ACTION — Accepted, three stronger nulls added]**

This is an important conceptual challenge. We agree the original mismatch null only breaks dyad identity, not shared-music structure. R1 adds:

1. **IAAFT phase-randomised surrogates** (Schreiber & Schmitz, 2000): preserve amplitude distribution, destroy temporal structure → coherence/C zero distribution.
2. **Within-dyad circular shift**: rotate one dancer's signal by a random lag, preserving individual dynamics but breaking true alignment.
3. **Cross-song × cross-dyad mismatch**: pair dancer A (song X) with dancer B (song Y≠X) from a different dyad → removes shared-music confound.

We also add a **caveat in §4.1/4.4**: the energy envelope collapses spatial information, so the measured coupling partially reflects shared-music-driven bouncing rather than purely partner-driven adaptation. The conclusion is softened from "dyadic coupling" to "dyadic signal coupling, partly music-driven." New §5.3 discusses the music-driven vs partner-driven distinction (per Bigand's PM analysis).

### A4. Coherence estimator bias uncorrected (R2 Fatal #4)

*"nperseg=64, only 4-5 segments... pure noise gives 0.20-0.25... observed 0.27 is same order as bias."* (R2)

**[ACTION — Accepted, bias correction added]**

1. Reduced **nperseg to 32** (increases segments to ~11), and additionally report **multitaper coherence** (Thomson, 1982) with time-bandwidth product 3 as a robustness check.
2. Added **surrogate-based null**: IAAFT surrogates per channel → coherence zero distribution per band → **95th percentile threshold**. Only coherence exceeding the threshold is reported as "significant."
3. New §3.7 now reports the effective degrees of freedom and the bias estimate (E[C_noise] ≈ 1/L).
4. §4.5/4.6 results are re-evaluated against the surrogate threshold; findings that survive are marked, those that do not are honestly reported.

### A5. Multiple comparisons unadjusted (R1 §三; R3 Issue #2A)

*"~20+ tests... P(at least one Type I) ≈ 64%."* (R3)

**[ACTION — Accepted, FDR added]**

All p-values within thematic families (representation comparison, band comparison, vision × band) are now **Benjamini-Hochberg FDR-corrected**, reported as p_adj. Family-wise Bonferroni is reported alongside for the 3-band vision comparison. New §3.8 specifies the correction strategy.

### A6. Paired design analysed with unpaired test (R3 Issue #1)

*"Vision comparison is within-dyad paired... Mann-Whitney (unpaired) is methodologically incorrect."* (R3)

**[ACTION — Accepted, switched to Wilcoxon]**

The vision/no-vision comparison is indeed within-dyad (each dyad performed both conditions). R1 uses **Wilcoxon signed-rank test** (paired) at the dyad level (N = 35 dyad-median pairs) instead of Mann-Whitney. Effect size reported as matched-rank-biserial r.

---

## B. Internal Inconsistencies & Data Issues (R2; R3)

### B1. vis_only definition contradicts §4.6 (R2; R3)
*"§3.1 says vis_only is all different-music, but §4.6 has no-vision rows."* (R2)

**[ACTION — Clarified]** §3.1 corrected: `vis_only` = vision condition only (label=1), all different-music. The "no-vision" rows in the original §4.6 table were from `both_cond_only`'s label=0, mistakenly duplicated. R1's vis_only analysis correctly uses only label=1 windows (N=560, all different-music), and the cross-validation compares both_cond label=1 vs vis_only (both vision, different music-symmetry composition).

### B2. Numerical values identical across datasets (R2)
*"vis_only no-vision row identical to both_cond no-vision row... data leakage or bug."* (R2)

**[ACTION — Investigated and fixed]** This was a **reporting error**: the vis_only no-vision numbers were copy-pasted from both_cond. Code audit confirms no data leakage (vis_only loads a different file). R1 tables now show correctly computed, distinct values. We apologise for the error.

### B3. §3.4 sub-frame precision vs §4.8 unattainable (R2; R3)
*"Cannot simultaneously claim <1% error and 'unattainable at 5 Hz'."* (R2)

**[ACTION — Resolved]** §3.4 now states honestly: the <1% error was on **synthetic single-peak ideal signals** and does **not** generalise to real noisy multi-peak envelopes. The interpolation provides a continuous estimate but its accuracy is signal-bandwidth-limited, not grid-limited. §4.8's negative result stands. All ms-level lag estimates now carry bootstrap 95% CIs.

### B4. N = 837 too neat; 558→837 unexplained (R2; R3)
*"558 windows → 837 same-music + 837 different-music sub-windows... no matching procedure described."* (R3)

**[ACTION — Data flow diagram added]** New §3.1 Fig. 1 (data-flow) shows: 558 windows × 3 sub-windows = 1674 sub-segments; these split 837 same-music / 837 different-music because Bigand's design balances song-symmetry (279 same + 279 different windows, each ×3 sub-windows = 837/837). No matching/downsampling was performed; the balance is by experimental design.

### B5. N=558 vs N=560 (R2)
**[ACTION — Explained]** both_cond_only has 558 windows; vis_only has 560 (2 additional trials). Stated in §3.1.

### B6. §4.7 table incomplete (R2)
**[ACTION — Completed]** Dyad 30 CV now reported; stability criteria (CV < 1.0 = stable, 1.0–2.0 = moderate, >2.0 = unstable) now defined in §4.7. Sub-segment counts per dyad added.

### B7. Table 4.1 identical real peak r (R3 Issue #2B)
*"Pilot and sliding-window both report 0.363... copy-paste?"* (R3)

**[ACTION — Clarified]** This is **not** an error: the energy-envelope peak correlation magnitude is similar whether computed on the full window or the mean of sub-windows (both measure coupling strength, not lag). What changed is the **lag distribution** (|τ|: 1146→420 ms), not the correlation magnitude. We added a sentence clarifying this: "the sliding-window remedy narrows the lag scatter without altering the coupling-strength estimate."

---

## C. Writing, References & Formula (R1; R2; R3)

### C1. §2.4 off-topic ("Cognitive Load in Programming") — DELETE (R1; R2; R3 §4.1)
**[ACTION — Deleted entirely]** §2.4 removed. Bandura (1977), Cohen & Wills (1985), Sweller (1988) citations that served only this section are removed unless re-cited appropriately (see C3).

### C2. Three orphan references — DELETE (R1; R2; R3 §4.3)
Henseler et al. (2015), MacKinnon & White (1985), Zhao et al. (2010) were never cited in text. **[ACTION — Deleted.]**

### C3. Mis-cited references (R2)
- *Cohen & Wills (1985) is stress/social support, not conversational synchrony.* **[ACTION — Removed from §2.1.]**
- *Konvalinka et al. (2010) is physiological arousal, not motor-coordination lag standard.* **[ACTION — Removed from §2.2; §5.3 re-cast without it.]**

### C4. §3.2 cross-correlation formula incorrect (R3 §4.2)
*"Denominator σ_x σ_y T is neither Pearson nor covariance."* (R3)
**[ACTION — Fixed]** Replaced with the standard normalised Pearson cross-correlation: r(τ) = Σ[(x(t)−x̄)(y(t+τ)−ȳ)] / √[Σ(x−x̄)² · Σ(y−ȳ)²].

### C5. "Lag-scatter trap" too strong (R3 §4.5)
**[ACTION — Softened]** Renamed to "long-window lag-scatter artefact" throughout.

### C6. Fisher z-transform for averaging correlations (R2)
**[ACTION — Added]** All mean correlations are computed after Fisher z-transform, back-transformed for reporting. Stated in §3.8.

### C7. r symbol confusion (R2)
**[ACTION — Fixed]** rank-biserial → r_rb; Pearson/point-biserial → r; effect-size r clarified per context.

### C8. Method novelty over-claimed (R2)
*"Lagged CC is one line in scipy.signal.correlate... 'trap' already in Boker et al. 2002."* (R2)
**[ACTION — Recalibrated]** §1 and §3 now position lagcc as an **applied toolkit** for this dataset, not a novel algorithm. Boker et al. (2002) cited for the windowing/peak-picking problem; our contribution framed as "quantification on dyadic dance data," not discovery. Lagcc's value = the mismatch null + sub-frame interpolation + the energy-vs-raw comparison, not the CC itself.

### C9. Bigand citation incomplete (R2)
**[ACTION — Completed]** Bigand, F., et al. (2024). Current Biology, 34(13), 3011–3019.e4. doi:10.1016/j.cub.2024.05.055.

### C10. No figures (R2)
**[ACTION — Figures promised]** R1 will include: (1) example signal + CC curve; (2) lag distribution histogram (full vs sub-window); (3) coherence spectrum + surrogate null band; (4) band boxplots by condition. [Plotted from re-run results; placeholder refs in text.]

### C11. 5 Hz limitation buried (R3 §4.8)
**[ACTION — Foregrounded]** The 5 Hz constraint is now stated in the **Introduction** and **Methods §3.1** as the study's defining boundary condition, not relegated to Limitations.

### C12. Data licensing/ethics statement (R3 §4.9)
**[ACTION — Added]** New statement: "Data are openly licensed under the Bigand et al. / IIT Dataverse terms; no additional human-subjects approval was required for this secondary analysis."

### C13. Bootstrap mention unused (R3 §4.10)
**[ACTION — Used]** Bootstrap now used for 95% CIs on all key effect sizes (especially N=35 dyad-level estimates).

---

## D. Additional Experiments (R2 §五)

| Experiment | Priority | Status in R1 |
|---|---|---|
| Dyad-level aggregation + LMM re-run | **Must** | ✅ Done — new §3.8, all R1 stats at N=35 |
| Effect-size code audit (SD vs SE) | **Must** | ✅ Done — §A2 above |
| Three surrogate nulls (IAAFT/circular/cross-song) | **Must** | ✅ Added — new §3.5/3.7 |
| Coherence bias correction (nperseg↓/multitaper/surrogate threshold) | **Must** | ✅ Done — §A4 above |
| vis_only data-leak排查 | **Must** | ✅ Done — §B2, was reporting error not leak |
| 25 Hz data re-run (Dataverse) | Strongly recommended | ⏳ Acknowledged as future work; DOI confirmed accessible, downsampling pipeline in preparation |
| Sub-window sensitivity (25/50/100) | Recommended | ✅ Added — new §4.3 reports sensitivity |
| CC/MI/RQA baseline bridge | Recommended | ⏳ Planned for R2 |
| Granger / PSI directionality | Optional | ⏳ Future work |

---

## E. Summary of Changes

| Category | Changes |
|---|---|
| **Statistical framework** | Redesigned: dyad-level (N=35) primary; LMM secondary; Wilcoxon paired; FDR corrected; permutation/surrogate nulls; coherence bias corrected |
| **Deleted** | §2.4 (off-topic); 3 orphan refs; mis-cited refs |
| **Fixed** | CC formula; effect-size (SD not SE); vis_only definition; N data-flow; §4.7 table; lag-scatter wording |
| **Added** | IAAFT surrogates; cross-song mismatch; multitaper; Fisher z; bootstrap CIs; data-flow diagram; ethics statement; figures |
| **Softened** | Music-coupling claim (partly music-driven); lagcc novelty (applied toolkit not novel algo); sub-frame precision claim |
| **Foregrounded** | 5 Hz as defining constraint (Introduction) |

We believe these revisions address the shared concerns substantively. The statistical framework is now valid for nested data; effect sizes are auditable; and the time–frequency complementarity insight—the paper's strongest contribution—is retained with appropriately calibrated claims.
