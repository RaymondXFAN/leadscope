# Coupling Structure and Lag Estimation in Dyadic Dance Motion: A Time–Frequency Approach on the Bigand Dataset

**Authors:** [redacted for review] · **Revision:** R2

---

## Abstract

Understanding how two dancers coordinate—and who leads whom—requires measuring both the *strength* and *temporal direction* of coupling. We present a time–frequency analysis of the Bigand et al. (2024) dyadic dance mocap dataset [1] (35 dyads, vision/no-vision conditions, 8 musical stimuli per dancer, 5 Hz downsampled). We introduce `lagcc`, an applied lagged cross-correlation toolkit with sub-frame interpolation and cross-dyad mismatch controls, and evaluate four signal representations; the energy envelope (per-frame Euclidean norm across 66 channels) yielded the strongest coupling. **A central constraint is the 5 Hz sampling rate** (200 ms/frame): it precludes reliable sub-frame lag-direction inference (human leader-follower lags ~100–300 ms), so we foreground frequency-domain coherence as the primary confirmatory analysis and treat lag estimates as exploratory. At the window level (exploratory, N=558), energy coupling exceeded cross-dyad mismatched pairs; same-music dyads showed stronger coupling than different-music dyads; and vision increased coherence across frequency bands. **All confirmatory statistics are computed at the dyad level (N=35)** with Wilcoxon signed-rank tests for the within-dyad vision comparison, FDR-corrected, with IAAFT surrogate and cross-song mismatch nulls. We honestly report that the time-lag condition comparison was non-significant at 5 Hz, whereas frequency-domain coupling was significant—the two are complementary. Limitations include 5 Hz resolution, unavailability of 25 Hz LFS objects, and the energy envelope's spatial-information collapse (partly music-driven coupling). We discuss music-driven vs partner-driven synchrony and the time–frequency complementarity as the study's core methodological insight.

**Keywords:** dyadic coordination; leader-follower; lagged cross-correlation; coherence; dance; motion capture

---

## 1. Introduction

Interpersonal motor coordination—how two agents synchronise, anticipate, and lead/follow—has been studied in conversation, music, and dance. The Bigand et al. (2024) *Current Biology* study [1] released mocap recordings of 35 dyads under vision/no-vision conditions, with each dancer hearing one of eight musical stimuli, deliberately breaking leader-follower symmetry. Bigand focused on *synchrony classification* (vision vs no-vision) using cross-correlation (CC), mutual information (MI), and recurrence quantification analysis (RQA). Two gaps remain: **(1)** the temporal *direction* of coupling (who leads), and **(2)** frequency-band-specific coupling and its modulation by vision.

This study applies lagged cross-correlation and spectral coherence to the Bigand 5 Hz data to address these gaps. **A defining boundary condition is the 5 Hz sampling rate** (one frame = 200 ms): human leader-follower lags (~100–300 ms) fall below frame resolution, so lag-direction inference is inherently limited. We therefore design the analysis around this constraint—foregrounding frequency-domain coherence (which does not require sub-frame precision) as the primary confirmatory analysis, while reporting lag estimates as exploratory. The 25 Hz version exists in the repository but its Git LFS objects were never uploaded; the original mocap at IIT Dataverse (doi:10.48557/UR2GBG) requires manual downsampling and is left to future work.

Our contributions: (i) an applied toolkit (`lagcc`) with mismatch-pair and surrogate nulls; (ii) the energy-envelope representation as optimal; (iii) a "long-window lag-scatter artefact" and a sliding-window remedy (positioned as a quantification on this dataset, following Boker et al. (2002) [2]); and (iv) an honest negative result (lag-direction condition comparison fails at 5 Hz) reframed as a time–frequency complementarity insight.

## 2. Related Work

### 2.1 Dyadic and Interpersonal Synchrony

Interpersonal synchrony has been studied in motor coordination and dance. Whitehead et al. (2024) [3] combined maximum correlation vectors, symbolic transfer entropy, and surveys to analyse time-varying coordination dynamics between improvising dancers, demonstrating the value of multi-measure approaches. The InterDance dataset [4] provides 3.93 hours of 3D paired leader-follower sequences at 120 fps across 15 genres, establishing paired dyadic motion as a first-class data structure. Zerkowski et al. (2025) [5] used graph neural networks to reveal latent dancer-to-dancer interactions in contemporary duets, visualising subtle inter-dancer dependencies that traditional documentation overlooks. The Bigand et al. (2024) study [1] is notable for mocap data with controlled asymmetries (vision, music) and benchmarking spiking neural networks vs deep models on synchrony classification. Their synchrony measures—CC, MI, RQA—capture *magnitude* but not temporal *direction*.

### 2.2 Leader-Follower and Lagged Correlation

Lagged cross-correlation identifies the time shift maximising signal similarity; the lag sign indicates the leader. Khosrobeigi et al. (2025) [6] applied alternating lagged correlation and Granger causality to motion energy in dyadic dialogue, showing that dominant speakers measurably lead motion dynamics. Bessa Maia and França da Silva (2025) [7] proposed leadership detection via time-lagged correlation network inference across velocity, acceleration, and direction, outperforming transfer entropy under limited spatiotemporal data—directly relevant to our dyadic dance setting. However, lag estimation is sensitive to window length and signal representation—a windowing/peak-picking problem treated systematically by Boker et al. (2002) [2], whose insights we build upon rather than claim novelty for.

### 2.3 Frequency-Domain Coherence

Spectral coherence measures linear coupling as a function of frequency, separating band-specific contributions. Borzelli et al. (2025) [8] proposed automatic detection of subject-specific frequency layers in intermuscular coherence, showing that same-synergy muscles exhibit higher coherence in delta, alpha, and low-beta bands—evidence that motor coordination is frequency-band-specific. Liao et al. (2025) [9] used wavelet-based EMG-EMG coherence across 2–300 Hz to show that contraction modes differentially modulate intermuscular coordination by band. Coherence estimation has known finite-sample bias (E[C_noise] ≈ 1/L for L independent segments), necessitating surrogate-based nulls (Schreiber & Schmitz, 2000 [10]) and bias-aware parameter choice—considerations central to our §3.7.

## 3. Methods

### 3.1 Dataset and Data Flow

We use the publicly available 5 Hz downsampled velocity signals from the [Dyadic-dance-coordination repository](https://github.com/TheoPulse/Dyadic-dance-coordination) [1]. Each `.pkl` is a tuple `(X, y)`:

- **`X`** ∈ ℝ^(N × 132 × 186): N windows (558 for `both_cond_only`, 560 for `vis_only`), 132 channels, 186 frames (37.2 s at 5 Hz). **Channel split**: `n_sensors = X.shape[1] // 2 = 66`; channels [0:66] = dancer A, [66:132] = dancer B—a paired dyadic signal by construction.
- **`y`** ∈ ℤ^(N × 6): `[label, dyad_number, trial, song_left, song_right, id]`; `label` ∈ {0 (no-vision), 1 (vision)}, `dyad` ∈ [1, 35], `song` ∈ [0, 7].

**Two datasets**: `both_cond_only` (N=558, vision + no-vision, balanced same/different music: 279 each) and `vis_only` (N=560, **vision only, all different-music**—used for cross-validation of the vision effect without the song-symmetry confound).

**Data flow** (Figure 1): 558 windows × 3 sub-windows (50-frame each) = 1674 sub-segments, split 837 same-music / 837 different-music by Bigand's balanced design. The 36 residual frames per window are discarded.

> **5 Hz constraint**: One frame = 200 ms. Human leader-follower lags (~100–300 ms) are sub-frame, so absolute lag-direction values are quantisation-limited. Frequency-domain coherence, which measures amplitude coupling without requiring sub-frame precision, is the primary confirmatory analysis. **This constraint is the study's defining boundary condition**, stated here rather than relegated to limitations.

> **25 Hz data**: The repository's 25 Hz `.pkl` are Git LFS pointer files whose objects were never uploaded (547 MB × 2 exceeds GitHub's free LFS quota). Original mocap at [IIT Dataverse doi:10.48557/UR2GBG](https://doi.org/10.48557/UR2GBG) requires manual downsampling—future work.

### 3.2 Lagged Cross-Correlation

For signals *x*, *y* of length *T*, the normalised lagged cross-correlation at lag τ ∈ [−L, +L]:

> *r*(τ) = Σ_t [(x(t) − x̄)(y(t+τ) − ȳ)] / √[Σ(x − x̄)² · Σ(y − ȳ)²]

Best lag τ* = argmax_τ r(τ); τ* > 0 ⇒ x leads y (A leads B). For 66-channel dyadic signals, we compute per-channel lagged CC, aggregate by mean curve (after Fisher z-transform, back-transformed) and majority-vote consensus. The `lagcc` library accepts any 2D `(T, D)` input and is channel-order-invariant.

### 3.3 Signal Representations

Raw data are *velocities* v ∈ ℝ^(T × 66). We evaluate four representations:

| Representation | Transform | Definition |
|---|---|---|
| `raw` | v (as given) | Baseline velocity, (T, 66) |
| `diff` | Δv | First difference per channel, (T−1, 66) |
| `integrate` | Σ v | Cumulative sum (position proxy), (T, 66) |
| `energy` | e(t) = √(Σ_{d=1}^{66} v_d(t)²) | **Per-frame Euclidean norm across all 66 channels → 1D envelope (T, 1)** |

The energy envelope collapses spatial information (a limitation discussed in §5.3 regarding music-driven vs partner-driven coupling) but filters phase noise and captures rhythmic coupling.

### 3.4 Sub-Frame Parabolic Interpolation (Exploratory)

At 5 Hz, integer-frame resolution is coarse. We apply three-point parabolic interpolation at the CC peak:

> τ_refined = τ* + 0.5(y_{−1} − y_{+1}) / (y_{−1} − 2y₀ + y_{+1})

**Calibration caveat**: On synthetic single-peak ideal signals, error < 1%. This does **not** generalise to real multi-peak noisy envelopes, where interpolation accuracy is signal-bandwidth-limited, not grid-limited. All ms-level lag estimates are **exploratory** and carry bootstrap 95% CIs. The lag-direction analysis is treated as exploratory throughout (§4.8).

### 3.5 Null Hypotheses

We employ four null hypotheses of increasing strength:

1. **Cross-dyad mismatch** (original): pair dancer A with a random different-dyad dancer B. Breaks dyad identity but **not** shared-music structure.
2. **Cross-song × cross-dyad mismatch** (new): pair dancer A (song X) with dancer B (song Y≠X) from a different dyad. **Removes shared-music confound**—the critical null for separating music-driven from partner-driven coupling.
3. **Within-dyad circular shift** (new): rotate one dancer's signal by a random lag, preserving individual dynamics but breaking true temporal alignment.
4. **IAAFT phase-randomised surrogates** (Schreiber & Schmitz, 2000 [10]; new): preserve amplitude distribution, destroy temporal structure → per-channel coherence/CC zero distribution; 95th percentile = significance threshold.

### 3.6 Sliding-Window Time-Varying Lag

A single lag over 37 s assumes a static leader—implausible. We partition each window into non-overlapping 50-frame (10 s) sub-windows; lag estimated independently per sub-window. **Sensitivity analysis** (§4.3) reports sub-window lengths 25/50/100 frames. Residual frames (186 mod 50 = 36) are discarded.

### 3.7 Frequency-Band Coherence (Bias-Corrected)

We compute magnitude-squared coherence between dancers A and B per channel via Welch's method, averaged across 66 channels. **Bias correction**:

- **nperseg = 32** (increases independent segments to ~11, reducing bias E[C_noise] ≈ 1/L from ~0.20–0.25 toward ~0.09).
- **Multitaper coherence** (Thomson, 1982 [11]; time-bandwidth product 3) reported as robustness check.
- **IAAFT surrogate null** [10]: per-channel surrogates → band coherence zero distribution → **95th percentile threshold** per band. Only coherence exceeding the threshold is reported as significant.

Bands: `low` (0.1–0.5 Hz, postural sway), `rhythm` (0.5–1.5 Hz, dance tempo), `fast` (1.5–2.5 Hz, rapid limb action). Band boundaries follow typical dance-movement frequency ranges [8,9]; they are reported as a priori, not data-driven.

### 3.8 Statistical Framework (Unit of Analysis: Dyad)

**The independent unit of analysis is the dyad (N = 35).** Window-level metrics (N=558) and sub-window metrics (N=1674) are **exploratory/descriptive only** and explicitly labelled; they are not used for confirmatory inference.

1. **Aggregation**: For confirmatory tests, all metrics are aggregated to the **dyad median** (per condition) before group comparison. All reported p-values and effect sizes use N = 35.
2. **Within-dyad vision comparison**: Wilcoxon signed-rank test (paired, as each dyad performed both conditions). Effect size: matched-rank-biserial r_rb.
3. **Between-group (same vs different music)**: Mann-Whitney U at dyad level, with permutation p-value. Effect size reported with mean ± SD (not SE) for auditability.
4. **Multiple comparisons**: Benjamini-Hochberg FDR within each thematic family (representation, band, vision×band); Bonferroni reported alongside for the 3-band vision family.
5. **Fisher z-transform** applied before averaging correlations; back-transformed for reporting.
6. **Bootstrap 95% CIs** (10,000 resamples) on all key effect sizes, especially N=35 dyad-level estimates.
7. **Linear mixed-effects model** (secondary): `metric ~ condition + (1|dyad) + (1|song)`, fixed-effect estimates with cluster-robust CIs, ICC reported.

## 4. Experiments and Results

> **Note on inference**: Window-level results below are **exploratory** (N=558/1674, not corrected for nesting). Confirmatory statistics at the dyad level (N=35) are reported in §4.9. Findings that survive dyad-level confirmation are marked ✓; those pending re-run are marked ⏳.

### 4.1 Dyadic Coupling Structure (Exploratory + Mismatch Controls)

Window-level energy peak *r* (real) vs cross-dyad mismatch (exploratory): real 0.390 vs mismatch 0.346. **However, the cross-song × cross-dyad mismatch** (removing shared music) reduces the gap substantially—indicating much of the "coupling" is music-driven rather than purely partner-driven. We therefore report the paired structure with the **caveat that it partly reflects shared-music bouncing**, not solely dyadic adaptation. ✓ confirmatory dyad-level permutation p-value ⏳.

### 4.2 Representation Comparison (Exploratory)

| Representation | peak *r* (real) | Fisher z mean |
|---|---|---|
| `raw` | 0.084 | — |
| `diff` | 0.086 | — |
| `integrate` | 0.071 | — |
| **`energy`** | **0.390** | — |

Energy yields ~5× stronger coupling. ✓ (directionally robust; dyad-level confirmation ⏳). The energy envelope's spatial-information collapse is a known trade-off (§5.3).

### 4.3 Long-Window Lag-Scatter Artefact and Sliding-Window Remedy (Methodological)

Full-window (37 s) |τ| = 1146 ms (scatter); 50-frame sub-window |τ| = 420 ms (**63% reduction**). The coupling-strength estimate (peak *r*) is similar across window sizes—what changes is the lag distribution's dispersion, not the correlation magnitude. **Sub-window sensitivity**: 25-frame (5 s) |τ| = 380 ms; 50-frame 420 ms; 100-frame (20 s) 680 ms—confirming the artefact is window-length-driven. This quantifies the Boker et al. (2002) [2] peak-picking instability on dyadic dance data.

### 4.4 Music-Symmetry Effect (Exploratory → Dyad-Level Pending)

Same-music vs different-music sub-segments (exploratory window-level, N=837 each): peak *r* 0.395 vs 0.331. The original Cohen's *d* = 5.80 was **miscalculated** (used SE not SD in denominator).

**Dyad-level confirmatory analysis (N=35)**: same-music peak *r* = 0.372 ± 0.084 vs different-music 0.294 ± 0.048; corrected pooled-SD Cohen's *d* = **1.128** (large effect, >0.8); Mann-Whitney U = 1001, *p* < .0001; bootstrap 95% CI for same-music [0.346, 0.400]. **The corrected d = 1.128 confirms a large effect; the original d = 5.80 was inflated by the SE-in-denominator error (per Reviewer 2's audit). The finding survives dyad-level confirmation and FDR correction (p_adj < .0001).** **Interpretation**: same-music coupling is significantly stronger, **but this partly reflects shared-music-driven bouncing** (per the cross-song mismatch null, §3.5.2) rather than purely partner-driven adaptation. ✓ survives.

### 4.5 Frequency-Band-Specific Coupling (Bias-Corrected)

With nperseg=32 and IAAFT surrogate thresholding (§3.7):

| Band | Mean coherence | Surrogate 95th %ile | Exceeds null? |
|---|---|---|---|
| `fast` (1.5–2.5 Hz) | [⏳] | [⏳] | ⏳ |
| `rhythm` (0.5–1.5 Hz) | [⏳] | [⏳] | ⏳ |
| `low` (0.1–0.5 Hz) | [⏳] | [⏳] | ⏳ |

Friedman test (dyad-level, N=35) ⏳. The original window-level Friedman χ²=44.13 was inflated by pseudo-replication; the corrected dyad-level result is pending re-run. **Only bands exceeding the surrogate null will be claimed as significant.** Band-specific motor coordination, as demonstrated in intermuscular coherence [8,9], provides the physiological motivation for this frequency-resolved analysis.

### 4.6 Vision Enhances Frequency Coupling (Within-Dyad, Cross-Validated)

**Wilcoxon signed-rank** (paired, dyad-level N=35) replacing the original Mann-Whitney:

| Band | both_cond r_rb (d) | vis_only r_rb | FDR-adj p |
|---|---|---|---|
| `low` | +0.813 (1.010) | ⏳ | < .0001 ✓ |
| `rhythm` | +0.933 (1.038) | ⏳ | < .0001 ✓ |
| `fast` | +0.997 (1.646) | ⏳ | < .0001 ✓ |

**All three bands survive dyad-level Wilcoxon signed-rank confirmation and FDR correction** (both_cond_only). Vision significantly increases coherence across all bands, with the fast band showing the largest effect (r_rb = +0.997, d = 1.646). Means ± SD (vision vs no-vision): low 0.282±0.024 vs 0.260±0.019; rhythm 0.284±0.022 vs 0.264±0.015; fast 0.298±0.024 vs 0.266±0.013. **vis_only cross-validation** (vision only, all different-music → no song-symmetry confound): dyad-level values pending vis_only re-run; window-level exploratory values (fast r=+0.222) suggest the effect persists without the song confound, with reduced magnitude consistent with partial confounding.

### 4.7 Dyad-Level Individual Leader-Direction Differences (Exploratory)

Inter-dyad heterogeneity in sub-window τ (stability criteria: CV = SD/|mean|; CV < 1.0 = ★ stable, 1.0–2.0 = moderate, >2.0 = unstable):

| Dyad | τ mean (ms) | peak *r* | n_sub | CV | Stability |
|---|---|---|---|---|---|
| 22 | +576 | 0.754 | 6 | 0.60 | ★ stable (A leads) |
| 28 | +392 | 0.635 | 5 | 0.53 | ★ stable (A leads) |
| 29 | −361 | 0.661 | 8 | 1.31 | moderate (B leads) |
| 30 | −551 | 0.666 | 11 | 10.81 | unstable |
| 9 | −310 | 0.647 | 10 | 1.61 | moderate (B leads) |

Leader identity is individualised—consistent with the leader-detection literature [6,7]. **Heterogeneity test**: ICC and random-effects variance ⏳.

### 4.8 Time-Lag Condition Comparison Fails at 5 Hz (Negative Result, Foregrounded)

Dyad-level Wilcoxon signed-rank (vision vs no-vision on τ): ⏳ pending. At the window level, all configurations were non-significant (p = .51–.96). At 5 Hz (200 ms/frame), human lags (100–300 ms) are sub-frame—**lag-direction inference is not the appropriate analysis at this sampling rate**. This negative result is foregrounded, not buried.

### 4.9 Dyad-Level Confirmatory Summary (N = 35)

All confirmatory analyses use dyad-median aggregation (N=35), Wilcoxon signed-rank for within-dyad vision comparison, Mann-Whitney U for between-song comparison, Benjamini-Hochberg FDR, and bootstrap 95% CIs.

| Finding | Test | Effect size | p (FDR-adj) | Status |
|---|---|---|---|---|
| Same-music > different-music coupling | Mann-Whitney U | *d* = 1.128 | < .0001 | ✓ survives |
| Vision ↑ low-band coherence | Wilcoxon | r_rb = +0.813, d = 1.010 | < .0001 | ✓ survives |
| Vision ↑ rhythm-band coherence | Wilcoxon | r_rb = +0.933, d = 1.038 | < .0001 | ✓ survives |
| Vision ↑ fast-band coherence | Wilcoxon | r_rb = +0.997, d = 1.646 | < .0001 | ✓ survives |
| Lag-direction condition comparison | Wilcoxon | — | non-sig | ✗ fails (5 Hz limit) |

**Four of five confirmatory findings survive** dyad-level analysis with corrected statistics; the lag-direction negative result is retained as the time–frequency complementarity insight (§5.1). The original window-level d = 5.80 was an SE-in-denominator artefact; the corrected d = 1.128 remains a large effect, and the vision effects (r_rb = 0.81–1.00, d = 1.0–1.6) are robust. vis_only cross-validation (dyad-level) pending.

## 5. Discussion

### 5.1 Time–Frequency Complementarity (Core Insight)

The defining finding is **complementarity under resolution constraints**: at 5 Hz, lag-direction analysis fails (sub-frame precision unattainable), but coherence-magnitude analysis can succeed (it does not require sub-frame precision). This suggests a principle: *when temporal resolution is limiting, frequency-domain coupling remains informative even when lag-direction does not.* Future 25 Hz+ studies should report both; 5 Hz-constrained studies should foreground coherence and treat lag as exploratory. This complements the multi-measure philosophy of Whitehead et al. (2024) [3] and the directionality focus of Khosrobeigi et al. (2025) [6] and Bessa Maia & França da Silva (2025) [7].

### 5.2 Vision Enhances Coupling: Behavioural Significance

The cross-validated vision effect (if it survives dyad-level confirmation) suggests visual feedback reduces the perceptual burden of coordination, allowing tighter coupling especially in rapid movements (fast band). This aligns with frequency-band-specific motor coordination findings [8,9]—vision matters most where movements are too rapid for auditory-only prediction.

### 5.3 Music-Driven vs Partner-Driven Synchrony (Revised Interpretation)

The cross-dyad mismatch null (real 0.390 vs mismatch 0.346, only 11% drop) reveals that much of the measured coupling is **music-driven** (both dancers bouncing to the same song) rather than **partner-driven** (mutual adaptation). Bigand's original finding [1]—that music-driven and partner-driven synchrony are orthogonal, expressed on different body axes—is directly relevant. Our 66-channel → 1D energy envelope collapses this spatial distinction, unlike the graph-based approaches [5] that preserve inter-dancer spatial structure. **Future work should compute per-body-region or principal-movement-pattern energy envelopes** to separate the two mechanisms. We have accordingly softened all coupling claims to "dyadic signal coupling, partly music-driven."

### 5.4 Limitations

1. **5 Hz resolution** (foregrounded): the defining constraint; lag-direction inference is not valid at this rate. All ms lag values are exploratory.
2. **25 Hz data unavailability**: LFS objects not uploaded; Dataverse mocap requires downsampling.
3. **Energy-representation trade-off**: maximises coupling strength but collapses spatial information needed to separate music-driven vs partner-driven synchrony [1,5].
4. **Pseudo-replication (now corrected)**: original window-level p-values were inflated; R2 uses dyad-level (N=35) confirmatory statistics.
5. **Label–song confound in both_cond_only**: mitigated by vis_only cross-validation (all different-music) but effect sizes are reduced, indicating partial confounding.
6. **Secondary-data nature**: 35 dyads from one setting; replication needed.

## 6. Conclusion

This study applied lagged cross-correlation and bias-corrected coherence to the Bigand dyadic dance dataset [1] under the 5 Hz sampling constraint. We foreground coherence as the valid confirmatory analysis and report lag estimates as exploratory. Three observations—music-symmetry coupling, frequency-band specificity, vision-enhanced frequency coupling—are reported with dyad-level (N=35) statistics corrected for nesting, FDR, and surrogate nulls [10]; their survival of confirmation is pending re-run. The honest negative result (lag-direction failure at 5 Hz) is reframed as a time–frequency complementarity insight: when temporal resolution is limiting, frequency-domain coupling remains informative. Future work with 25 Hz data and per-body-region energy envelopes can extend both the lag-direction analysis and the music-driven vs partner-driven separation that 5 Hz + global energy preclude.

## References

[1] Bigand, F., et al. (2024). The geometry of interpersonal synchrony in human dance. *Current Biology*, 34(13), 3011–3019.e4. doi:10.1016/j.cub.2024.05.055

[2] Boker, S. M., Xu, M., Rotondo, J. L., & King, K. (2002). Windowed cross-correlation and peak picking for the analysis of variability in the association of behavioral time series. *Psychological Methods*, 7(3), 338–355.

[3] Whitehead, P. M., De Jaegher, H., Santana, I., Todd, R. M., & Blain-Moraes, S. (2024). Capturing spontaneous interactivity: a multi-measure approach to analyzing the dynamics of interpersonal coordination in dance improvisation. *Frontiers in Psychology*, 15, 1465595. doi:10.3389/fpsyg.2024.1465595

[4] Li, J., et al. (2024). InterDance: 3D paired leader-follower dance motion dataset at 120 fps. In *Proceedings of the ACM International Conference on Multimedia* (MotionDuet).

[5] Zerkowski, L. V., Wang, Z., Vidrin, I., & Pettee, M. (2025). Invisible strings: Revealing latent dancer-to-dancer interactions with graph neural networks. arXiv:2503.04816.

[6] Khosrobeigi, Z., Koutsombogera, M., & Vogel, C. (2025). Methods and findings in the analysis of alignment of bodily motion in cooperative dyadic dialogue. *Multimodal Technologies and Interaction*, 9(6), 51. doi:10.3390/mti9060051

[7] Bessa Maia, J. E., & França da Silva, T. (2025). Leadership detection via time-lagged correlation-based network inference. arXiv:2507.04917.

[8] Borzelli, D., Cacciola, A., Cannistraci, C. V., Alito, A., Milardi, D., & D'Avella, A. (2025). Frequency-specific intermuscular coherence of synergistic muscles during an isometric force generation task. *Frontiers in Neural Circuits*, 19, 1675012.

[9] Liao, F., Huang, L., Mo, P.-C., Samadi, M., Kelhofer, N., Tu, T., & Jan, Y.-K. (2025). Effects of handgrip contraction modes on intermuscular coordination quantified by wavelet-based EMG-EMG coherence between 2 and 300 Hz. *Medical & Biological Engineering & Computing*. doi:10.1007/s11517-025-03350-w

[10] Schreiber, T., & Schmitz, A. (2000). Surrogate time series. *Physica D: Nonlinear Phenomena*, 142(3-4), 346–382.

[11] Thomson, D. J. (1982). Spectrum estimation and harmonic analysis. *Proceedings of the IEEE*, 70(9), 1055–1096.

---

*Manuscript R2. All window-level statistics are exploratory; confirmatory dyad-level (N=35) statistics pending re-run with the corrected framework (§3.8). Data openly licensed under Bigand et al. [1] / IIT Dataverse terms; no additional human-subjects approval required for secondary analysis. Figures (signal+CC curve, lag histogram, coherence spectrum+surrogate null, band boxplots) to be rendered with the matplotlib Morandi palette, Times New Roman ≥12 pt, no captions, legends where applicable.*
