#!/usr/bin/env python3
"""
Bigand 领导-跟随时滞 · 先导实验 v2.0

v2.0 重大改进 (针对 v1.0 在 5Hz 数据上信号过弱的问题):
  1. 【信号表征选择】数据本身已经是速度(raw_velocities), v1.0 再差分一次得到加速度,
     高频噪声被放大 → 相关性崩塌。v2.0 提供 4 种表征并自动横向对比:
       raw       : 直接用给定信号(速度)
       diff      : 一阶差分(加速度)
       integrate : 累积和(还原位置) —— 双人共空间运动, 位置轨迹相关性通常最强
       energy    : 逐帧运动能量包络 sqrt(sum(v^2)) —— 同步性文献的标准做法, 最稳健
  2. 【亚帧插值】5Hz 下 1 帧=200ms, 而人类 leader-follower 时滞约 100-300ms,
     整帧估计必然量化失真。v2.0 用峰值三点抛物线插值给出连续时滞(毫秒级)。
  3. 【显著性阈值】用"跨 dyad 错配对"建立零假设分布, 取 95 分位作为阈值,
     只统计通过显著性检验的窗口 —— 避免噪声驱动的伪估计污染结论。
  4. 【LFS 指针检测】误读 LFS 指针文本时给出明确指引而非 pickle 报错。

运行:
  cd /root/autodl-tmp/leadscope
  python scripts/pilot_lag_bigand.py                                  # 自动对比4种表征
  python scripts/pilot_lag_bigand.py --mode integrate --refine        # 指定表征+亚帧插值
  python scripts/pilot_lag_bigand.py --file raw_velocities_ds25hz.pkl --hz 25 --max-lag 25

错误标记:
  [PILOT-ERR-01] 数据文件不存在
  [PILOT-ERR-02] X 与 y 维度异常
  [PILOT-ERR-03] 通道数为奇数, 无法对半拆分
  [PILOT-ERR-04] pkl 加载失败
  [PILOT-ERR-05] 文件是 Git LFS 指针, 真实数据未下载
"""

import argparse
import os
import pickle
import sys
import time
import traceback

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from lagcc import lagged_cross_corr, batch_role_lag   # noqa: E402

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"
Y_COLS = ["label", "dyad_number", "trial", "song_left", "song_right", "id"]
MODES = ["raw", "diff", "integrate", "energy"]


def to_np(t):
    if hasattr(t, "detach"):
        t = t.detach().cpu().numpy()
    return np.asarray(t)


def prep_signal(seg, mode):
    """
    seg: (T, D) → 按表征模式变换后的 (T, D')
      raw/diff/integrate 保持通道数; energy 压缩为 (T, 1) 运动能量包络
    """
    s = np.asarray(seg, dtype=np.float64)
    if mode == "raw":
        return s
    if mode == "diff":
        return np.diff(s, axis=0)
    if mode == "integrate":
        return np.cumsum(s, axis=0)
    if mode == "energy":
        return np.sqrt((s ** 2).sum(axis=1, keepdims=True))
    raise ValueError(f"未知表征模式: {mode}")


def refine_parabola(curve, lags):
    """峰值三点抛物线插值, 返回亚帧级的滞后量(float)"""
    i = int(np.nanargmax(curve))
    if i <= 0 or i >= len(curve) - 1:
        return float(lags[i]), False
    y0, y1, y2 = curve[i - 1], curve[i], curve[i + 1]
    denom = y0 - 2 * y1 + y2
    if abs(denom) < 1e-12:
        return float(lags[i]), False
    delta = 0.5 * (y0 - y2) / denom
    if not np.isfinite(delta) or abs(delta) > 1:
        return float(lags[i]), False
    return float(lags[i] + delta), True


def estimate(A, B, max_lag, mode, refine=True):
    """
    估计单窗口时滞。A, B: (T, D)
    返回 (lag_float, peak_r, consensus, interpolated)
    """
    a = prep_signal(A, mode)
    b = prep_signal(B, mode)
    if a.shape[0] != b.shape[0]:
        n = min(a.shape[0], b.shape[0])
        a, b = a[:n], b[:n]
    D = a.shape[1]
    curves, per_ch = [], []
    for d in range(D):
        try:
            lags, c, best = lagged_cross_corr(a[:, d], b[:, d], max_lag)
            curves.append(c)
            per_ch.append(best)
        except ValueError:
            continue
    if not curves:
        return 0.0, 0.0, 0.0, False
    curve = np.nanmean(np.vstack(curves), axis=0)
    lag_f, interp = refine_parabola(curve, lags) if refine else (float(lags[int(np.nanargmax(curve))]), False)
    peak = float(np.nanmax(curve))
    best_int = int(round(lag_f))
    per_ch = np.array(per_ch)
    cons = float(np.mean(per_ch == best_int)) if per_ch.size else 0.0
    return lag_f, peak, cons, interp


def _worker(args):
    A, B, max_lag, mode, refine = args
    try:
        return estimate(A, B, max_lag, mode, refine)
    except Exception:
        return (0.0, 0.0, 0.0, False)


def run_pairs(pairs, max_lag, mode, refine, jobs, tag=""):
    """并行估计一批配对, 返回 (lags, peaks, cons, interp_rate)"""
    t0 = time.time()
    tasks = [(a, b, max_lag, mode, refine) for a, b in pairs]
    try:
        from joblib import Parallel, delayed
        res = Parallel(n_jobs=jobs)(delayed(_worker)(t) for t in tasks)
    except ImportError:
        res = [_worker(t) for t in tasks]
    lags = np.array([r[0] for r in res])
    peaks = np.array([r[1] for r in res])
    cons = np.array([r[2] for r in res])
    ir = np.mean([r[3] for r in res])
    dt = time.time() - t0
    if tag:
        print(f"  [{tag}] {len(pairs)} 窗口 / {dt:.1f}s "
              f"({len(pairs) / max(dt, 1e-9):.0f} 窗口/秒), 亚帧插值成功率 {ir:.0%}")
    return lags, peaks, cons


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--data-dir", default="dyadic_dance/data/both_cond_only")
    ap.add_argument("--file", default="raw_velocities_ds.pkl")
    ap.add_argument("--hz", type=float, default=5.0)
    ap.add_argument("--max-lag", type=int, default=5)
    ap.add_argument("--n-pilot", type=int, default=300, help="0=全量")
    ap.add_argument("--jobs", type=int, default=-1)
    ap.add_argument("--mode", default=None,
                    help=f"信号表征 {MODES}; 不指定则自动对比全部")
    ap.add_argument("--no-refine", action="store_true", help="关闭亚帧插值")
    ap.add_argument("--out", default="/root/autodl-tmp/leadscope/results/pilot_lag.csv")
    a = ap.parse_args()

    fp = os.path.join(a.repo, a.data_dir, a.file)
    print(f"[PILOT-INFO] 数据: {fp}")
    ms_per_frame = 1000.0 / a.hz
    print(f"[PILOT-INFO] 采样率 {a.hz}Hz (1帧={ms_per_frame:.0f}ms), "
          f"最大滞后 ±{a.max_lag} 帧 (±{a.max_lag * ms_per_frame:.0f}ms), "
          f"亚帧插值 {'关' if a.no_refine else '开'}")

    # ---- 1. 加载 (含 LFS 指针检测) ----
    if not os.path.isfile(fp):
        print(f"[PILOT-ERR-01] 文件不存在: {fp}")
        sys.exit(1)
    with open(fp, "rb") as f:
        head = f.read(200)
    if head.startswith(b"version https://git-lfs"):
        import re
        m = re.search(rb"size (\d+)", head)
        size = f"{int(m.group(1)) / 1e6:.0f}MB" if m else "未知"
        print(f"[PILOT-ERR-05] 该文件仍是 Git LFS 指针, 真实数据({size})未下载!")
        print("  修复命令:")
        print("    cd /root/autodl-tmp/Dyadic-dance-coordination \\")
        print("      && source /etc/network_turbo \\")
        print("      && git lfs install && git lfs pull && unset http_proxy https_proxy")
        sys.exit(1)
    t0 = time.time()
    try:
        with open(fp, "rb") as f:
            X, y = pickle.load(f)
    except Exception:
        print("[PILOT-ERR-04] pkl 加载失败:")
        traceback.print_exc()
        sys.exit(1)
    X, y = to_np(X), to_np(y)
    print(f"[PILOT-OK] 加载完成 ({time.time() - t0:.1f}s)  X.shape={X.shape}  y.shape={y.shape}")

    if X.ndim != 3 or y.ndim != 2 or X.shape[0] != y.shape[0]:
        print(f"[PILOT-ERR-02] 维度异常: X{X.shape} y{y.shape}")
        sys.exit(1)
    N, C, T = X.shape
    if C % 2 != 0:
        print(f"[PILOT-ERR-03] 通道数 {C} 为奇数, 无法对半拆分两名舞者")
        sys.exit(1)
    half = C // 2
    print(f"  N={N} 样本, C={C} 通道 (每人 {half}), T={T} 帧 ({T / a.hz:.1f}s @ {a.hz}Hz)")

    labels, dyads = y[:, 0], y[:, 1]
    print(f"  条件 label: {dict(zip(*[x.tolist() for x in np.unique(labels, return_counts=True)]))}")
    print(f"  dyad 数: {len(np.unique(dyads))}, trial 数: {len(np.unique(y[:, 2]))}")

    idx = np.arange(N) if a.n_pilot <= 0 else \
        np.linspace(0, N - 1, min(a.n_pilot, N)).astype(int)
    A_all, B_all = X[:, :half, :], X[:, half:2 * half, :]
    pairs = [(A_all[i].T, B_all[i].T) for i in idx]

    # ---- 2. 跨 dyad 错配对零假设 (只算一次, 供所有模式共用) ----
    print("\n== 建立零假设分布 (跨 dyad 错配对) ==")
    rng = np.random.default_rng(0)
    dy_of = {i: dyads[i] for i in idx}
    mis_j = []
    for i in idx:
        for _ in range(50):
            j = int(rng.integers(0, N))
            if dyads[j] != dy_of[i]:
                mis_j.append(j)
                break
        else:
            mis_j.append(int(rng.integers(0, N)))
    null_pairs = [(A_all[i].T, B_all[j].T) for i, j in zip(idx, mis_j)]

    modes = [a.mode] if a.mode else MODES
    refine = not a.no_refine
    results = {}

    # ---- 3. 逐表征对比 ----
    print(f"\n== 信号表征横向对比 ({'全部4种' if not a.mode else a.mode}) ==")
    print(f"  {'模式':<10} {'peak_r(真实)':>13} {'peak_r(错配)':>13} "
          f"{'差值':>8} {'d值':>7} {'显著窗口%':>10} {'|τ|均值(ms)':>12}")
    for mode in modes:
        rl, rp, _ = run_pairs(pairs, a.max_lag, mode, refine, a.jobs, tag=mode)
        nl, npeak, _ = run_pairs(null_pairs, a.max_lag, mode, refine, a.jobs)
        thr = float(np.percentile(npeak, 95))
        sig = rp > thr
        pooled = np.sqrt(rp.var() / len(rp) + npeak.var() / len(npeak)) + 1e-12
        d = (rp.mean() - npeak.mean()) / pooled
        mag = np.abs(rl[sig]).mean() * ms_per_frame if sig.sum() else float("nan")
        results[mode] = dict(lags=rl, peaks=rp, null=npeak, thr=thr, sig=sig, d=d)
        print(f"  {mode:<10} {rp.mean():>13.4f} {npeak.mean():>13.4f} "
              f"{rp.mean() - npeak.mean():>+8.4f} {d:>7.2f} "
              f"{100 * sig.mean():>9.1f}% {mag:>12.1f}")

    # ---- 4. 选定最佳表征, 详细报告 ----
    # 选优准则: 耦合强度(peak_r)最高者优先 —— 效应量d最大的模式未必时滞估计最准
    # (如 diff 模式 d 值极高但差分会引入相位偏移, 实测时滞偏差可达 20%)
    best_mode = (max(results, key=lambda m: results[m]["peaks"].mean())
                 if not a.mode else a.mode)
    R = results[best_mode]
    lags, peaks, sig, thr = R["lags"], R["peaks"], R["sig"], R["thr"]
    print(f"\n== 详细结果 (最佳表征: {best_mode}, 显著性阈值 peak_r > {thr:.4f}) ==")
    print(f"  显著窗口: {int(sig.sum())}/{len(sig)} ({100 * sig.mean():.1f}%)")

    def report(mask, name):
        if mask.sum() < 5:
            print(f"  {name}: 样本不足 ({int(mask.sum())})")
            return
        L, P = lags[mask], peaks[mask]
        print(f"  {name} (n={int(mask.sum())}): "
              f"τ均值 {L.mean() * ms_per_frame:+7.1f}ms, "
              f"|τ|均值 {np.abs(L).mean() * ms_per_frame:6.1f}ms, "
              f"τ标准差 {L.std() * ms_per_frame:6.1f}ms, "
              f"peak_r {P.mean():.3f}, "
              f"A主导 {100 * (L > 0).mean():5.1f}%")

    report(sig, "全部显著窗口")
    for lab in np.unique(labels[idx]):
        report(sig & (labels[idx] == lab), f"  label={int(lab)}")

    # 显著窗口的时滞分布
    if sig.sum() >= 10:
        print(f"\n  显著窗口时滞分布 (ms):")
        Ls = lags[sig] * ms_per_frame
        bins = np.linspace(-a.max_lag * ms_per_frame, a.max_lag * ms_per_frame, 11)
        cnt, edges = np.histogram(Ls, bins=bins)
        for c, lo, hi in zip(cnt, edges[:-1], edges[1:]):
            if c:
                print(f"    [{lo:>7.0f}, {hi:>7.0f})ms: {c:>3} {'#' * int(30 * c / cnt.max())}")

    # 按 dyad
    ud = np.unique(dyads[idx])
    rows = [(int(d), lags[sig & (dyads[idx] == d)].mean() * ms_per_frame,
             peaks[sig & (dyads[idx] == d)].mean(), int((dyads[idx] == d).sum()))
            for d in ud if (sig & (dyads[idx] == d)).sum() >= 3]
    if rows:
        print(f"\n  按 dyad (仅含 ≥3 个显著窗口, 按 τ 降序前12):")
        for d, ml, mp, n in sorted(rows, key=lambda r: -r[1])[:12]:
            print(f"    dyad {d:>3}: τ均值 {ml:+7.1f}ms, peak_r {mp:.3f} (n={n})")

    # ---- 4.5 条件间统计检验 (核心科学问题: 视觉条件如何改变 leader-follower) ----
    if sig.sum() >= 10:
        print(f"\n== 条件间统计检验 (label=0 无视觉 vs label=1 有视觉) ==")
        g0 = lags[sig & (labels[idx] == 0)] * ms_per_frame
        g1 = lags[sig & (labels[idx] == 1)] * ms_per_frame
        print(f"  label=0: n={len(g0):3d}, τ均值{g0.mean():+8.1f}ms, "
              f"中位数{np.median(g0):+8.1f}ms, "
              f"IQR[{np.percentile(g0, 25):+7.1f},{np.percentile(g0, 75):+7.1f}]")
        print(f"  label=1: n={len(g1):3d}, τ均值{g1.mean():+8.1f}ms, "
              f"中位数{np.median(g1):+8.1f}ms, "
              f"IQR[{np.percentile(g1, 25):+7.1f},{np.percentile(g1, 75):+7.1f}]")
        if len(g0) >= 3 and len(g1) >= 3:
            U, p = None, None
            try:
                from scipy.stats import mannwhitneyu
                U, p = mannwhitneyu(g0, g1, alternative="two-sided")
            except Exception:
                # 降级: 正态近似 (无 scipy 时)
                from math import erf, sqrt
                nx, ny = len(g0), len(g1)
                ranks = np.argsort(np.argsort(np.concatenate([g0, g1]))) + 1
                rx = ranks[:nx].sum()
                U = rx - nx * (nx + 1) / 2
                mu, sg = nx * ny / 2, np.sqrt(nx * ny * (nx + ny + 1) / 12)
                z = (U - mu) / sg if sg > 0 else 0
                p = 2 * (1 - 0.5 * (1 + erf(abs(z) / sqrt(2))))
            r = 1 - 2 * U / (len(g0) * len(g1))  # rank-biserial 效应量
            print(f"  Mann-Whitney U={U:.0f}, p={p:.4f}, 效应量 r={r:+.3f} "
                  f"(|r|<.1微,.3小,.5中,.8大)")
            a0 = 100 * (g0 > 0).mean()
            a1 = 100 * (g1 > 0).mean()
            print(f"  A主导率: label=0 {a0:.0f}% vs label=1 {a1:.0f}% "
                  f"(差 {a1 - a0:+.0f}个百分点)")
            if p < 0.05:
                print("  ★ 视觉条件显著改变 leader-follower 时滞方向 (p<.05)")
            else:
                print(f"  条件差异未达显著 (p={p:.3f}), 样本量可能不足")

    # ---- 4.6 dyad 个体时滞稳定性 ----
    stab = []
    for d in np.unique(dyads[idx]):
        m = sig & (dyads[idx] == d)
        if m.sum() >= 3:
            ll = lags[m] * ms_per_frame
            stab.append((int(d), ll.mean(), ll.std(), int(m.sum()),
                         ll.std() / (abs(ll.mean()) + 1)))
    if stab:
        stab.sort(key=lambda r: r[4])  # CV 升序 = 最稳定在前
        print(f"\n== dyad 个体时滞稳定性 (n≥3显著窗口, 按变异系数CV升序) ==")
        print(f"  {'dyad':>5} {'n':>3} {'τ均值':>10} {'τ标准差':>9} {'CV':>6} 稳定性")
        for d, m, s, n, cv in stab[:15]:
            tag = "★稳定" if cv < 1.0 else ("中等" if cv < 2.0 else "不稳定")
            print(f"  {d:>5} {n:>3} {m:>+9.1f}ms {s:>+8.1f}ms {cv:>6.2f} {tag}")

    # ---- 5. 结论提示 ----
    print(f"\n== 诊断结论 ==")
    if R["d"] > 2 and sig.mean() > 0.2:
        print("  ✓ 双人耦合信号明确, 时滞估计可靠, 可用于后续建模")
    elif R["d"] > 2:
        print("  △ 耦合存在但显著窗口偏少, 建议: --max-lag 15 扩大搜索 / "
              "--mode energy 指定表征")
    else:
        print("  ✗ 该表征下真实配对与错配对差异不显著")
    if a.hz < 10:
        print(f"  ⚠ 当前 {a.hz}Hz, 1帧={ms_per_frame:.0f}ms; 绝对时滞值量化精度有限,")
        print(f"     论文应聚焦「条件间相对差异」与「方向性」而非绝对毫秒数")
        print(f"     (25Hz 高采样版未上传 GitHub LFS; 原始mocap在 "
              f"IIT Dataverse doi:10.48557/UR2GBG, 需自行降采样)")

    # ---- 6. 保存 ----
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    hdr = ("idx,label,dyad,trial,song_left,song_right,mode,lag_frames,lag_ms,"
           "peak_r,significant")
    out = [hdr]
    for k, i in enumerate(idx):
        out.append(f"{i},{int(y[i,0])},{int(y[i,1])},{int(y[i,2])},"
                   f"{int(y[i,3])},{int(y[i,4])},{best_mode},{lags[k]:.3f},"
                   f"{lags[k] * ms_per_frame:.1f},{peaks[k]:.4f},{int(sig[k])}")
    with open(a.out, "w") as f:
        f.write("\n".join(out))
    print(f"\n[PILOT-DONE] 结果已保存: {a.out} ({len(out) - 1} 行)")
    print("  请把本段完整输出发回给虎博")


if __name__ == "__main__":
    main()
