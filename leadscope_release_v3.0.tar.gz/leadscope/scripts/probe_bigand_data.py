#!/usr/bin/env python3
"""
Bigand 核心数据文件探测脚本 v1.0
运行: cd /root/autodl-tmp/leadscope && python scripts/probe_bigand_data.py
作用: 深入加载 raw_velocities_ds.pkl 和 features_ds.pkl (真正要用的数据),
      并检查 134B 的可疑小文件是否为 LFS 指针。

错误标记约定:
  [PROBE-ERR-01] 数据目录不存在
  [PROBE-ERR-02] LFS 指针未拉取 (文件 < 500B 但应为数十MB)
  [PROBE-ERR-03] pkl 加载失败 (把 traceback 发回)
"""

import os
import sys
import pickle
import traceback

import numpy as np

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"
TARGETS = [
    "dyadic_dance/data/both_cond_only/raw_velocities_ds.pkl",
    "dyadic_dance/data/both_cond_only/features_ds.pkl",
    "dyadic_dance/data/vis_only/raw_velocities_ds.pkl",
    "dyadic_dance/data/vis_only/features_ds.pkl",
]
SUSPECTS = [
    "dyadic_dance/data/both_cond_only/raw_velocities_ds25hz.pkl",
    "dyadic_dance/data/vis_only/raw_velocities_ds25hz.pkl",
]

def human(n):
    for u in ["B", "KB", "MB", "GB"]:
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}TB"

def describe(obj, prefix="", depth=0, max_depth=3):
    pad = prefix + "  " * depth
    if isinstance(obj, dict):
        print(f"{pad}dict, {len(obj)} keys: {list(obj.keys())[:15]}")
        if depth < max_depth:
            for k, v in list(obj.items())[:5]:
                print(f"{pad}[{k!r}] ->")
                describe(v, prefix, depth + 1, max_depth)
    elif isinstance(obj, (list, tuple)):
        kind = "list" if isinstance(obj, list) else "tuple"
        print(f"{pad}{kind}, len={len(obj)}")
        if len(obj) and depth < max_depth:
            print(f"{pad}首元素:")
            describe(obj[0], prefix, depth + 1, max_depth)
            if len(obj) > 1:
                print(f"{pad}末元素:")
                describe(obj[-1], prefix, depth + 1, max_depth)
    elif isinstance(obj, np.ndarray):
        print(f"{pad}ndarray shape={obj.shape}, dtype={obj.dtype}, "
              f"min={float(np.nanmin(obj)):.4f}, max={float(np.nanmax(obj)):.4f}")
        if obj.ndim >= 2 and obj.shape[0] > 1:
            # 逐帧差分能量, 判断是否为速度信号(差分应远小于原值)
            diff_scale = float(np.mean(np.abs(np.diff(obj, axis=0)))) / (float(np.mean(np.abs(obj))) + 1e-9)
            print(f"{pad}  (帧间差分/幅值比: {diff_scale:.4f} — <<1 更像位置, ~1-2 更像速度/白噪)")
    else:
        print(f"{pad}{type(obj).__name__}: {str(obj)[:120]}")

def main():
    if not os.path.isdir(REPO):
        print(f"[PROBE-ERR-01] 仓库不存在: {REPO}")
        sys.exit(1)

    # ---- 1. 可疑小文件: 是否 LFS 指针 ----
    print("== 可疑小文件检查 (134B 的 *25hz.pkl) ==")
    for rel in SUSPECTS:
        fp = os.path.join(REPO, rel)
        if not os.path.isfile(fp):
            print(f"  [缺失] {rel}")
            continue
        sz = os.path.getsize(fp)
        with open(fp, "rb") as f:
            head = f.read(200)
        print(f"  {rel}  ({sz}B)")
        print(f"    前200字节: {head!r}")
        if head.startswith(b"version https://git-lfs"):
            print("    → [PROBE-ERR-02] 这是 Git LFS 指针, 真实数据未下载!")
            print("      修复: cd /root/autodl-tmp/Dyadic-dance-coordination && "
                  "git lfs install && git lfs pull")
        else:
            print("    → 非 LFS 指针, 是普通小文件 (可能是路径引用/空数据)")

    # ---- 2. 核心大文件结构探测 ----
    print("\n== 核心数据文件结构 ==")
    for rel in TARGETS:
        fp = os.path.join(REPO, rel)
        print(f"\n--- {rel} ---")
        if not os.path.isfile(fp):
            print("  [缺失] 文件不存在!")
            continue
        sz = os.path.getsize(fp)
        print(f"  大小: {human(sz)}")
        if sz < 500:
            print("  [PROBE-ERR-02] 文件过小, 疑似 LFS 指针未拉取!")
            continue
        try:
            with open(fp, "rb") as f:
                obj = pickle.load(f)
            describe(obj, prefix="  ")
        except Exception:
            print("  [PROBE-ERR-03] 加载失败:")
            traceback.print_exc()
            print("  把上面 traceback 发回给虎博")

    # ---- 3. Synchrony 特征文件 (只看一个的顶层结构) ----
    print("\n== Synchrony 特征文件 (顶层结构) ==")
    sync = "dyadic_dance/functional/Synchrony_features/Parameter_selection/data/ws_125_dynamic_features_both_conditions.pkl"
    fp = os.path.join(REPO, sync)
    if os.path.isfile(fp):
        print(f"--- {sync} ({human(os.path.getsize(fp))}) ---")
        try:
            with open(fp, "rb") as f:
                obj = pickle.load(f)
            describe(obj, prefix="  ", max_depth=2)
        except Exception:
            print("  [PROBE-ERR-03] 加载失败:")
            traceback.print_exc()
    else:
        print("  [缺失] 未找到")

    print("\n[PROBE-DONE] 探测完成, 请把以上完整输出发回给虎博")

if __name__ == "__main__":
    main()
