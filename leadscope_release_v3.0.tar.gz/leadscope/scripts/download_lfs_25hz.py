#!/usr/bin/env python3
"""
Bigand 25Hz LFS 文件下载器 — 绕过 git lfs pull 的网络问题。

原理: Git LFS 指针文件里存了 sha256 oid 和 size, 直接调 GitHub 的 LFS
Batch API (公开仓库免认证) 拿到 S3 预签名 URL, 再用 curl 下载 + 校验。

为什么需要它: `git lfs pull` 在 autodl 上常失败, 因为 LFS 实际下载走
github-cloud.s3.amazonaws.com, 学术代理未必放行这个 AWS 域名;
而 batch API (github.com) 通常能通, 拿到的 S3 URL 直连或走代理下载更可控。

用法:
  cd /root/autodl-tmp/leadscope
  python scripts/download_lfs_25hz.py                       # 默认仓库路径
  python scripts/download_lfs_25hz.py --repo /path/to/repo   # 指定仓库
  python scripts/download_lfs_25hz.py --force               # 已下载也重下

前置: 若 autodl 需学术代理, 先 source /etc/network_turbo (curl 自动读 http_proxy)

错误标记:
  [LFS-ERR-01] 没找到 LFS 指针文件
  [LFS-ERR-02] batch API 请求失败 (github.com 不通 / 私有仓库需 token)
  [LFS-ERR-03] S3 下载失败 (代理不放行 github-cloud.s3.amazonaws.com)
  [LFS-ERR-04] sha256/size 校验失败 (下载不完整或被篡改)
"""

import argparse
import glob
import hashlib
import json
import os
import re
import subprocess
import sys

REPO_DEFAULT = "/root/autodl-tmp/Dyadic-dance-coordination"
GITHUB_REPO = "TheoPulse/Dyadic-dance-coordination"
LFS_API = f"https://github.com/{GITHUB_REPO}.git/info/lfs/objects/batch"


def parse_pointer(path):
    """解析 Git LFS 指针文本, 返回 (oid_sha256, size) 或 None。"""
    with open(path, "rb") as f:
        data = f.read().decode("utf-8", "replace")
    m = re.search(r"oid sha256:([0-9a-f]{64})", data)
    s = re.search(r"size (\d+)", data)
    if not m or not s:
        return None
    return m.group(1), int(s.group(1))


def find_pointers(repo):
    """递归找所有 *25hz*.pkl 指针文件 (<500B 的视为指针)。"""
    pointers = []
    for p in glob.glob(os.path.join(repo, "**", "*25hz*.pkl"), recursive=True):
        if os.path.getsize(p) < 500:
            parsed = parse_pointer(p)
            if parsed:
                pointers.append((p, parsed[0], parsed[1]))
    return pointers


def batch_api(objects, timeout=30):
    """调 GitHub LFS Batch API, 返回 {oid: download_url}。公开仓库免认证。"""
    import urllib.request
    body = json.dumps({
        "operation": "download",
        "transfers": ["basic"],
        "objects": [{"oid": f"sha256:{o}", "size": s} for o, s in objects],
    }).encode("utf-8")
    req = urllib.request.Request(LFS_API, data=body, method="POST", headers={
        "Accept": "application/vnd.git-lfs+json",
        "Content-Type": "application/vnd.git-lfs+json",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        result = json.loads(resp.read().decode("utf-8"))
    urls = {}
    for obj in result.get("objects", []):
        oid = obj["oid"].split(":")[1]
        if "error" in obj:
            print(f"  [LFS API] 对象错误: {obj['error'].get('message', obj['error'])}")
            continue
        act = obj.get("actions", {})
        if "download" in act:
            urls[oid] = act["download"]["href"]
    return urls


def curl_download(url, dest, expected_size, expected_sha):
    """curl 下载 (支持续传 -C -) + sha256/size 双校验。"""
    tmp = dest + ".part"
    # 已有 .part 则续传
    cmd = ["curl", "-fL", "--retry", "3", "--retry-delay", "5",
           "-C", "-", "-o", tmp, url]
    print(f"  curl 下载 {expected_size / 1e6:.0f}MB → {os.path.basename(tmp)}")
    r = subprocess.run(cmd)
    if r.returncode != 0:
        print(f"  [LFS-ERR-03] curl 退出码 {r.returncode} (S3 域名可能不通)")
        return False
    # size 校验
    actual = os.path.getsize(tmp)
    if actual != expected_size:
        print(f"  [LFS-ERR-04] size 不匹配: got {actual}, want {expected_size}")
        return False
    # sha256 校验
    h = hashlib.sha256()
    with open(tmp, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    if h.hexdigest() != expected_sha:
        print(f"  [LFS-ERR-04] sha256 不匹配 (文件损坏?)")
        return False
    os.replace(tmp, dest)
    return True


def verify_pickle(path):
    """pickle.load 验证文件可被加载。"""
    import pickle
    try:
        with open(path, "rb") as f:
            obj = pickle.load(f)
        kind = type(obj).__name__
        if isinstance(obj, tuple) and len(obj) == 2:
            x, y = obj
            shape = getattr(x, "shape", "?")
            print(f"  pickle OK: {kind} len=2, X.shape={shape}")
            return True
        print(f"  pickle OK: {kind}")
        return True
    except Exception as e:
        print(f"  pickle 加载失败: {e}")
        return False


def net_check():
    """快速网络预检: github.com 和 S3 域名连通性。"""
    print("\n[网络预检]")
    for host in ["github.com", "github-cloud.s3.amazonaws.com"]:
        r = subprocess.run(["curl", "-sI", "-o", "/dev/null", "-w",
                            "%{http_code}", f"https://{host}", "--max-time", "10"],
                           capture_output=True, text=True)
        code = r.stdout.strip() or "FAIL"
        proxy = os.environ.get("https_proxy", os.environ.get("http_proxy", "无"))
        flag = "OK" if code not in ("000", "FAIL") else "不通"
        print(f"  {host}: HTTP {code} ({flag}) [代理: {proxy}]")


def main():
    ap = argparse.ArgumentParser(description="Bigand 25Hz LFS Batch API 下载器")
    ap.add_argument("--repo", default=REPO_DEFAULT, help="Dyadic-dance-coordination 仓库路径")
    ap.add_argument("--force", action="store_true", help="已下载的也重新下载")
    args = ap.parse_args()

    print("=" * 62)
    print("Bigand 25Hz LFS 文件下载器 (Batch API 方案)")
    print("=" * 62)

    net_check()

    # 1. 找指针
    pointers = find_pointers(args.repo)
    if not pointers:
        print(f"\n[LFS-ERR-01] 在 {args.repo} 没找到 25hz LFS 指针文件。")
        print("  确认仓库已 git clone 且含 dyadic_dance/data/*/raw_velocities_ds25hz.pkl")
        return 1
    print(f"\n[1/4] 找到 {len(pointers)} 个 LFS 指针文件:")
    for path, oid, size in pointers:
        done = os.path.getsize(path) > 500 and not parse_pointer(path)
        tag = "已下载" if (done and not args.force) else "待下载"
        print(f"  {os.path.relpath(path, args.repo)}: {size / 1e6:.0f}MB sha256:{oid[:12]}… [{tag}]")

    # 跳过已下载
    todo = [(p, o, s) for p, o, s in pointers
            if args.force or parse_pointer(p) is not None]
    if not todo:
        print("\n所有文件已下载, 用 --force 强制重下。")
        # 仍做 pickle 验证
        print("\n[4/4] pickle 验证:")
        for p, _, _ in pointers:
            print(f"\n  → {os.path.relpath(p, args.repo)}")
            verify_pickle(p)
        return 0

    # 2. batch API
    print(f"\n[2/4] 调用 GitHub LFS Batch API...")
    try:
        urls = batch_api([(o, s) for _, o, s in todo])
    except Exception as e:
        print(f"\n[LFS-ERR-02] batch API 请求失败: {e}")
        print("  诊断: curl -I https://github.com  (github.com 是否通?)")
        print("  私有仓库需在环境变量设 GITHUB_TOKEN")
        return 1
    if not urls:
        print("\n[LFS-ERR-02] 未获取到任何下载 URL。")
        return 1
    print(f"  获取到 {len(urls)}/{len(todo)} 个 S3 预签名 URL ✓")

    # 3. 下载
    print(f"\n[3/4] 下载文件:")
    all_ok = True
    for path, oid, size in todo:
        if oid not in urls:
            print(f"\n  → {os.path.relpath(path, args.repo)}: 无 URL, 跳过")
            all_ok = False
            continue
        print(f"\n  → {os.path.relpath(path, args.repo)}")
        ok = curl_download(urls[oid], path, size, oid)
        if not ok:
            all_ok = False
            print("  ⚠ 下载失败, 见上方错误码")
            print("  降级方案: 若 S3 不通, 尝试配置 git lfs 走代理:")
            print("    git config --global http.proxy http://127.0.0.1:7890")
            print("    git -C " + args.repo + " lfs pull")

    # 4. pickle 验证
    print(f"\n[4/4] pickle 加载验证:")
    for path, _, _ in pointers:
        print(f"\n  → {os.path.relpath(path, args.repo)}")
        verify_pickle(path)

    print("\n" + "=" * 62)
    if all_ok:
        print("[DONE] 全部下载成功! 现在可以跑 25Hz 实验:")
        print(f"  cd /root/autodl-tmp/leadscope")
        print(f"  python scripts/pilot_lag_bigand.py \\")
        print(f"    --file raw_velocities_ds25hz.pkl --hz 25 --max-lag 25 --n-pilot 0")
    else:
        print("[PARTIAL] 部分文件下载失败, 见上方 [LFS-ERR] 标记。")
        print("把本段完整输出发回给虎博, 我给降级方案。")
    print("=" * 62)
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
