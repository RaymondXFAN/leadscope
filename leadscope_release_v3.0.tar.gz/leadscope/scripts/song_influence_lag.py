#!/usr/bin/env python3
"""
Song 对称性对 leader-follower 的影响分析。

科学问题: Bigand 故意给两名舞者听不同音乐打破对称。
  (1) 同歌(song_left==song_right) vs 不同歌, 耦合强度/时滞是否不同?
  (2) A主导率是否随 song_left 变化? (某首歌是否总让听者主导→暗示节奏规整度)

假设: 若不同歌时耦合减弱或leader偏向某方, 验证Bigand设计 + 音乐影响行为发现。

用法:
  cd /root/autodl-tmp/leadscope
  python scripts/song_influence_lag.py                    # 默认 both_cond_only
  python scripts/song_influence_lag.py --data-dir dyadic_dance/data/vis_only
"""

import argparse
import os
import pickle
import sys
import time
import traceback

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from lagcc import lagged_cross_corr   # noqa: E402

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"


def to_np(t):
    if hasattr(t, "detach"):
        t = t.detach().cpu().numpy()
    return np.asarray(t)


def prep_signal(seg, mode="energy"):
    s = np.asarray(seg, dtype=np.float64)
    if mode == "energy":
        return np.sqrt((s ** 2).sum(axis=1, keepdims=True))
    if mode == "raw":
        return s
    if mode == "integrate":
        return np.cumsum(s, axis=0)
    raise ValueError(mode)


def refine_parabola(curve, lags):
    i = int(np.nanargmax(curve))
    if i <= 0 or i >= len(curve) - 1:
        return float(lags[i])
    y0, y1, y2 = curve[i - 1], curve[i], curve[i + 1]
    denom = y0 - 2 * y1 + y2
    if abs(denom) < 1e-12:
        return float(lags[i])
    delta = 0.5 * (y0 - y2) / denom
    if not np.isfinite(delta) or abs(delta) > 1:
        return float(lags[i])
    return float(lags[i] + delta)


def estimate_one(A, B, max_lag, mode="energy"):
    a, b = prep_signal(A, mode), prep_signal(B, mode)
    n = min(a.shape[0], b.shape[0])
    a, b = a[:n], b[:n]
    curves = []
    for d in range(a.shape[1]):
        try:
            _, c, _ = lagged_cross_corr(a[:, d], b[:, d], max_lag)
            curves.append(c)
        except ValueError:
            continue
    if not curves:
        return 0.0, 0.0
    curve = np.nanmean(np.vstack(curves), axis=0)
    lags = np.arange(-max_lag, max_lag + 1)
    return refine_parabola(curve, lags), float(np.nanmax(curve))


def main():
    ap = argparse.ArgumentParser(description="Song 对称性 leader-follower 分析")
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--data-dir", default="dyadic_dance/data/both_cond_only")
    ap.add_argument("--file", default="raw_velocities_ds.pkl")
    ap.add_argument("--hz", type=float, default=5.0)
    ap.add_argument("--sub-window", type=int, default=50)
    ap.add_argument("--max-lag", type=int, default=5)
    ap.add_argument("--mode", default="energy")
    ap.add_argument("--jobs", type=int, default=-1)
    ap.add_argument("--out", default="/root/autodl-tmp/leadscope/results/song_influence.csv")
    a = ap.parse_args()

    ms = 1000.0 / a.hz
    print("=" * 62)
    print(f"Song 对称性 leader-follower 分析 ({a.data_dir.split('/')[-1]})")
    print(f"子段{a.sub_window}帧={a.sub_window/a.hz:.0f}s, max_lag±{a.max_lag}帧=±{a.max_lag*ms:.0f}ms, 表征={a.mode}")
    print("=" * 62)

    fp = os.path.join(a.repo, a.data_dir, a.file)
    with open(fp, "rb") as f:
        head = f.read(200)
    if head.startswith(b"version https://git-lfs"):
        print("[SONG-ERR] LFS 指针未下载"); sys.exit(1)
    t0 = time.time()
    try:
        with open(fp, "rb") as f:
            X, y = pickle.load(f)
    except Exception:
        print("[SONG-ERR] pkl 加载失败:"); traceback.print_exc(); sys.exit(1)
    X, y = to_np(X), to_np(y)
    print(f"[SONG-OK] 加载({time.time()-t0:.1f}s) X{X.shape} y{y.shape}")
    N, C, T = X.shape
    half = C // 2
    n_sub = T // a.sub_window
    print(f"  N={N} 双人{half}通道 T={T}({T/a.hz:.1f}s) 切{n_sub}子段")

    song_l = y[:, 3].astype(int)
    song_r = y[:, 4].astype(int)
    sym = (song_l == song_r)  # 同歌mask
    print(f"  song_left 取值 {sorted(np.unique(song_l))}, song_right {sorted(np.unique(song_r))}")
    print(f"  同歌(song_l==song_r): {sym.sum()} 窗口 ({100*sym.mean():.1f}%)")
    print(f"  不同歌: {(~sym).sum()} 窗口 ({100*(~sym).mean():.1f}%)")

    A_all, B_all = X[:, :half, :], X[:, half:2*half, :]
    tasks = []
    for wi in range(N):
        for si in range(n_sub):
            s, e = si*a.sub_window, (si+1)*a.sub_window
            tasks.append((A_all[wi, :, s:e].T, B_all[wi, :, s:e].T, wi, si))

    print(f"\n[SONG-INFO] 估计 {len(tasks)} 子段时滞...")
    try:
        from joblib import Parallel, delayed
        def _w(t):
            try:
                lg, pk = estimate_one(t[0], t[1], a.max_lag, a.mode)
            except Exception:
                lg, pk = 0.0, 0.0
            return lg, pk, t[2], t[3]
        res = Parallel(n_jobs=a.jobs)(delayed(_w)(t) for t in tasks)
    except ImportError:
        res = []
        for t in tasks:
            lg, pk = estimate_one(t[0], t[1], a.max_lag, a.mode)
            res.append((lg, pk, t[2], t[3]))
    lags = np.array([r[0] for r in res])
    peaks = np.array([r[1] for r in res])
    widx = np.array([r[2] for r in res])
    sidx = np.array([r[3] for r in res])
    print(f"  完成({time.time()-t0:.1f}s)")

    # 子段→窗口的 song 对称性
    sub_sym = sym[widx]
    sub_songl = song_l[widx]
    sub_songr = song_r[widx]

    # ---- 分析1: 同歌 vs 不同歌 ----
    print(f"\n== 分析1: 同歌 vs 不同歌 (耦合与时滞) ==")
    same_pk = peaks[sub_sym]
    diff_pk = peaks[~sub_sym]
    same_lag = lags[sub_sym] * ms
    diff_lag = lags[~sub_sym] * ms
    print(f"  同歌  : n={len(same_pk):4d}, peak_r {same_pk.mean():.4f}±{same_pk.std():.3f}, "
          f"|τ| {np.abs(same_lag).mean():.1f}ms, τ均值 {same_lag.mean():+.1f}ms, A主导{100*(same_lag>0).mean():.0f}%")
    print(f"  不同歌: n={len(diff_pk):4d}, peak_r {diff_pk.mean():.4f}±{diff_pk.std():.3f}, "
          f"|τ| {np.abs(diff_lag).mean():.1f}ms, τ均值 {diff_lag.mean():+.1f}ms, A主导{100*(diff_lag>0).mean():.0f}%")
    if len(same_pk) >= 3 and len(diff_pk) >= 3:
        try:
            from scipy.stats import mannwhitneyu, ttest_ind
            U_pk, p_pk = mannwhitneyu(same_pk, diff_pk, alternative="two-sided")
            t_lag, p_lag = ttest_ind(np.abs(same_lag), np.abs(diff_lag))
            pooled = np.sqrt(same_pk.var()/len(same_pk) + diff_pk.var()/len(diff_pk)) + 1e-12
            d_pk = (same_pk.mean() - diff_pk.mean()) / pooled
            print(f"  peak_r: Mann-Whitney U={U_pk:.0f}, p={p_pk:.4f}, Cohen's d={d_pk:+.3f} (同-异)")
            print(f"  |τ|: t检验 t={t_lag:.3f}, p={p_lag:.4f}")
            if p_pk < 0.05:
                print(f"  ★ 同歌vs不同歌耦合强度差异显著(p<.05) → 音乐对称性影响双人协调")
            if p_lag < 0.05:
                print(f"  ★ 同歌vs不同歌时滞幅度差异显著(p<.05)")
        except Exception as e:
            print(f"  统计检验失败: {e}")

    # ---- 分析2: A主导率随 song_left 变化 ----
    print(f"\n== 分析2: A主导率随 A 所听歌曲 (song_left) 变化 ==")
    print(f"  {'song_left':>9} {'n':>5} {'peak_r':>8} {'A主导%':>8} {'τ均值ms':>9} 含义")
    rows_song = []
    for sl in sorted(np.unique(sub_songl)):
        m = sub_songl == sl
        if m.sum() < 10:
            continue
        a_dom = 100 * (lags[m] > 0).mean()
        pk = peaks[m].mean()
        tm = lags[m].mean() * ms
        # A主导>50%说明听这首歌的A更常主导
        tag = "A倾向主导" if a_dom > 52 else ("B倾向主导" if a_dom < 48 else "对称")
        rows_song.append((sl, m.sum(), pk, a_dom, tm, tag))
        print(f"  {sl:>9} {m.sum():>5} {pk:>8.4f} {a_dom:>7.0f}% {tm:>+8.1f} {tag}")
    # 卡方: A主导率是否随song_left变化
    if len(rows_song) >= 3:
        try:
            from scipy.stats import chi2_contingency
            cont = np.array([[int((lags[sub_songl==sl]>0).sum()),
                              int((lags[sub_songl==sl]<=0).sum())] for sl, _, _, _, _, _ in rows_song])
            chi2, pchi, _, _ = chi2_contingency(cont)
            print(f"  卡方检验: χ²={chi2:.2f}, p={pchi:.4f} (A主导率是否随song_left变化)")
            if pchi < 0.05:
                print(f"  ★ A主导率随歌曲显著变化 → 某些歌让听者更易主导(可能节奏更规整)")
        except Exception as e:
            print(f"  卡方检验失败: {e}")

    # ---- 分析3: 不对称时 leader 偏向 ----
    print(f"\n== 分析3: 不同歌时 leader 是否偏向某方 ==")
    diff_mask = ~sub_sym
    if diff_mask.sum() >= 30:
        # 看 song_left≠song_right 时, A主导率
        a_dom_diff = 100 * (lags[diff_mask] > 0).mean()
        print(f"  不同歌时 A主导率: {a_dom_diff:.1f}% (50%=对称, 偏离说明leader非随机)")
        # 按对称差分组
        for sl in sorted(np.unique(sub_songl[diff_mask])):
            for sr in sorted(np.unique(sub_songr[diff_mask])):
                if sl == sr:
                    continue
                m = diff_mask & (sub_songl == sl) & (sub_songr == sr)
                if m.sum() >= 15:
                    ad = 100 * (lags[m] > 0).mean()
                    print(f"    A听{sl} B听{sr}: n={m.sum():3d}, A主导{ad:.0f}%, τ{lags[m].mean()*ms:+.0f}ms")

    # ---- 分析4: 错配对对照 (全局) ----
    print(f"\n== 分析4: 错配对对照 (验证配对结构) ==")
    rng = np.random.default_rng(0)
    null_peaks = []
    null_tasks = []
    for k in range(min(500, len(res))):
        wi = widx[k]; si = sidx[k]
        for _ in range(20):
            j = int(rng.integers(0, N))
            if j != wi:
                break
        s, e = si*a.sub_window, (si+1)*a.sub_window
        null_tasks.append((A_all[wi,:,s:e].T, B_all[j,:,s:e].T))
    try:
        from joblib import Parallel, delayed
        nres = Parallel(n_jobs=a.jobs)(delayed(lambda t: estimate_one(t[0],t[1],a.max_lag,a.mode)[1])(_t) for _t in null_tasks)
        null_peaks = np.array(nres)
    except ImportError:
        null_peaks = np.array([estimate_one(t[0],t[1],a.max_lag,a.mode)[1] for t in null_tasks])
    pooled = np.sqrt(peaks.var()/len(peaks) + null_peaks.var()/max(len(null_peaks),1)) + 1e-12
    d = (peaks.mean() - null_peaks.mean()) / pooled
    print(f"  真实 peak_r {peaks.mean():.4f} vs 错配 {null_peaks.mean():.4f}, Cohen's d={d:.2f}")
    if d > 2:
        print(f"  ✓ 双人配对结构真实 (d>2)")

    # 保存
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    hdr = "window,sub_idx,song_left,song_right,same_song,label,dyad,lag_ms,peak_r"
    out = [hdr]
    for k in range(len(res)):
        out.append(f"{widx[k]},{sidx[k]},{sub_songl[k]},{sub_songr[k]},{int(sub_sym[k])},"
                   f"{int(y[widx[k],0])},{int(y[widx[k],1])},{lags[k]*ms:.1f},{peaks[k]:.4f}")
    with open(a.out, "w") as f:
        f.write("\n".join(out))
    print(f"\n[SONG-DONE] 保存: {a.out} ({len(out)-1}行)")
    print("  请把本段完整输出发回给虎博")


if __name__ == "__main__":
    main()
