#!/usr/bin/env python3
"""
滑窗时变时滞分析 — 验证"37秒长窗口导致时滞散布"假设。

原理: pilot 用 186帧=37秒 整窗估计单一时滞, energy 包络在这么长的窗口里
多峰且平坦, argmax 不稳定 → 时滞摊到 ±3000ms 均匀分布。
本脚本把每个窗口切成 sub_window 帧的子段, 每段独立估计时滞, 看:
  (a) 短窗口下 |τ| 是否收窄到 100-500ms (人类 leader-follower 合理范围)
  (b) 条件间统计差异是否重新出现
  (c) 时滞随子段索引的变化 (leader 角色切换)

用法:
  cd /root/autodl-tmp/leadscope
  python scripts/sw_subwindow_lag.py                       # 默认 sub_window=50(10s)
  python scripts/sw_subwindow_lag.py --sub-window 30      # 6秒子段
  python scripts/sw_subwindow_lag.py --sub-window 50 --max-lag 5 --mode energy
"""

import argparse
import os
import pickle
import sys
import time
import traceback

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from lagcc import lagged_cross_corr   # noqa: E402

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"
Y_COLS = ["label", "dyad_number", "trial", "song_left", "song_right", "id"]


def to_np(t):
    if hasattr(t, "detach"):
        t = t.detach().cpu().numpy()
    return np.asarray(t)


def prep_signal(seg, mode):
    s = np.asarray(seg, dtype=np.float64)
    if mode == "raw":
        return s
    if mode == "diff":
        return np.diff(s, axis=0)
    if mode == "integrate":
        return np.cumsum(s, axis=0)
    if mode == "energy":
        return np.sqrt((s ** 2).sum(axis=1, keepdims=True))
    raise ValueError(mode)


def refine_parabola(curve, lags):
    i = int(np.nanargmax(curve))
    if i <= 0 or i >= len(curve) - 1:
        return float(lags[i])
    y0, y1, y2 = curve[i - 1], curve[i], curve[i + 1]
    denom = y0 - 2 * y1 + y2
    if abs(denom) < 1e-12:
        return float(lags[i])
    delta = 0.5 * (y0 - y2) / denom
    if not np.isfinite(delta) or abs(delta) > 1:
        return float(lags[i])
    return float(lags[i] + delta)


def estimate_one(A, B, max_lag, mode):
    """单段时滞估计, 返回 (lag_float, peak_r)。A,B: (T_seg, D)"""
    a, b = prep_signal(A, mode), prep_signal(B, mode)
    n = min(a.shape[0], b.shape[0])
    a, b = a[:n], b[:n]
    curves = []
    for d in range(a.shape[1]):
        try:
            _, c, _ = lagged_cross_corr(a[:, d], b[:, d], max_lag)
            curves.append(c)
        except ValueError:
            continue
    if not curves:
        return 0.0, 0.0
    curve = np.nanmean(np.vstack(curves), axis=0)
    lags = np.arange(-max_lag, max_lag + 1)
    lag_f = refine_parabola(curve, lags)
    return lag_f, float(np.nanmax(curve))


def main():
    ap = argparse.ArgumentParser(description="滑窗时变时滞分析")
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--data-dir", default="dyadic_dance/data/both_cond_only")
    ap.add_argument("--file", default="raw_velocities_ds.pkl")
    ap.add_argument("--hz", type=float, default=5.0)
    ap.add_argument("--sub-window", type=int, default=50, help="子段帧数 (50=10s@5Hz)")
    ap.add_argument("--max-lag", type=int, default=5, help="子段内最大滞后帧数")
    ap.add_argument("--mode", default="energy", help="信号表征")
    ap.add_argument("--n-pilot", type=int, default=0, help="0=全量, >0抽样窗口数")
    ap.add_argument("--jobs", type=int, default=-1)
    ap.add_argument("--out", default="/root/autodl-tmp/leadscope/results/subwindow_lag.csv")
    a = ap.parse_args()

    ms_per_frame = 1000.0 / a.hz
    sub_sec = a.sub_window / a.hz
    print("=" * 62)
    print(f"滑窗时变时滞分析 (子段={a.sub_window}帧={sub_sec:.1f}s, max_lag=±{a.max_lag}帧=±{a.max_lag*ms_per_frame:.0f}ms)")
    print("=" * 62)

    fp = os.path.join(a.repo, a.data_dir, a.file)
    print(f"[SW-INFO] 数据: {fp}")
    # LFS 检测
    with open(fp, "rb") as f:
        head = f.read(200)
    if head.startswith(b"version https://git-lfs"):
        print(f"[SW-ERR] LFS 指针未下载"); sys.exit(1)
    t0 = time.time()
    try:
        with open(fp, "rb") as f:
            X, y = pickle.load(f)
    except Exception:
        print("[SW-ERR] pkl 加载失败:"); traceback.print_exc(); sys.exit(1)
    X, y = to_np(X), to_np(y)
    print(f"[SW-OK] 加载 ({time.time()-t0:.1f}s) X{X.shape} y{y.shape}")
    N, C, T = X.shape
    half = C // 2
    n_sub = T // a.sub_window
    rem = T % a.sub_window
    print(f"  N={N} C={C}(每人{half}) T={T}({T/a.hz:.1f}s) → 切成 {n_sub} 子段×{a.sub_window}帧 + 余{rem}帧")
    print(f"  条件 label: {dict(zip(*[x.tolist() for x in np.unique(y[:,0], return_counts=True)]))}")

    idx = np.arange(N) if a.n_pilot <= 0 else \
        np.linspace(0, N-1, min(a.n_pilot, N)).astype(int)
    labels = y[:, 0]
    dyads = y[:, 1]

    # 切子段 + 估计
    A_all, B_all = X[:, :half, :], X[:, half:2*half, :]
    sub_lags, sub_peaks, sub_meta = [], [], []  # meta: (window_idx, sub_idx, label, dyad)
    t0 = time.time()
    tasks = []
    for wi in idx:
        for si in range(n_sub):
            s, e = si*a.sub_window, (si+1)*a.sub_window
            tasks.append((A_all[wi, :, s:e].T, B_all[wi, :, s:e].T, wi, si, int(labels[wi]), int(dyads[wi])))
    print(f"\n[SW-INFO] 估计 {len(tasks)} 子段时滞...")
    try:
        from joblib import Parallel, delayed
        def _w(t):
            try:
                return estimate_one(t[0], t[1], a.max_lag, a.mode) + (t[2], t[3], t[4], t[5])
            except Exception:
                return (0.0, 0.0, t[2], t[3], t[4], t[5])
        res = Parallel(n_jobs=a.jobs)(delayed(_w)(t) for t in tasks)
    except ImportError:
        res = [estimate_one(t[0], t[1], a.max_lag, a.mode) + (t[2], t[3], t[4], t[5]) for t in tasks]
    dt = time.time() - t0
    sub_lags = np.array([r[0] for r in res])
    sub_peaks = np.array([r[1] for r in res])
    widx = np.array([r[2] for r in res])
    sidx = np.array([r[3] for r in res])
    slabel = np.array([r[4] for r in res])
    sdyad = np.array([r[5] for r in res])
    print(f"  完成 ({dt:.1f}s, {len(tasks)/max(dt,1e-9):.0f} 段/秒)")

    # 显著性阈值 (错配对)
    print(f"\n== 零假设 (跨 dyad 错配子段) ==")
    rng = np.random.default_rng(0)
    null_peaks = []
    null_tasks = []
    for k in range(len(res)):
        wi = widx[k]; si = sidx[k]
        for _ in range(20):
            j = int(rng.integers(0, N))
            if dyads[j] != dyads[wi]:
                break
        else:
            j = int(rng.integers(0, N))
        s, e = si*a.sub_window, (si+1)*a.sub_window
        null_tasks.append((A_all[wi,:,s:e].T, B_all[j,:,s:e].T))
    try:
        from joblib import Parallel, delayed
        nres = Parallel(n_jobs=a.jobs)(delayed(lambda t: estimate_one(t[0],t[1],a.max_lag,a.mode))(_t) for _t in null_tasks)
        null_peaks = np.array([r[1] for r in nres])
    except ImportError:
        null_peaks = np.array([estimate_one(t[0],t[1],a.max_lag,a.mode)[1] for t in null_tasks])
    thr = float(np.percentile(null_peaks, 95))
    sig = sub_peaks > thr
    pooled = np.sqrt(sub_peaks.var()/len(sub_peaks) + null_peaks.var()/max(len(null_peaks),1)) + 1e-12
    d = (sub_peaks.mean() - null_peaks.mean()) / pooled
    print(f"  真实 peak_r {sub_peaks.mean():.4f} vs 错配 {null_peaks.mean():.4f}, d={d:.2f}, 阈值{thr:.4f}")
    print(f"  显著子段: {int(sig.sum())}/{len(sig)} ({100*sig.mean():.1f}%)")

    # 时滞分布对比 (全长 vs 子段)
    print(f"\n== 时滞分布对比 (子段级, 仅显著) ==")
    Ls = sub_lags[sig] * ms_per_frame
    print(f"  子段({a.sub_window}帧={sub_sec:.0f}s): |τ|均值 {np.abs(Ls).mean():.1f}ms, "
          f"τ均值 {Ls.mean():+.1f}ms, 中位数 {np.median(Ls):+.1f}ms, std {Ls.std():.1f}ms")
    print(f"  (对比 pilot 全长窗口 |τ|均值 1146ms — 若子段明显更窄, 验证窗口过长假设)")

    # 时滞分布直方图
    if len(Ls) >= 10:
        lo, hi = -a.max_lag*ms_per_frame, a.max_lag*ms_per_frame
        bins = np.linspace(lo, hi, 11)
        cnt, edges = np.histogram(Ls, bins=bins)
        print(f"\n  子段时滞直方图 (ms):")
        for c, l, h in zip(cnt, edges[:-1], edges[1:]):
            if c: print(f"    [{l:>6.0f}, {h:>6.0f}): {c:>4} {'#'*int(30*c/max(cnt.max(),1))}")

    # 条件间统计检验
    print(f"\n== 条件间统计检验 (子段级) ==")
    for lab in [0, 1]:
        m = sig & (slabel == lab)
        ll = sub_lags[m] * ms_per_frame
        if m.sum() >= 3:
            print(f"  label={lab}: n={int(m.sum()):3d}, τ均值{ll.mean():+8.1f}ms, "
                  f"中位数{np.median(ll):+8.1f}ms, |τ|均值{np.abs(ll).mean():6.1f}ms, "
                  f"A主导{100*(ll>0).mean():.0f}%")
    g0 = sub_lags[sig & (slabel==0)] * ms_per_frame
    g1 = sub_lags[sig & (slabel==1)] * ms_per_frame
    if len(g0) >= 3 and len(g1) >= 3:
        try:
            from scipy.stats import mannwhitneyu
            U, p = mannwhitneyu(g0, g1, alternative="two-sided")
        except Exception:
            from math import erf, sqrt
            nx, ny = len(g0), len(g1)
            ranks = np.argsort(np.argsort(np.concatenate([g0,g1])))+1
            U = ranks[:nx].sum() - nx*(nx+1)/2
            mu, sg = nx*ny/2, np.sqrt(nx*ny*(nx+ny+1)/12)
            z = (U-mu)/sg if sg>0 else 0
            p = 2*(1-0.5*(1+erf(abs(z)/sqrt(2))))
        r = 1 - 2*U/(len(g0)*len(g1))
        print(f"  Mann-Whitney U={U:.0f}, p={p:.4f}, r={r:+.3f}")
        if p < 0.05:
            print(f"  ★ 条件差异显著 (p<.05)")

    # 时变: 时滞随子段索引的变化 (leader 切换)
    print(f"\n== 时变时滞曲线 (按子段索引, 看leader切换) ==")
    for si in range(n_sub):
        m = sig & (sidx == si)
        if m.sum() >= 5:
            ll = sub_lags[m] * ms_per_frame
            print(f"  段{si} ({si*sub_sec:.0f}-{(si+1)*sub_sec:.0f}s): n={int(m.sum()):3d}, "
                  f"τ均值{ll.mean():+7.1f}ms, A主导{100*(ll>0).mean():3.0f}%, peak_r {sub_peaks[m].mean():.3f}")

    # dyad 内时滞稳定性 (子段级)
    print(f"\n== dyad 时滞稳定性 (子段级, n≥5) ==")
    for d in np.unique(sdyad):
        m = sig & (sdyad == d)
        if m.sum() >= 5:
            ll = sub_lags[m] * ms_per_frame
            cv = ll.std()/(abs(ll.mean())+1)
            print(f"  dyad {int(d):>3}: n={int(m.sum()):2d}, τ均值{ll.mean():+7.1f}ms, "
                  f"std{ll.std():6.1f}, CV{cv:5.2f}")

    # 保存
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    hdr = "window,sub_idx,label,dyad,lag_frames,lag_ms,peak_r,significant"
    out = [hdr]
    for k in range(len(res)):
        out.append(f"{widx[k]},{sidx[k]},{slabel[k]},{sdyad[k]},{sub_lags[k]:.3f},"
                   f"{sub_lags[k]*ms_per_frame:.1f},{sub_peaks[k]:.4f},{int(sig[k])}")
    with open(a.out, "w") as f:
        f.write("\n".join(out))
    print(f"\n[SW-DONE] 保存: {a.out} ({len(out)-1} 行)")
    print("  请把本段完整输出发回给虎博")


if __name__ == "__main__":
    main()
