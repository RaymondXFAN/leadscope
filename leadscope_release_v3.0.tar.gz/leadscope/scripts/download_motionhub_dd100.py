#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
MotionHub (HuggingFace) 子集下载脚本 v1.1
用途: AutoDL 学术加速代理只白名单 github/huggingface;
      MotionHub (ZeyuLing/MotionHub, ECCV 2026 VersatileMotion 配套数据) 含多个双人交互
      子集 (InterX/Hi4D/CHI3D/InterHuman, 均为 SMPL-H npz), 走 HF 通道可在服务器直下,
      可作为 DD100 之外的补充双人数据.
注意: v1.0 的 404 根因是 HF 上不存在顶层 subsets/ 目录, 各子集直接挂在仓库顶层
      (如 GRAB/, aist/), v1.1 已改为先列顶层目录再按子集名递归下载.
运行: cd /root/autodl-tmp/leadscope && python scripts/download_motionhub_dd100.py --list
      python scripts/download_motionhub_dd100.py --subset InterX --dry
      python scripts/download_motionhub_dd100.py --subset InterX        # 实际下载
目标目录: /root/autodl-tmp/data/motionhub_<subset>/

技术要点:
  - 学术代理对 HTTPS 做自签名证书中转, 需跳过证书校验 (ssl unverified)
  - 代理地址自动从 /etc/network_turbo 提取 (v1.3 同款正则)
  - HF tree API 分页 (每页1000条, Link header 翻页), 已处理
  - 断点续传 (.part)
"""
import argparse
import json
import os
import re
import ssl
import sys
import urllib.request

REPO = "ZeyuLing/MotionHub"
API_BASE = f"https://huggingface.co/api/datasets/{REPO}/tree/main"
RAW_BASE = f"https://huggingface.co/datasets/{REPO}/resolve/main/"
TURBO_FILE = "/etc/network_turbo"
# 我们关心的双人交互子集候选 (大小写不敏感匹配)
PATTERNS = ("interx", "inter_x", "hi4d", "chi3d", "interhuman", "dd100", "duolando")


def read_turbo_proxy():
    try:
        with open(TURBO_FILE) as f:
            text = f.read()
        m = re.search(r"https?://[0-9a-zA-Z.\-]+:[0-9]+", text)
        if m:
            return m.group(0)
    except OSError:
        pass
    for env in ("https_proxy", "http_proxy"):
        v = os.environ.get(env, "").strip()
        if v.startswith(("http://", "https://")) and " " not in v:
            return v
    return None


def make_opener(proxy):
    ctx = ssl._create_unverified_context()   # 学术代理自签名证书
    if proxy:
        return urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": proxy, "https": proxy}),
            urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=ctx))


def fetch_tree_page(opener, url):
    """请求一页 tree API; 返回 (items, next_url)"""
    req = urllib.request.Request(url, headers={"User-Agent": "leadscope/1.1"})
    with opener.open(req, timeout=60) as r:
        items = json.loads(r.read().decode())
        link = r.headers.get("Link", "")   # 形如 <url>; rel="next"
    next_url = None
    m = re.search(r'<([^>]+)>;\s*rel="next"', link)
    if m:
        next_url = m.group(1)
    return items, next_url


def fetch_tree(opener, path, recursive=True):
    """完整拉取一个路径的文件树 (自动翻页), 返回 [(path, size_mb), ...]"""
    url = f"{API_BASE}/{path}" + ("?recursive=true" if recursive else "")
    out, page_n = [], 0
    try:
        while url:
            items, url = fetch_tree_page(opener, url)
            page_n += 1
            for it in items:
                if it.get("type") != "file":
                    continue
                size = it.get("size", 0) or (it.get("lfs") or {}).get("size", 0)
                out.append((it["path"], size / 1024 / 1024))
        print(f"[MH-INFO] {path}: {page_n} 页, {len(out)} 个文件")
        return out
    except Exception as e:
        print(f"[MH-ERR-01] 获取 HF 文件树失败: {e}")
        print(f"  排查: 1) 确认已 source /etc/network_turbo (脚本会自动读代理)")
        print(f"        2) 把本行发回给虎博 | 请求路径: {path}")
        return None


def download(opener, rel_path, data_dir):
    """单文件断点续传下载; HF 大文件走 lfs resolve 会 302, urllib 自动跟随"""
    full = os.path.join(data_dir, rel_path)
    os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
    if os.path.exists(full) and os.path.getsize(full) > 0:
        return True, "已存在, 跳过"
    url = RAW_BASE + rel_path
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "leadscope/1.1"})
        with opener.open(req, timeout=300) as r, open(full + ".part", "wb") as f:
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
        os.rename(full + ".part", full)
        return True, "OK"
    except Exception as e:
        return False, f"[MH-ERR-02] 下载失败: {e} | {rel_path}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true", help="列出仓库顶层全部子集目录")
    ap.add_argument("--subset", type=str, default=None,
                    help="指定子集名 (先用 --list 查看真实名称)")
    ap.add_argument("--dry", action="store_true", help="只显示将下载的文件, 不实际下载")
    args = ap.parse_args()

    proxy = read_turbo_proxy()
    print(f"[MH-INFO] 学术代理: {proxy or '未检测到(将尝试直连)'}")
    opener = make_opener(proxy)

    if args.list or not args.subset:
        # 列出顶层目录
        top = fetch_tree(opener, "", recursive=False)
        if top is None:
            sys.exit(1)
        # 顶层接口返回的目录 type=directory, 重新拉取原始 JSON 解析
        req = urllib.request.Request(API_BASE, headers={"User-Agent": "leadscope/1.1"})
        with opener.open(req, timeout=60) as r:
            items = json.loads(r.read().decode())
        dirs = sorted(it["path"] for it in items if it.get("type") == "directory")
        print(f"[MH-OK] 仓库顶层共 {len(dirs)} 个目录:")
        for d in dirs:
            tag = "  <== 双人交互候选" if any(pt in d.lower() for pt in PATTERNS) else ""
            print(f"  {d:>24}{tag}")
        if not args.subset:
            print("\n用法: python scripts/download_motionhub_dd100.py --subset <目录名>")
            print("      (InterX/Hi4D/CHI3D/InterHuman 为双人交互候选, 上表带标记)")
        return

    data_dir = f"/root/autodl-tmp/data/motionhub_{args.subset}"
    os.makedirs(data_dir, exist_ok=True)
    files = fetch_tree(opener, args.subset, recursive=True)
    if files is None:
        sys.exit(1)
    total_gb = sum(s for _, s in files) / 1024
    print(f"[MH-INFO] 子集 '{args.subset}': {len(files)} 个文件, {total_gb:.2f} GB")

    if args.dry:
        for p, s in files[:30]:
            print(f"  {s:>9.2f}MB  {p}")
        if len(files) > 30:
            print(f"  ... 其余 {len(files)-30} 个文件省略")
        return

    n_ok = n_skip = n_fail = 0
    for i, (p, s) in enumerate(files, 1):
        print(f"[{i}/{len(files)}] ({s:.1f}MB) {p}")
        ok, msg = download(opener, p, data_dir)
        if msg == "已存在, 跳过":
            n_skip += 1
        elif ok:
            n_ok += 1
        else:
            n_fail += 1
            print(f"    {msg}  <<< 发回此行定位")
    print(f"\n[MH-DONE] 新下载 {n_ok}, 跳过 {n_skip}, 失败 {n_fail}")
    print(f"数据目录: {data_dir}")


if __name__ == "__main__":
    main()
