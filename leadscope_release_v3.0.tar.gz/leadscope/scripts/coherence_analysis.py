#!/usr/bin/env python3
"""
频域相干性分析 — 双人舞蹈协调的频段特异耦合。

科学问题:
  (1) 双人舞蹈协调在哪个频段最强? (0.5-1.5Hz 舞蹈节奏?)
  (2) 视觉条件(label)改变频段耦合吗?
  (3) 同歌 vs 不同歌, 频段耦合如何差异?

原理: 时域 CC 受相位噪声影响, 频域 coherence 能分离不同频段的耦合强度,
是双人运动协调的经典神经/运动科学分析方法。

用法:
  cd /root/autodl-tmp/leadscope
  python scripts/coherence_analysis.py
  python scripts/coherence_analysis.py --data-dir dyadic_dance/data/vis_only
"""

import argparse
import os
import pickle
import sys
import time
import traceback

import numpy as np

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"

# 频段定义 (@5Hz, Nyquist=2.5Hz)
BANDS = {
    "low(0.1-0.5Hz) 慢漂移": (0.1, 0.5),
    "rhythm(0.5-1.5Hz) 舞蹈节奏": (0.5, 1.5),
    "fast(1.5-2.5Hz) 快速动作": (1.5, 2.5),
}


def to_np(t):
    if hasattr(t, "detach"):
        t = t.detach().cpu().numpy()
    return np.asarray(t)


def mean_coherence(A, B, fs, nperseg):
    """A,B: (T, D) 多通道, 返回 (freqs, mean_cohere(D,)) 跨通道平均相干谱。"""
    from scipy.signal import coherence
    D = A.shape[1]
    T = A.shape[0]
    nps = min(nperseg, T)
    coh_sum = None
    freqs = None
    cnt = 0
    for d in range(D):
        try:
            f, c = coherence(A[:, d], B[:, d], fs=fs, nperseg=nps)
            if coh_sum is None:
                freqs = f
                coh_sum = np.zeros_like(c)
            coh_sum += c
            cnt += 1
        except Exception:
            continue
    if cnt == 0:
        return None, None
    return freqs, coh_sum / cnt


def band_integrate(freqs, coh, lo, hi):
    """频段内相干均值。"""
    mask = (freqs >= lo) & (freqs <= hi)
    if mask.sum() == 0:
        return 0.0
    return float(np.mean(coh[mask]))


def main():
    ap = argparse.ArgumentParser(description="频域相干性分析")
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--data-dir", default="dyadic_dance/data/both_cond_only")
    ap.add_argument("--file", default="raw_velocities_ds.pkl")
    ap.add_argument("--hz", type=float, default=5.0)
    ap.add_argument("--nperseg", type=int, default=64, help="FFT 窗长(建议<=T//2, T=186时用64)")
    ap.add_argument("--jobs", type=int, default=-1)
    ap.add_argument("--out", default="/root/autodl-tmp/leadscope/results/coherence.csv")
    a = ap.parse_args()

    print("=" * 62)
    print(f"频域相干性分析 ({a.data_dir.split('/')[-1]})")
    print(f"采样率 {a.hz}Hz, Nyquist {a.hz/2:.2f}Hz, nperseg={a.nperseg}")
    print("=" * 62)

    fp = os.path.join(a.repo, a.data_dir, a.file)
    with open(fp, "rb") as f:
        head = f.read(200)
    if head.startswith(b"version https://git-lfs"):
        print("[COH-ERR] LFS 指针未下载"); sys.exit(1)
    t0 = time.time()
    try:
        with open(fp, "rb") as f:
            X, y = pickle.load(f)
    except Exception:
        print("[COH-ERR] pkl 加载失败:"); traceback.print_exc(); sys.exit(1)
    X, y = to_np(X), to_np(y)
    print(f"[COH-OK] 加载({time.time()-t0:.1f}s) X{X.shape} y{y.shape}")
    N, C, T = X.shape
    half = C // 2
    print(f"  N={N} 双人{half}通道 T={T}({T/a.hz:.1f}s)")

    labels = y[:, 0].astype(int)
    song_l = y[:, 3].astype(int)
    song_r = y[:, 4].astype(int)
    sym = (song_l == song_r)
    print(f"  label: {dict(zip(*[x.tolist() for x in np.unique(labels, return_counts=True)]))}")
    print(f"  同歌 {sym.sum()} 不同歌 {(~sym).sum()}")

    # 计算每窗口的相干谱
    print(f"\n[COH-INFO] 计算 {N} 窗口×{half}通道 相干谱...")
    A_all, B_all = X[:, :half, :], X[:, half:2*half, :]

    def _one(wi):
        return mean_coherence(A_all[wi].T, B_all[wi].T, a.hz, a.nperseg)

    try:
        from joblib import Parallel, delayed
        results = Parallel(n_jobs=a.jobs)(delayed(_one)(wi) for wi in range(N))
    except ImportError:
        results = [_one(wi) for wi in range(N)]

    freqs = results[0][0]
    if freqs is None:
        print("[COH-ERR] 相干计算全失败"); sys.exit(1)
    spectra = np.array([r[1] for r in results if r[1] is not None])
    print(f"  完成({time.time()-t0:.1f}s), 有效 {len(spectra)}/{N}, 频率点 {len(freqs)}")

    # 频段积分
    band_vals = {name: np.array([band_integrate(freqs, s, lo, hi) for s in spectra])
                 for name, (lo, hi) in BANDS.items()}

    # ---- 分析1: 全局频段分布 (哪个频段耦合最强) ----
    print(f"\n== 分析1: 全局频段相干分布 (哪个频段双人耦合最强) ==")
    print(f"  {'频段':<35} {'均值':>8} {'中位数':>8} {'std':>8}")
    order = sorted(BANDS.items(), key=lambda x: -band_vals[x[0]].mean())
    for name, _ in order:
        v = band_vals[name]
        star = " ★最强" if name == order[0][0] else ""
        print(f"  {name:<35} {v.mean():>8.4f} {np.median(v):>8.4f} {v.std():>8.4f}{star}")

    # Friedman 检验: 三频段差异
    if len(spectra) >= 10:
        try:
            from scipy.stats import friedmanchisquare
            fr, p = friedmanchisquare(*[band_vals[n] for n, _ in BANDS.items()])
            print(f"  Friedman 检验: χ²={fr:.2f}, p={p:.4f} (三频段差异)")
            if p < 0.05:
                print(f"  ★ 频段间耦合强度差异显著 → 存在频段特异耦合")
        except Exception as e:
            print(f"  Friedman 检验失败: {e}")

    # ---- 分析2: 视觉条件 (label) 对频段耦合的影响 ----
    print(f"\n== 分析2: 视觉条件 (label) 对频段耦合的影响 ==")
    for name, (lo, hi) in BANDS.items():
        v0 = band_vals[name][labels == 0]
        v1 = band_vals[name][labels == 1]
        print(f"  {name}:")
        print(f"    label=0(无视觉): n={len(v0)}, 均值{v0.mean():.4f}")
        print(f"    label=1(有视觉): n={len(v1)}, 均值{v1.mean():.4f}")
        if len(v0) >= 3 and len(v1) >= 3:
            try:
                from scipy.stats import mannwhitneyu
                U, p = mannwhitneyu(v0, v1, alternative="two-sided")
                r = 1 - 2*U/(len(v0)*len(v1))
                print(f"    Mann-Whitney p={p:.4f}, r={r:+.3f}")
                if p < 0.05:
                    print(f"    ★ 该频段视觉条件差异显著")
            except Exception as e:
                print(f"    检验失败: {e}")

    # ---- 分析3: 同歌 vs 不同歌 频段耦合 ----
    print(f"\n== 分析3: 同歌 vs 不同歌 频段耦合 ==")
    for name, (lo, hi) in BANDS.items():
        vs = band_vals[name][sym]
        vd = band_vals[name][~sym]
        print(f"  {name}:")
        print(f"    同歌  : n={len(vs)}, 均值{vs.mean():.4f}")
        print(f"    不同歌: n={len(vd)}, 均值{vd.mean():.4f}")
        if len(vs) >= 3 and len(vd) >= 3:
            try:
                from scipy.stats import mannwhitneyu
                U, p = mannwhitneyu(vs, vd, alternative="two-sided")
                r = 1 - 2*U/(len(vs)*len(vd))
                print(f"    Mann-Whitney p={p:.4f}, r={r:+.3f}")
                if p < 0.05:
                    print(f"    ★ 该频段同歌vs不同歌差异显著")
            except Exception as e:
                print(f"    检验失败: {e}")

    # ---- 分析4: 频谱形状 (打印均值谱供论文作图) ----
    print(f"\n== 分析4: 均值相干谱 (前20频率点, 供论文作图) ==")
    mean_spec = spectra.mean(axis=0)
    print(f"  {'freq(Hz)':>9} {'coherence':>10}")
    for i in range(0, len(freqs), max(1, len(freqs)//20)):
        print(f"  {freqs[i]:>9.3f} {mean_spec[i]:>10.4f}")

    # 保存 (含 dyad 列, 供 dyad_aggregate_stats.py 聚合)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    dyads = y[:, 1].astype(int)
    hdr = "window,label,dyad,same_song," + ",".join(BANDS.keys()).replace(" ", "")
    out = [hdr]
    for k in range(len(spectra)):
        row = f"{k},{int(labels[k])},{int(dyads[k])},{int(sym[k])}"
        for name in BANDS:
            row += f",{band_vals[name][k]:.4f}"
        out.append(row)
    with open(a.out, "w") as f:
        f.write("\n".join(out))
    print(f"\n[COH-DONE] 保存: {a.out}")
    print("  请把本段完整输出发回给虎博")


if __name__ == "__main__":
    main()
