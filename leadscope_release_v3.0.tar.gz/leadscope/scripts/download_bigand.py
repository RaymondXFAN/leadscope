#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Bigand 数据集下载脚本 v1.3 (三级网络通道自动降级)
运行: cd /root/autodl-tmp/leadscope && python scripts/download_bigand.py --dyad 01
      python scripts/download_bigand.py --all
      python scripts/download_bigand.py --list
      python scripts/download_bigand.py --probe   # 仅测试网络通道
目标目录: /root/autodl-tmp/data/bigand/

v1.2 变更: 直连(dataverse.iit.it被防火墙拒绝) → 自动尝试 AutoDL 学术加速代理
          → 仍失败给出明确错误标记
v1.3 变更: 修复代理地址解析 bug (旧版会把 ' && export ...' 拼进 URL 导致
          'URL can't contain control characters'); 提取失败时回退读环境变量
v1.4 变更: 通道B 增加跳过 SSL 证书校验 (学术加速代理用自签名证书转发
          HTTPS, Python 严格校验会报 self-signed certificate in chain;
          wget 对应加 --no-check-certificate)
通道优先级: A) 直连(绕过代理变量)  B) 学术加速代理(/etc/network_turbo中的地址)
"""
import argparse
import json
import os
import re
import ssl
import subprocess
import sys
import urllib.request

DOI = "doi:10.48557/UR2GBG"
SERVER = "https://dataverse.iit.it"
API_LIST = f"{SERVER}/api/datasets/:persistentId/?persistentId={DOI}"
DATA_DIR = "/root/autodl-tmp/data/bigand"
TURBO_FILE = "/etc/network_turbo"


def read_turbo_proxy():
    """从 /etc/network_turbo 提取代理地址, 失败返回 None

    v1.3 修复: 该文件一行可能同时含 http_proxy/https_proxy 两条 export,
    旧版 split('=')[1] 会把整行 (含 ' && export ...') 当成 URL.
    现在用正则只提取第一个 http(s)://host:port 片段.
    """
    try:
        with open(TURBO_FILE) as f:
            text = f.read()
        m = re.search(r"https?://[0-9a-zA-Z.\-]+:[0-9]+", text)
        if m:
            return m.group(0)
    except OSError:
        pass
    # 兜底: 环境变量里如果已有合法代理地址 (形如 http://x.x.x.x:port)
    for env in ("https_proxy", "http_proxy"):
        v = os.environ.get(env, "").strip()
        if v.startswith(("http://", "https://")) and " " not in v:
            return v
    return None


def try_channel(opener_or_proxy, name, url):
    """尝试一个通道访问 API, 成功返回解析后的 JSON"""
    try:
        if opener_or_proxy is None:          # 通道A: 直连空代理
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        else:                                 # 通道B: 学术加速代理
            proxy = opener_or_proxy
            # 学术代理用自签名证书做 HTTPS 转发, 需跳过证书校验
            # (仅用于下载公开科研数据, 风险可接受)
            ctx = ssl._create_unverified_context()
            opener = urllib.request.build_opener(
                urllib.request.ProxyHandler({"http": proxy, "https": proxy}),
                urllib.request.HTTPSHandler(context=ctx))
        req = urllib.request.Request(url, headers={"User-Agent": "leadscope/1.4"})
        with opener.open(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        print(f"  [通道{name}失败] {e}")
        return None


def probe_and_get_file_list():
    """依次尝试 直连 -> 学术代理, 返回 (files, 通道名) 或 (None, None)"""
    print("[BIGAND-INFO] 通道A: 直连 (绕过代理变量)...")
    channel = "A"
    meta = try_channel(None, "A", API_LIST)
    if meta:
        print("  [通道A成功] 使用直连")
    else:
        proxy = read_turbo_proxy()
        if not proxy:
            print("[BIGAND-ERR-01] 直连失败且未找到学术加速代理配置(/etc/network_turbo)")
            return None, None
        print(f"[BIGAND-INFO] 通道B: 学术加速代理 {proxy} ...")
        meta = try_channel(proxy, "B", API_LIST)
        if not meta:
            print("[BIGAND-ERR-01] 直连与学术代理均无法访问 dataverse.iit.it")
            return None, None
        print("  [通道B成功] 使用学术加速代理")
        channel = "B"

    files = []
    for f in meta["data"]["latestVersion"]["files"]:
        fid = f["dataFile"]["id"]
        path = (f.get("directoryLabel", "").strip("/") + "/"
                + f["dataFile"]["filename"])
        size_mb = f["dataFile"].get("filesize", 0) / 1024 / 1024
        files.append((fid, path, size_mb))
    return files, channel


def wget_one(fid, path, channel, proxy=None):
    """单文件断点续传下载"""
    full = os.path.join(DATA_DIR, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    if os.path.exists(full) and os.path.getsize(full) > 0:
        return True, "已存在, 跳过"
    url = f"{SERVER}/api/access/datafile/{fid}"
    cmd = ["wget", "-c", "-q", "--show-progress", "--timeout=60", "--tries=3",
           "-O", full + ".part"]
    if channel == "A":
        cmd.insert(1, "--no-proxy")          # 直连: 无视环境代理变量
    else:
        cmd += ["--no-check-certificate",      # 学术代理自签名证书
                "-e", f"use_proxy=yes", "-e", f"http_proxy={proxy}",
                "-e", f"https_proxy={proxy}"]  # 走学术代理
    ret = subprocess.call(cmd)
    if ret != 0:
        return False, f"[BIGAND-ERR-{ret:02d}] wget 返回码 {ret}: {path}"
    os.rename(full + ".part", full)
    return True, "OK"


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--list", action="store_true", help="只列出文件清单")
    g.add_argument("--all", action="store_true", help="下载全部")
    g.add_argument("--dyad", type=str, default=None, help="下载指定 dyad, 如 01")
    g.add_argument("--probe", action="store_true", help="仅测试网络通道连通性")
    args = ap.parse_args()

    os.makedirs(DATA_DIR, exist_ok=True)
    files, channel = probe_and_get_file_list()

    if args.probe:
        if files:
            print(f"\n[BIGAND-PROBE-OK] 通道{channel} 可用, 共 {len(files)} 文件, "
                  f"{sum(s for _,_,s in files)/1024:.1f} GB")
        else:
            print("\n[BIGAND-PROBE-FAIL] 所有通道均不可用, 请把上面输出发回给虎博")
            sys.exit(1)
        return

    if files is None:
        print("  排查建议: 把本段完整输出发回给虎博; 同时可手动测试学术代理通道:")
        print(f"    source /etc/network_turbo && curl -v -m 20 {SERVER}/ -o /dev/null")
        sys.exit(1)

    print(f"[BIGAND-OK] 共 {len(files)} 个文件, 总大小 "
          f"{sum(s for _, _, s in files)/1024:.1f} GB, 使用通道{channel}\n")

    if args.list:
        for fid, path, mb in files:
            print(f"  {fid:>7}  {mb:>8.1f}MB  {path}")
        return

    if args.dyad:
        files = [f for f in files if f"/Dyad_{args.dyad}/" in "/" + f[1]
                 or f[1].startswith(f"Dyad_{args.dyad}/")]
        if not files:
            print(f"[BIGAND-ERR-02] 未找到 Dyad_{args.dyad} 的文件, 用 --list 核对目录名")
            sys.exit(1)
        print(f"[BIGAND-INFO] 本次下载 Dyad_{args.dyad}: {len(files)} 个文件, "
              f"{sum(s for _, _, s in files)/1024:.2f} GB\n")

    proxy = read_turbo_proxy() if channel == "B" else None
    n_ok = n_skip = 0
    for i, (fid, path, mb) in enumerate(files, 1):
        print(f"[{i}/{len(files)}] {path} ({mb:.1f}MB)")
        ok, msg = wget_one(fid, path, channel, proxy)
        if msg == "已存在, 跳过":
            n_skip += 1
        elif ok:
            n_ok += 1
        else:
            print(f"    {msg}  <<< 发回此行定位")
    print(f"\n[BIGAND-DONE] 新下载 {n_ok}, 跳过 {n_skip}, 失败 {len(files)-n_ok-n_skip}")
    print(f"数据目录: {DATA_DIR}")


if __name__ == "__main__":
    main()
