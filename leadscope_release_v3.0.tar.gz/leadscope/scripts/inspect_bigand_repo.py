#!/usr/bin/env python3
"""
Bigand 预处理数据仓库体检脚本 v1.0
运行: cd /root/autodl-tmp/leadscope && python scripts/inspect_bigand_repo.py
作用: 盘点 TheoPulse/Dyadic-dance-coordination 仓库结构, 摸清数据格式,
      为 lagcc 管线对接做准备。所有输出带标记, 出错发回给虎博定位。

错误标记约定:
  [INSPECT-ERR-01] 仓库目录不存在 (git clone 未完成或路径不对)
  [INSPECT-ERR-02] 数据文件数量为 0 (clone 可能不完整)
  [INSPECT-ERR-02a] 文件数远少于预期 (若 < 150 个给出警告, 预期约183)
  [INSPECT-ERR-03] 样本文件加载失败 (格式异常, 把 traceback 发回)
"""

import os
import sys
import pickle
import traceback
from collections import Counter

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"
DATA_SUBDIRS = ["dyadic_dance"]      # 候选数据目录, 会自动发现其他
EXPECTED_MIN_FILES = 150             # 预期约 183 个文件

def human(nbytes):
    for unit in ["B", "KB", "MB", "GB"]:
        if nbytes < 1024:
            return f"{nbytes:.1f}{unit}"
        nbytes /= 1024
    return f"{nbytes:.1f}TB"

def main():
    # ---- 1. 仓库存在性 ----
    if not os.path.isdir(REPO):
        print(f"[INSPECT-ERR-01] 仓库不存在: {REPO}")
        print("  排查: cd /root/autodl-tmp && ls -la 确认 clone 是否完成")
        sys.exit(1)
    print(f"[INSPECT-OK] 仓库存在: {REPO}")

    # ---- 2. 顶层结构 ----
    print("\n== 顶层目录结构 (2层) ==")
    for name in sorted(os.listdir(REPO)):
        p = os.path.join(REPO, name)
        if os.path.isdir(p):
            sub = sorted(os.listdir(p))[:10]
            print(f"  [DIR ] {name}/  ({len(os.listdir(p))} 项)")
            for s in sub[:6]:
                print(f"          - {s}")
            if len(sub) > 6:
                print(f"          ... 共{len(sub)}项")
        else:
            print(f"  [FILE] {name}  ({human(os.path.getsize(p))})")

    # ---- 3. 全量文件统计 ----
    ext_counter, all_files, total_size = Counter(), [], 0
    for root, _, files in os.walk(REPO):
        for f in files:
            fp = os.path.join(root, f)
            try:
                sz = os.path.getsize(fp)
            except OSError:
                sz = 0
            all_files.append((fp, sz))
            total_size += sz
            ext_counter[os.path.splitext(f)[1].lower() or "(无后缀)"] += 1

    print(f"\n== 文件统计 ==")
    print(f"  总文件数: {len(all_files)}  (预期约183)")
    print(f"  总大小:   {human(total_size)}  (预期约445MB)")
    print(f"  按后缀:   {dict(ext_counter.most_common(10))}")
    if len(all_files) == 0:
        print("[INSPECT-ERR-02] 0 个文件, clone 不完整, 请删除后重新 clone")
        sys.exit(1)
    if len(all_files) < EXPECTED_MIN_FILES:
        print(f"[INSPECT-ERR-02a] 警告: 文件数 {len(all_files)} < {EXPECTED_MIN_FILES}, "
              f"可能 clone 中断, 建议在仓库目录: git status 检查")

    # ---- 4. 数据文件分布 (重点看 data 类目录) ----
    print("\n== 数据目录定位 ==")
    data_files = []
    for root, dirs, files in os.walk(REPO):
        if "/data" in root.replace("\\", "/") or "data" in os.path.basename(root).lower():
            for f in files:
                fp = os.path.join(root, f)
                data_files.append((fp, os.path.getsize(fp)))
    data_files.sort()
    if data_files:
        print(f"  候选数据文件: {len(data_files)} 个, 合计 {human(sum(s for _, s in data_files))}")
        print(f"  样例路径 (前8个):")
        for fp, sz in data_files[:8]:
            print(f"    {human(sz):>9}  {fp.replace(REPO + '/', '')}")
        # 按父目录分组统计
        grp = Counter(os.path.dirname(fp).replace(REPO + "/", "") for fp, _ in data_files)
        print(f"  按父目录分布: {dict(grp.most_common(10))}")
    else:
        print("  [INSPECT-WARN] 未发现 data 目录, 请把顶层结构输出发回给虎博")

    # ---- 5. 抽样加载一个数据文件 ----
    print("\n== 数据样本格式探测 ==")
    # 优先 pkl, 其次 csv/npy
    for target_ext in [".pkl", ".pickle", ".csv", ".npy", ".npz", ".json"]:
        samples = [(fp, sz) for fp, sz in data_files if fp.endswith(target_ext)]
        if not samples:
            continue
        fp, sz = samples[len(samples) // 2]     # 取中间一个, 避开可能的异常首尾
        print(f"  抽样: {fp.replace(REPO + '/', '')}  ({human(sz)})  [{target_ext}]")
        try:
            if target_ext in (".pkl", ".pickle"):
                with open(fp, "rb") as f:
                    obj = pickle.load(f)
                describe_pkl(obj, prefix="    ")
            elif target_ext == ".csv":
                import csv
                with open(fp, "r") as f:
                    reader = csv.reader(f)
                    head = [next(reader, None) for _ in range(3)]
                rows = 1 + sum(1 for _ in open(fp)) - 1
                print(f"    CSV 行数≈{rows}, 表头: {head[0][:8] if head[0] else '空'}")
                print(f"    首行数据: {head[1][:8] if len(head) > 1 and head[1] else '空'}")
            elif target_ext == ".npy":
                import numpy as np
                arr = np.load(fp, allow_pickle=False)
                print(f"    NPY shape={arr.shape}, dtype={arr.dtype}, "
                      f"min={arr.min():.4f}, max={arr.max():.4f}")
            elif target_ext == ".npz":
                import numpy as np
                z = np.load(fp, allow_pickle=True)
                for k in z.files[:10]:
                    a = z[k]
                    print(f"    NPZ key={k}, shape={a.shape}, dtype={a.dtype}")
            elif target_ext == ".json":
                import json
                with open(fp) as f:
                    obj = json.load(f)
                if isinstance(obj, dict):
                    print(f"    JSON keys: {list(obj.keys())[:15]}")
                elif isinstance(obj, list):
                    print(f"    JSON list len={len(obj)}, 首元素类型: {type(obj[0]).__name__}")
                    if isinstance(obj[0], dict):
                        print(f"    首元素keys: {list(obj[0].keys())[:15]}")
        except Exception:
            print(f"    [INSPECT-ERR-03] 加载失败:")
            traceback.print_exc()
            print("    把上面 traceback 发回给虎博")
        break   # 只探测一种优先格式

    print("\n[INSPECT-DONE] 体检完成, 请把以上完整输出发回给虎博")

def describe_pkl(obj, prefix="", depth=0):
    """递归描述 pickle 对象结构, 最多3层"""
    pad = prefix + "  " * depth
    import numpy as np
    if isinstance(obj, dict):
        print(f"{pad}dict, {len(obj)} keys: {list(obj.keys())[:12]}")
        if depth < 2:
            for k, v in list(obj.items())[:4]:
                print(f"{pad}[{k!r}] ->")
                describe_pkl(v, prefix, depth + 1)
    elif isinstance(obj, (list, tuple)):
        print(f"{pad}{'list' if isinstance(obj, list) else 'tuple'}, len={len(obj)}")
        if len(obj) and depth < 2:
            print(f"{pad}首元素:")
            describe_pkl(obj[0], prefix, depth + 1)
    elif isinstance(obj, np.ndarray):
        print(f"{pad}ndarray shape={obj.shape}, dtype={obj.dtype}, "
              f"min={float(np.nanmin(obj)):.4f}, max={float(np.nanmax(obj)):.4f}")
    elif hasattr(obj, "shape"):  # tensor 等
        print(f"{pad}{type(obj).__name__} shape={tuple(obj.shape)}, dtype={obj.dtype}")
    else:
        print(f"{pad}{type(obj).__name__}: {str(obj)[:100]}")

if __name__ == "__main__":
    main()
