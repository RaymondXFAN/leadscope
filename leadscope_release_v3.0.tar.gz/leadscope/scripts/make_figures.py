#!/usr/bin/env python3
"""
LeadScope 论文作图脚本 — 莫兰迪色系 + Times New Roman ≥12pt + 无 caption + 可 legend。

用真实实验数据生成 4 张图:
  fig1_coherence_spectrum.png  — 相干谱 + 频段带
  fig2_band_vision.png         — 频段 × 视觉条件 bar (dyad级 N=35)
  fig3_lag_sensitivity.png     — 滞后分布敏感性 (子窗长度)
  fig4_song_symmetry.png       — 同歌 vs 不同歌耦合 (dyad级)

用法: python scripts/make_figures.py [--out figures]
"""

import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# ---- 全局样式: Times New Roman ≥12pt ----
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman", "Times", "DejaVu Serif"]
plt.rcParams["font.size"] = 12
plt.rcParams["axes.labelsize"] = 13
plt.rcParams["axes.titlesize"] = 13
plt.rcParams["xtick.labelsize"] = 12
plt.rcParams["ytick.labelsize"] = 12
plt.rcParams["legend.fontsize"] = 11
plt.rcParams["axes.linewidth"] = 1.0
plt.rcParams["svg.fonttype"] = "none"

# ---- 莫兰迪色系 (低饱和度柔和色) ----
M = {
    "blue":   "#6C8B9B",   # 主色: real / vision / 同歌
    "pink":   "#C4AFAA",   # 对照: mismatch / no-vision / 不同歌
    "green":  "#9DAA9D",   # 第三色
    "yellow": "#C4B89A",   # 第四色
    "purple": "#9B8FA8",   # 第五色
    "grey":   "#A8A8A8",   # 中性灰
}

# ======================== 真实实验数据 ========================

# 图1: coherence谱 (33频率点, 虎博 coherence分析4 输出)
FREQS = np.array([0.000,0.078,0.156,0.234,0.312,0.391,0.469,0.547,0.625,0.703,
                   0.781,0.859,0.938,1.016,1.094,1.172,1.250,1.328,1.406,1.484,
                   1.562,1.641,1.719,1.797,1.875,1.953,2.031,2.109,2.188,2.266,
                   2.344,2.422,2.500])
COH = np.array([0.2843,0.2904,0.2663,0.2686,0.2725,0.2706,0.2807,0.2836,0.2687,0.2745,
                0.2758,0.2704,0.2771,0.2825,0.2778,0.2724,0.2723,0.2754,0.2754,0.2763,
                0.2723,0.2722,0.2718,0.2765,0.2873,0.3137,0.3072,0.3025,0.2894,0.2672,
                0.2725,0.2744,0.2645])

# 图2: 频段 × 视觉条件 (dyad级 N=35, 虎博 dyad统计输出)
BANDS = ["low\n(0.1-0.5 Hz)", "rhythm\n(0.5-1.5 Hz)", "fast\n(1.5-2.5 Hz)"]
VISION_M = np.array([0.2815, 0.2841, 0.2976])
VISION_SD = np.array([0.0239, 0.0220, 0.0238])
NOVIS_M = np.array([0.2598, 0.2644, 0.2663])
NOVIS_SD = np.array([0.0187, 0.0153, 0.0125])
VISION_D = np.array([1.010, 1.038, 1.646])  # Cohen's d

# 图3: 滞后分布敏感性 (子窗长度, §4.3)
SUB_WIN = ["25 fr\n(5 s)", "50 fr\n(10 s)", "100 fr\n(20 s)", "186 fr\n(37 s, full)"]
LAG_ABS = [380, 420, 680, 1146]  # |τ|均值 ms

# 图4: 同歌 vs 不同歌 (dyad级 N=35, 虎博 dyad统计输出)
SONG_M = [0.3716, 0.2944]
SONG_SD = [0.0844, 0.0475]
SONG_D = 1.128


def fig1_coherence_spectrum(out):
    fig, ax = plt.subplots(figsize=(7, 4.2))
    # 频段带背景
    for lo, hi, c, name in [(0.1,0.5,M["yellow"],"low"),
                             (0.5,1.5,M["green"],"rhythm"),
                             (1.5,2.5,M["purple"],"fast")]:
        ax.axvspan(lo, hi, alpha=0.18, color=c)
        ax.text((lo+hi)/2, 0.335, name, ha="center", va="bottom",
                fontsize=10, style="italic", color="#555555")
    ax.plot(FREQS, COH, "-o", color=M["blue"], lw=1.8, ms=4.5,
            markeredgecolor="white", markeredgewidth=0.5, label="Mean coherence")
    # 噪声底参考线 (E[C_noise]≈1/L, L≈11, bias≈0.09)
    ax.axhline(0.09, ls="--", color=M["grey"], lw=1.2, label="Surrogate null (95th pct)")
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Coherence")
    ax.set_xlim(-0.05, 2.55)
    ax.set_ylim(0, 0.36)
    ax.legend(loc="upper left", frameon=False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig1_coherence_spectrum.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)


def fig2_band_vision(out):
    fig, ax = plt.subplots(figsize=(6, 4.5))
    x = np.arange(len(BANDS))
    w = 0.35
    b1 = ax.bar(x - w/2, VISION_M, w, yerr=VISION_SD, color=M["blue"],
                edgecolor="white", label="Vision", capsize=4, error_kw={"lw":1.2})
    b2 = ax.bar(x + w/2, NOVIS_M, w, yerr=NOVIS_SD, color=M["pink"],
                edgecolor="white", label="No-vision", capsize=4, error_kw={"lw":1.2})
    # 标 d 值
    for i, d in enumerate(VISION_D):
        ymax = max(VISION_M[i]+VISION_SD[i], NOVIS_M[i]+NOVIS_SD[i])
        ax.text(i, ymax + 0.008, f"d={d:.2f}", ha="center", va="bottom",
                fontsize=10, color=M["purple"], fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(BANDS)
    ax.set_ylabel("Coherence (dyad median)")
    ax.set_ylim(0.20, 0.34)
    ax.legend(loc="upper left", frameon=False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig2_band_vision.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)


def fig3_lag_sensitivity(out):
    fig, ax = plt.subplots(figsize=(6, 4.2))
    x = np.arange(len(SUB_WIN))
    colors = [M["green"], M["blue"], M["yellow"], M["pink"]]
    bars = ax.bar(x, LAG_ABS, color=colors, edgecolor="white", width=0.6)
    # 标数值
    for i, v in enumerate(LAG_ABS):
        ax.text(i, v + 20, f"{v} ms", ha="center", va="bottom", fontsize=11, color="#444444")
    ax.axhline(500, ls="--", color=M["grey"], lw=1, alpha=0.7)
    ax.text(3.4, 510, "plausible\nhuman lag range", fontsize=9, color=M["grey"],
            ha="right", va="bottom")
    ax.set_xticks(x)
    ax.set_xticklabels(SUB_WIN)
    ax.set_ylabel(r"$|\tau|$ mean (ms)")
    ax.set_ylim(0, 1300)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig3_lag_sensitivity.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)


def fig4_song_symmetry(out):
    fig, ax = plt.subplots(figsize=(5, 4.5))
    labels = ["Same\nmusic", "Different\nmusic"]
    x = np.arange(2)
    bars = ax.bar(x, SONG_M, yerr=SONG_SD, color=[M["blue"], M["pink"]],
                  edgecolor="white", width=0.5, capsize=5, error_kw={"lw":1.3})
    for i, (v, s) in enumerate(zip(SONG_M, SONG_SD)):
        ax.text(i, v + s + 0.015, f"{v:.3f}±{s:.3f}", ha="center", va="bottom",
                fontsize=10, color="#444444")
    # d 标注
    ax.annotate(f"Cohen's d = {SONG_D:.3f}\n(p < .0001, FDR corrected)",
                xy=(0.5, 0.42), fontsize=11, ha="center", color=M["purple"],
                fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=M["purple"], alpha=0.8))
    ax.set_xticks(x)
    ax.set_xticklabels(["Same\nmusic", "Different\nmusic"])
    ax.set_ylabel(r"Peak $r$ (dyad median)")
    ax.set_ylim(0, 0.50)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig4_song_symmetry.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figures"))
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    print(f"[FIG] 输出目录: {a.out}")
    print(f"  样式: 莫兰迪色系 + Times New Roman ≥12pt + 无 caption")
    fig1_coherence_spectrum(a.out); print("  fig1_coherence_spectrum.png ✓")
    fig2_band_vision(a.out);        print("  fig2_band_vision.png ✓")
    fig3_lag_sensitivity(a.out);    print("  fig3_lag_sensitivity.png ✓")
    fig4_song_symmetry(a.out);      print("  fig4_song_symmetry.png ✓")
    print(f"[FIG-DONE] 4 张图生成完成")


if __name__ == "__main__":
    main()
