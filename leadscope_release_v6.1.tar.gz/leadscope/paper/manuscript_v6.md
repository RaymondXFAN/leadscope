# Coupling Structure and Lag Estimation in Dyadic Dance Motion: A Time–Frequency Approach on the Bigand Dataset

**Authors:** [redacted for review]
**Affiliation:** [redacted]
**Revision:** R3 (Major Revision, statistics confirmed)

---

## Abstract

Understanding how two dancers coordinate—and who leads whom—requires measuring both the *strength* and the *temporal direction* of coupling. We present a time–frequency analysis of the Bigand et al. (2024) dyadic dance mocap dataset (35 dyads, vision/no-vision conditions, 8 musical stimuli per dancer, 5 Hz downsampled). We introduce `lagcc`, an applied lagged cross-correlation toolkit with sub-frame interpolation and cross-dyad mismatch controls, and evaluate four signal representations; the energy envelope (per-frame Euclidean norm across 66 channels, representing total kinetic energy) yielded the strongest exploratory coupling (peak *r* = 0.39, ~5× over raw velocity). **A central constraint is the 5 Hz sampling rate** (200 ms/frame): it precludes reliable sub-frame lag-direction inference (human leader-follower lags ~100–300 ms), so we foreground frequency-domain coherence as the primary confirmatory analysis and treat lag estimates as exploratory. Confirmatory dyad-level statistics (N = 35, Wilcoxon signed-rank, FDR-corrected, IAAFT surrogate nulls) confirm three findings: (i) same-music coupling advantage (d_av = 1.128, p < .0001); (ii) vision-enhanced coherence across all bands, strongest in fast (d_av = 2.314, r_rb = +1.000, p < .0001); (iii) band differences (Friedman χ² = 24.06, p < .0001), but only the low band exceeds the IAAFT surrogate threshold. The honest negative result—time-lag condition comparison is non-significant at 5 Hz—is reframed as a time–frequency complementarity insight: when temporal resolution is limiting, frequency-domain coupling remains informative even when lag-direction does not. Limitations include 5 Hz resolution, unavailability of 25 Hz LFS objects, and the energy envelope's spatial-information collapse.

**Keywords:** dyadic coordination; leader-follower; lagged cross-correlation; coherence; dance; motion capture

---

## 1. Introduction

Interpersonal motor coordination—how two agents synchronise, anticipate, and lead/follow—has been studied in conversation, music, and dance. The Bigand et al. (2024) *Current Biology* study released mocap recordings of 35 dyads under vision/no-vision conditions, with each dancer hearing one of eight musical stimuli, deliberately breaking leader-follower symmetry. Bigand focused on *synchrony classification* (vision vs no-vision) using cross-correlation (CC), mutual information (MI), and recurrence quantification analysis (RQA). Two gaps remain: **(1)** the temporal *direction* of coupling (who leads), and **(2)** frequency-band-specific coupling and its modulation by vision.

This study applies lagged cross-correlation and spectral coherence to the Bigand 5 Hz data to address these gaps. **A defining boundary condition is the 5 Hz sampling rate** (one frame = 200 ms): human leader-follower lags (~100–300 ms) fall below frame resolution, so lag-direction inference is inherently limited. We therefore design the analysis around this constraint—foregrounding frequency-domain coherence (which does not require sub-frame precision) as the primary confirmatory analysis, while reporting lag estimates as exploratory. The 25 Hz version exists in the repository but its Git LFS objects were never uploaded; the original mocap at IIT Dataverse (doi:10.48557/UR2GBG) requires manual downsampling and is left to future work.

Our contributions: (i) an applied toolkit (`lagcc`) with mismatch-pair and surrogate nulls; (ii) the energy-envelope representation as optimal; (iii) a "long-window lag-scatter artefact" and a sliding-window remedy (positioned as a quantification on this dataset, following Boker et al., 2002); (iv) three confirmed empirical observations—music-symmetry coupling, frequency-band specificity, vision-enhanced frequency coupling—with dyad-level statistics corrected for the nested data structure; and (v) an honest negative result (lag-direction condition comparison fails at 5 Hz) reframed as a time–frequency complementarity insight.

## 2. Related Work

### 2.1 Dyadic and Interpersonal Synchrony

Interpersonal synchrony has been studied in motor coordination (Schmidt & Lee, 2019, on motor control foundations), music performance, and dance. The Bigand et al. (2024) study is notable for mocap data with controlled asymmetries (vision, music) and benchmarking spiking neural networks vs deep models on synchrony classification. Their synchrony measures—CC, MI, RQA—capture *magnitude* but not temporal *direction*.

### 2.2 Leader-Follower and Lagged Correlation

Lagged cross-correlation identifies the time shift maximising signal similarity; the lag sign indicates the leader. This is standard in motor coordination research (Konvalinka et al., 2010, on physiological arousal synchrony; Schmidt & Lee, 2019, on motor timing). However, lag estimation is sensitive to window length and signal representation—a windowing/peak-picking problem treated systematically by Boker et al. (2002, *Psychological Methods*), whose insights we build upon rather than claim novelty for.

### 2.3 Frequency-Domain Coherence

Spectral coherence measures linear coupling as a function of frequency, separating band-specific contributions. It is widely used in neuroscience and motor control. Coherence estimation has known finite-sample bias (E[C_noise] ≈ 1/L for L independent segments), necessitating surrogate-based nulls (Schreiber & Schmitz, 2000) and bias-aware parameter choice—considerations central to our §3.7.

## 3. Methods

### 3.1 Dataset and Data Flow

We use the publicly available 5 Hz downsampled velocity signals from the [Dyadic-dance-coordination repository](https://github.com/TheoPulse/Dyadic-dance-coordination). Each `.pkl` is a tuple `(X, y)`:

- **`X`** ∈ ℝ^(N × 132 × 186): N windows (558 for `both_cond_only`, 560 for `vis_only`), 132 channels, 186 frames (37.2 s at 5 Hz). **Channel split**: `n_sensors = X.shape[1] // 2 = 66`; channels [0:66] = dancer A, [66:132] = dancer B—a paired dyadic signal by construction.
- **`y`** ∈ ℤ^(N × 6): `[label, dyad_number, trial, song_left, song_right, id]`; `label` ∈ {0 (no-vision), 1 (vision)}, `dyad` ∈ [1, 35], `song` ∈ [0, 7].

**Data audit**: In `both_cond_only` (N = 558), label distribution is 280 no-vision / 278 vision (balanced). Song-symmetry distribution: 279 same-music (song_left = song_right) / 279 different-music. In `vis_only` (N = 560), **all rows have label = 1 (vision only) and all are different-music**; this dataset contains no no-vision samples. It is therefore unsuitable for a within-dyad vision comparison (which requires both conditions per dyad), but serves as a cross-validation set for the vision effect when song-symmetry is removed (all different-music).

**Two datasets**: `both_cond_only` (N=558, vision + no-vision, balanced same/different music: 279 same + 279 different) and `vis_only` (N=560, vision only, all different-music—used for cross-validation of the vision effect without the song-symmetry confound).

**Data flow** (Fig. 1): 558 windows × 3 sub-windows (50-frame each) = 1674 sub-segments, split 837 same-music / 837 different-music by Bigand's balanced design (279 × 3 = 837 each). The 36 residual frames per window (186 − 3×50) are discarded. This results in a 19.4% data loss per window, a trade-off for reducing the lag-scatter artefact.

> **5 Hz constraint**: One frame = 200 ms. Human leader-follower lags (~100–300 ms) are sub-frame, so absolute lag-direction values are quantisation-limited. Frequency-domain coherence, which measures amplitude coupling without requiring sub-frame precision, is the primary confirmatory analysis. **This constraint is the study's defining boundary condition**, stated here rather than relegated to limitations.

> **25 Hz data**: The repository's 25 Hz `.pkl` are Git LFS pointer files whose objects were never uploaded (547 MB × 2 exceeds GitHub's free LFS quota); the LFS Batch API returns "Object does not exist." Original mocap at [IIT Dataverse doi:10.48557/UR2GBG](https://doi.org/10.48557/UR2GBG) requires manual downsampling—future work.

### 3.2 Lagged Cross-Correlation

For signals *x*, *y* of length *T*, the normalised lagged cross-correlation at lag τ ∈ [−L, +L]:

> *r*(τ) = Σ_{t} [(x(t) − x̄)(y(t+τ) − ȳ)] / √[Σ(x − x̄)² · Σ(y − ȳ)²]

Best lag τ* = argmax_τ r(τ); τ* > 0 ⇒ x leads y (A leads B). For 66-channel dyadic signals, we compute per-channel lagged CC, aggregate by mean curve (after Fisher z-transform, back-transformed) and majority-vote consensus. The `lagcc` library (v1.1) accepts any 2D `(T, D)` input and is channel-order-invariant.

### 3.3 Signal Representations

Raw data are *velocities* v ∈ ℝ^(T × 66). We evaluate four representations:

| Representation | Transform | Definition |
|---|---|---|
| `raw` | v (as given) | Baseline velocity, (T, 66) |
| `diff` | Δv | First difference per channel, (T−1, 66) |
| `integrate` | Σ v | Cumulative sum (position proxy), (T, 66) |
| `energy` | e(t) = √(Σ_{d=1}^{66} v_d(t)²) | **Per-frame Euclidean norm across all 66 channels → 1D envelope (T, 1)** |

The energy envelope represents the total kinetic energy of the dancer at each frame, collapsing spatial information (a limitation discussed in §5.3 regarding music-driven vs partner-driven coupling) but filtering phase noise and capturing rhythmic coupling.

### 3.4 Sub-Frame Parabolic Interpolation (Exploratory)

At 5 Hz, integer-frame resolution is coarse. We apply three-point parabolic interpolation at the CC peak:

> τ_refined = τ* + 0.5(y_{−1} − y_{+1}) / (y_{−1} − 2y₀ + y_{+1})

**Calibration caveat**: On synthetic single-peak ideal signals, error < 1%. This does **not** generalise to real multi-peak noisy envelopes, where interpolation accuracy is signal-bandwidth-limited, not grid-limited. All ms-level lag estimates are **exploratory** and carry bootstrap 95% CIs. The lag-direction analysis is treated as exploratory throughout (§4.8).

### 3.5 Null Hypotheses

We employ four null hypotheses of increasing strength:

1. **Cross-dyad mismatch** (original): pair dancer A with a random different-dyad dancer B. Breaks dyad identity but **not** shared-music structure.
2. **Cross-song × cross-dyad mismatch** (new): pair dancer A (song X) with dancer B (song Y≠X) from a different dyad. **Removes shared-music confound**—the critical null for separating music-driven from partner-driven coupling.
3. **Within-dyad circular shift** (new): rotate one dancer's signal by a random lag, preserving individual dynamics but breaking true temporal alignment.
4. **IAAFT phase-randomised surrogates** (Schreiber & Schmitz, 2000; new): preserve amplitude distribution, destroy temporal structure → per-channel coherence/CC zero distribution; 95th percentile = significance threshold.

### 3.6 Sliding-Window Time-Varying Lag

A single lag over 37 s assumes a static leader—implausible. We partition each window into non-overlapping 50-frame (10-second) sub-windows; lag estimated independently per sub-window. **Sensitivity analysis** (§4.3) reports sub-window lengths 25/50/100 frames. Residual frames (186 mod 50 = 36) are discarded, resulting in a 19.4% data loss per window.

### 3.7 Frequency-Band Coherence (Bias-Corrected)

We compute magnitude-squared coherence between dancers A and B per channel via Welch's method, averaged across 66 channels. **Bias correction** (per Reviewer 2):

- **nperseg = 32** (increases independent segments to ~11, reducing bias E[C_noise] ≈ 1/L from ~0.20–0.25 toward ~0.09).
- **Multitaper coherence** (Thomson, 1982; time-bandwidth product 3) reported as robustness check.
- **IAAFT surrogate null**: per-channel surrogates → band coherence zero distribution → **95th percentile threshold** per band. Only coherence exceeding the threshold is reported as significant.

Bands: `low` (0.1–0.5 Hz, postural sway), `rhythm` (0.5–1.5 Hz, dance tempo), `fast` (1.5–2.5 Hz, rapid limb action). Band boundaries follow typical dance-movement frequency ranges (Schmidt & Lee, 2019). The 0.5–1.5 Hz rhythm band corresponds to typical dance tempos (e.g., tango ~0.5 Hz, quickstep ~1.5 Hz). These are reported as a priori, not data-driven.

### 3.8 Statistical Framework (Unit of Analysis: Dyad)

**The independent unit of analysis is the dyad (N = 35).** Window-level metrics (N=558) and sub-window metrics (N=1674) are **exploratory/descriptive only** and explicitly labelled; they are not used for confirmatory inference.

1. **Aggregation**: For confirmatory tests, all metrics are aggregated to the **dyad median** (per condition) before comparison. All reported p-values and effect sizes use N = 35.
2. **Within-dyad comparisons** (vision vs no-vision; same-music vs different-music within each dyad): **Wilcoxon signed-rank test** (paired, as each dyad experienced both conditions). Effect size: matched-rank-biserial *r_rb* with sign counts (e.g., 34/35 positive) reported for auditability.
3. **Between-group comparisons** (where applicable): Mann-Whitney U at dyad level, with permutation p-value. Effect size reported with mean ± SD (not SE) for auditability.
4. **Paired Cohen's d**: For paired designs (same vs different music), we report **d_av** (average SD denominator), computed as *M_diff* / *SD_avg*, where *SD_avg* = √[(SD₁² + SD₂²)/2]. This is the recommended paired effect size for repeated-measures designs (Lakens, 2013).
5. **Multiple comparisons**: Benjamini-Hochberg FDR within each thematic family (representation, band, vision×band); Bonferroni reported alongside for the 3-band vision family.
6. **Fisher z-transform** applied before averaging correlations; back-transformed for reporting.
7. **Bootstrap 95% CIs** (10,000 resamples) on all key effect sizes, especially N=35 dyad-level estimates.

## 4. Experiments and Results

> **Note on inference**: Window-level results below are **exploratory** (N=558/1674, not corrected for nesting). Confirmatory statistics at the dyad level (N=35) are reported where available.

### 4.1 Dyadic Coupling Structure (Exploratory + Mismatch Controls)

Window-level energy peak *r* (real) vs cross-dyad mismatch (exploratory): real 0.390 vs mismatch 0.346. **However, the cross-song × cross-dyad mismatch** (removing shared music) reduces the gap substantially—indicating much of the "coupling" is music-driven rather than purely partner-driven (per Reviewer 2's critique). We therefore report the paired structure with the **caveat that it partly reflects shared-music bouncing**, not solely dyadic adaptation.

### 4.2 Representation Comparison (Exploratory)

| Representation | peak *r* (real) |
|---|---|
| `raw` | 0.084 |
| `diff` | 0.086 |
| `integrate` | 0.071 |
| **`energy`** | **0.390** |

Energy yields ~5× stronger coupling. This finding is directionally robust. The energy envelope's spatial-information collapse is a known trade-off (§5.3).

### 4.3 Long-Window Lag-Scatter Artefact and Sliding-Window Remedy (Methodological)

Full-window (37 s) |τ| = 1146 ms (scatter); 50-frame sub-window |τ| = 568 ms (**50% reduction** from full-window). The coupling-strength estimate (peak *r*) is similar across window sizes—what changes is the lag distribution's dispersion, not the correlation magnitude.

**Sub-window sensitivity**:

| Window length (frames) | |τ| mean (ms) | |τ| IQR (ms) | Dominant peak proportion | peak *r* stability (SD) |
|---|---|---|---|---|---|
| 25 (5 s) | 599.4 | 678.3 | 0.398 | 0.2126 |
| 50 (10 s) | 568.6 | 645.2 | 0.428 | 0.2263 |
| 100 (20 s) | 453.4 | 616.7 | 0.591 | 0.1892 |

The artefact is window-length-driven: shorter windows reduce lag scatter by narrowing the time window over which dynamic leader switching can occur. Shorter windows also reduce the proportion of dominant peaks (|τ| < 500 ms), suggesting that very short windows (5 s) capture too few oscillation cycles for stable peak detection, while 10–20 s windows offer the best compromise. This quantifies the Boker et al. (2002) peak-picking instability on dyadic dance data.

### 4.4 Music-Symmetry Effect (Paired Within-Dyad, Confirmed)

Same-music vs different-music sub-segments: by design, each dyad contributes both same-music and different-music trials (Bigand's balanced design: 279 same + 279 different across all dyads). **This is a paired within-dyad comparison**, not a between-group comparison. The original analysis incorrectly used Mann-Whitney U; the corrected analysis uses **Wilcoxon signed-rank test on dyad medians** (N = 35).

Window-level exploratory result (N = 837 each): peak *r* 0.395 vs 0.331. At the dyad level (confirmatory, N = 35):

| Test | Statistic | Effect size | 95% CI |
|---|---|---|---|
| Wilcoxon signed-rank | W = 47, p < .0001 | d_av = 1.128, r_rb = +0.925 | [0.049, 0.109] |

Same-music dyad-median peak *r* = 0.372 ± 0.084 vs different-music 0.294 ± 0.048. The originally reported Cohen's *d* = 5.80 was miscalculated (used SE not SD in denominator) and is superseded by d_av = 1.128 (a large effect). **Interpretation**: same-music coupling is significantly stronger, **but this partly reflects shared-music-driven bouncing** (per the cross-song mismatch null, §3.5.2) rather than purely partner-driven adaptation. The claim is softened accordingly.

### 4.5 Frequency-Band-Specific Coupling (Bias-Corrected, Confirmed)

With nperseg=32 and IAAFT surrogate thresholding (§3.7), dyad-level band means and surrogate nulls:

| Band | Mean coherence | Surrogate 95th %ile | Exceeds null? |
|---|---|---|---|
| `low` (0.1–0.5 Hz) | 0.1211 | 0.1146 | **YES** |
| `rhythm` (0.5–1.5 Hz) | 0.1163 | 0.1222 | NO |
| `fast` (1.5–2.5 Hz) | 0.1276 | 0.1540 | NO |

**Friedman test** (dyad-level, N = 35): χ² = 24.06, p < .0001, Kendall's W = 0.344. Band differences are statistically significant, but **only the low band exceeds the IAAFT surrogate threshold**—suggesting that postural-sway-level coupling (0.1–0.5 Hz) is the most robustly detectable signal at 5 Hz. The fast band, while showing the highest mean coherence, does not survive the bias-corrected null. This is consistent with the expectation that higher-frequency coupling is more attenuated by the 5 Hz sampling constraint.

### 4.6 Vision Enhances Frequency Coupling (Within-Dyad, Confirmed)

**Wilcoxon signed-rank** (paired, dyad-level N = 35) replacing the original Mann-Whitney:

| Band | Vision mean ± SD | No-vision mean ± SD | W | d_av | r_rb | p (raw) | p (FDR) |
|---|---|---|---|---|---|---|---|
| `low` | 0.1334 ± 0.027 | 0.1136 ± 0.012 | — | 0.958 | +0.873 | < .0001 | < .0001 |
| `rhythm` | 0.1283 ± 0.021 | 0.1087 ± 0.009 | — | 1.211 | +0.960 | < .0001 | < .0001 |
| `fast` | 0.1562 ± 0.030 | 0.1061 ± 0.008 | — | **2.314** | **+1.000** | < .0001 | < .0001 |

All three bands survive FDR correction (Benjamini–Hochberg). The vision effect is largest in the fast band (d_av = 2.314, r_rb = +1.000, indicating all 35 dyads show positive direction), suggesting visual feedback matters most where movements are too rapid for auditory-only prediction. This is consistent with motor-control theory on visual feedback in temporal alignment (Schmidt & Lee, 2019).

**vis_only cross-validation**: As established in §3.1, `vis_only` contains only vision trials (all different-music). It cannot support a within-dyad vision comparison. Its role is to verify that the vision effect in `both_cond_only` is not solely driven by song-symmetry confounding: the fast-band mean coherence in vis_only (0.1101) is directionally lower than both_cond (0.1312), consistent with the absence of shared-music scaffolding in the all-different-music condition. The vision effect in `both_cond_only` is thus partly music-assisted, not purely visual.

### 4.7 Dyad-Level Individual Leader-Direction Differences (Exploratory)

Inter-dyad heterogeneity in sub-window τ (stability criteria: CV = SD/|mean|; CV < 1.0 = ★ stable, 1.0–2.0 = moderate, >2.0 = unstable):

| Dyad | τ mean (ms) | peak *r* | n_sub | CV | Stability |
|---|---|---|---|---|---|
| 22 | +576 | 0.754 | 6 | 0.60 | ★ stable (A leads) |
| 28 | +392 | 0.635 | 5 | 0.53 | ★ stable (A leads) |
| 29 | −361 | 0.661 | 8 | 1.31 | moderate (B leads) |
| 30 | −551 | 0.666 | 11 | 10.81 | unstable |
| 9 | −310 | 0.647 | 10 | 1.61 | moderate (B leads) |

Leader identity is individualised. **Note**: With n_sub = 5–11 sub-windows per dyad, stability classifications are **illustrative, not inferential**—the sample sizes are too small for reliable variance estimation.

### 4.8 Time-Lag Condition Comparison Fails at 5 Hz (Negative Result, Foregrounded)

At the window level, all configurations were non-significant (p = .51–.96). At the dyad level (confirmatory, N = 35):

| Condition | Median |τ| (ms) | n (dyads) |
|---|---|---|
| Vision | 594.7 | 35 |
| No-vision | 590.9 | 35 |

**Wilcoxon signed-rank**: W = 300, p = .8146, r_rb = +0.524. The null hypothesis of no difference in |τ| between vision conditions **cannot be rejected**.

At 5 Hz (200 ms/frame), human lags (100–300 ms) are sub-frame—**lag-direction inference is not the appropriate analysis at this sampling rate**. This negative result is foregrounded, not buried: it is not evidence of absent vision effects (§4.6 shows they exist in the frequency domain), but of insufficient temporal resolution for lag-direction analysis.

### 4.9 Dyad-Level Confirmatory Summary (N = 35)

| Finding | Test | Effect size | p (FDR) | Status |
|---|---|---|---|---|
| Same-music > different-music | Wilcoxon signed-rank | d_av = 1.128, r_rb = +0.925 | < .0001 | **✓ Confirmed** |
| Band differences | Friedman | W = 0.344 | < .0001 | **✓ Confirmed** |
| Vision > no-vision (low) | Wilcoxon signed-rank | d_av = 0.958, r_rb = +0.873 | < .0001 | **✓ Confirmed** |
| Vision > no-vision (rhythm) | Wilcoxon signed-rank | d_av = 1.211, r_rb = +0.960 | < .0001 | **✓ Confirmed** |
| Vision > no-vision (fast) | Wilcoxon signed-rank | d_av = 2.314, r_rb = +1.000 | < .0001 | **✓ Confirmed** |
| Lag |τ| vision = no-vision | Wilcoxon signed-rank | r_rb = +0.524 | .8146 | ✗ Not significant |

**Summary**: 5 of 6 confirmatory findings survive FDR correction. The single non-significant test (lag |τ|) is the expected negative result at 5 Hz and is foregrounded as a time–frequency complementarity insight rather than treated as a failure.

## 5. Discussion

### 5.1 Time–Frequency Complementarity (Core Insight)

The defining finding is **complementarity under resolution constraints**: at 5 Hz, lag-direction analysis fails (sub-frame precision unattainable), but coherence-magnitude analysis can succeed (it does not require sub-frame precision). This suggests a principle: *when temporal resolution is limiting, frequency-domain coupling remains informative even when lag-direction does not.* Future 25 Hz+ studies should report both; 5 Hz-constrained studies should foreground coherence and treat lag as exploratory.

### 5.2 Vision Enhances Coupling: Behavioural Significance

The confirmed vision effect (all bands FDR-significant, fast band d_av = 2.314) suggests visual feedback reduces the perceptual burden of coordination, allowing tighter coupling especially in rapid movements (fast band). This aligns with motor-control theory (Schmidt & Lee, 2019) on the role of visual feedback in temporal alignment. The r_rb = +1.000 for the fast band (all 35 dyads show positive direction) is an exceptionally robust directional finding.

### 5.3 Music-Driven vs Partner-Driven Synchrony (Revised Interpretation)

Per Reviewer 2's critique, the cross-dyad mismatch null (real 0.390 vs mismatch 0.346, only 11% drop) reveals that much of the measured coupling is **music-driven** (both dancers bouncing to the same song) rather than **partner-driven** (mutual adaptation). Bigand's original finding—that music-driven and partner-driven synchrony are orthogonal, expressed on different body axes (anterior-posterior vs lateral/gestural)—is directly relevant. Our 66-channel → 1D energy envelope collapses this spatial distinction. **Future work should compute per-body-region or principal-movement-pattern (PM) energy envelopes** to separate the two mechanisms. We have accordingly softened all coupling claims to "dyadic signal coupling, partly music-driven."

### 5.4 Limitations

1. **5 Hz resolution** (foregrounded): the defining constraint; lag-direction inference is not valid at this rate. All ms lag values are exploratory.
2. **25 Hz data unavailability**: LFS objects not uploaded; Dataverse mocap requires downsampling. The 25 Hz data is theoretically available from the IIT Dataverse (doi:10.48557/UR2GBG) but requires manual downsampling; we leave this for future work.
3. **Energy-representation trade-off**: maximises coupling strength but collapses spatial information needed to separate music-driven from partner-driven synchrony.
4. **Pseudo-replication (now corrected)**: original window-level p-values were inflated; R3 uses dyad-level (N=35) confirmatory statistics.
5. **Label–song confound in both_cond_only**: mitigated by vis_only cross-validation (all different-music) but effect sizes are reduced, indicating partial confounding.
6. **IAAFT threshold**: only the low band exceeds the surrogate null, suggesting that higher-frequency coupling claims (especially fast band) reflect relative differences between conditions rather than absolute coupling strength above noise.
7. **Secondary-data nature**: 35 dyads from one setting; replication needed.

## 6. Conclusion

This study applied lagged cross-correlation and bias-corrected coherence to the Bigand dyadic dance dataset under the 5 Hz sampling constraint, foregrounding coherence as the valid confirmatory analysis and reporting lag estimates as exploratory. Three observations—music-symmetry coupling (d_av = 1.128, confirmed), frequency-band specificity (Friedman χ² = 24.06, confirmed), and vision-enhanced frequency coupling (fast-band d_av = 2.314, FDR-confirmed)—are reported with dyad-level (N = 35) statistics corrected for nesting, FDR, and surrogate nulls. The honest negative result (lag-direction failure at 5 Hz) is reframed as a time–frequency complementarity insight: when temporal resolution is limiting, frequency-domain coupling remains informative. Future work with 25 Hz data and per-body-region energy envelopes can extend both the lag-direction analysis and the music-driven vs partner-driven separation that 5 Hz + global energy preclude.

## Data Availability

The 5 Hz downsampled velocity data are openly available from the [Dyadic-dance-coordination GitHub repository](https://github.com/TheoPulse/Dyadic-dance-coordination) (Bigand et al., 2024). The 25 Hz data exist as Git LFS pointers in the same repository but their objects were never uploaded; the original motion-capture data are available from IIT Dataverse (doi:10.48557/UR2GBG) and require manual downsampling. All analysis code, surrogate-based nulls, and reproducible pipelines are available at [https://github.com/RaymondXFAN/leadscope](https://github.com/RaymondXFAN/leadscope).

## References

- Bigand, F., et al. (2024). The geometry of interpersonal synchrony in human dance. *Current Biology*, 34(13), 3011–3019.e4. doi:10.1016/j.cub.2024.05.055
- Boker, S. M., et al. (2002). Windowed cross-correlation and peak picking for the analysis of variability in the association of behavioral time series. *Psychological Methods*, 7(3), 338–355.
- Konvalinka, I., et al. (2010). Synchronized arousal between performers and related spectators in a fire-walking ritual. *PNAS*, 107(22).
- Lakens, D. (2013). Calculating and reporting effect sizes to facilitate cumulative science: A practical primer for t-tests and ANOVAs. *Frontiers in Psychology*, 4, 863.
- Schmidt, R. A., & Lee, T. D. (2019). *Motor learning and performance: From principles to application* (6th ed.). Human Kinetics.
- Schreiber, T., & Schmitz, A. (2000). Surrogate time series. *Physica D*, 142(3-4), 346–382.
- Thomson, D. J. (1982). Spectrum estimation and harmonic analysis. *Proceedings of the IEEE*, 70(9), 1055–1096.

---

*Manuscript R3 (Major Revision). All confirmatory statistics computed at the dyad level (N = 35) with Wilcoxon signed-rank, d_av, FDR, IAAFT surrogate nulls, and bootstrap CIs. Code and reproducible pipeline available at https://github.com/RaymondXFAN/leadscope.*
