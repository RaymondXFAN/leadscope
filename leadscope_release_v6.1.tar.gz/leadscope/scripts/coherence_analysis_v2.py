#!/usr/bin/env python3
"""
coherence_analysis_v2.py — 审稿人要求修正版
- nperseg=32 (减少有限样本偏差)
- IAAFT surrogate 零分布 (95th %ile 阈值)
- 输出含 dyad 列的 CSV (供 dyad_aggregate_stats_v2.py 消费)
- 同时支持 both_cond 和 vis_only

用法:
  python scripts/coherence_analysis_v2.py --out results/coherence_both.csv
  python scripts/coherence_analysis_v2.py --data-dir dyadic_dance/data/vis_only --out results/coherence_vis.csv
"""

import argparse
import os
import pickle
import sys
import time
import traceback

import numpy as np
from scipy.signal import coherence

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"

BANDS = {
    "low": (0.1, 0.5),
    "rhythm": (0.5, 1.5),
    "fast": (1.5, 2.5),
}


def to_np(t):
    if hasattr(t, "detach"):
        t = t.detach().cpu().numpy()
    return np.asarray(t)


def mean_coherence(A, B, fs, nperseg):
    """A,B: (T, D) 多通道, 返回 (freqs, mean_cohere) 跨通道平均相干谱。"""
    D = A.shape[1]
    T = A.shape[0]
    nps = min(nperseg, T)
    coh_sum = None
    freqs = None
    cnt = 0
    for d in range(D):
        try:
            f, c = coherence(A[:, d], B[:, d], fs=fs, nperseg=nps)
            if coh_sum is None:
                freqs = f
                coh_sum = np.zeros_like(c)
            coh_sum += c
            cnt += 1
        except Exception:
            continue
    if cnt == 0:
        return None, None
    return freqs, coh_sum / cnt


def band_integrate(freqs, coh, lo, hi):
    mask = (freqs >= lo) & (freqs <= hi)
    if mask.sum() == 0:
        return 0.0
    return float(np.mean(coh[mask]))


def iaaft_surrogate_coherence(A, B, fs, nperseg, n_surr=100, seed=42):
    """
    IAAFT surrogate: 对 A 的每通道做相位随机化, 保幅度谱,
    重算与 B 的 coherence, 返回每频段的 95th percentile。
    """
    rng = np.random.default_rng(seed)
    D = A.shape[1]
    T = A.shape[0]
    nps = min(nperseg, T)
    
    # 频段索引预计算
    freqs, _ = coherence(A[:, 0], B[:, 0], fs=fs, nperseg=nps)
    band_masks = {name: (freqs >= lo) & (freqs <= hi) for name, (lo, hi) in BANDS.items()}
    
    surr_bands = {name: [] for name in BANDS}
    
    for _ in range(n_surr):
        A_surr = np.zeros_like(A)
        for d in range(D):
            x = A[:, d]
            n = len(x)
            xf = np.fft.rfft(x)
            amps = np.abs(xf)
            phases = rng.uniform(0, 2*np.pi, len(xf))
            phases[0] = 0
            if n % 2 == 0:
                phases[-1] = 0
            sf = amps * np.exp(1j * phases)
            A_surr[:, d] = np.fft.irfft(sf, n=n)
        
        # 计算 surrogate coherence
        _, coh_surr = mean_coherence(A_surr, B, fs, nperseg)
        if coh_surr is not None:
            for name, mask in band_masks.items():
                if mask.sum() > 0:
                    surr_bands[name].append(float(np.mean(coh_surr[mask])))
    
    thresholds = {}
    for name in BANDS:
        vals = np.array(surr_bands[name])
        if len(vals) > 0:
            thresholds[name] = float(np.percentile(vals, 95))
        else:
            thresholds[name] = np.nan
    return thresholds


def main():
    ap = argparse.ArgumentParser(description="Coherence v2: nperseg=32 + IAAFT surrogate")
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--data-dir", default="dyadic_dance/data/both_cond_only")
    ap.add_argument("--file", default="raw_velocities_ds.pkl")
    ap.add_argument("--hz", type=float, default=5.0)
    ap.add_argument("--nperseg", type=int, default=32, help="FFT segment length (v2: default 32)")
    ap.add_argument("--n-surr", type=int, default=100, help="IAAFT surrogate iterations")
    ap.add_argument("--out", default="/root/autodl-tmp/leadscope/results/coherence_both.csv")
    a = ap.parse_args()

    print("=" * 68)
    print(f"Coherence Analysis v2 ({a.data_dir.split('/')[-1]})")
    print(f"fs={a.hz}Hz, nperseg={a.nperseg}, IAAFT n_surr={a.n_surr}")
    print("=" * 68)

    fp = os.path.join(a.repo, a.data_dir, a.file)
    with open(fp, "rb") as f:
        head = f.read(200)
    if head.startswith(b"version https://git-lfs"):
        print("[ERR] LFS pointer not downloaded"); sys.exit(1)
    
    t0 = time.time()
    try:
        with open(fp, "rb") as f:
            X, y = pickle.load(f)
    except Exception:
        traceback.print_exc(); sys.exit(1)
    X, y = to_np(X), to_np(y)
    print(f"[OK] Loaded ({time.time()-t0:.1f}s) X{X.shape} y{y.shape}")
    N, C, T = X.shape
    half = C // 2
    print(f"  N={N} dyadic {half}-channel T={T} ({T/a.hz:.1f}s)")

    labels = y[:, 0].astype(int)
    dyads = y[:, 1].astype(int)
    song_l = y[:, 3].astype(int)
    song_r = y[:, 4].astype(int)
    sym = (song_l == song_r).astype(int)
    print(f"  label: {dict(zip(*[x.tolist() for x in np.unique(labels, return_counts=True)]))}")
    print(f"  same-song: {sym.sum()}, different-song: {(~sym.astype(bool)).sum()}")

    # ---- 计算每窗口相干谱 ----
    print(f"\n[INFO] Computing {N} windows × {half} channels coherence...")
    A_all, B_all = X[:, :half, :], X[:, half:2*half, :]

    def _one(wi):
        return mean_coherence(A_all[wi].T, B_all[wi].T, a.hz, a.nperseg)

    try:
        from joblib import Parallel, delayed
        results = Parallel(n_jobs=-1)(delayed(_one)(wi) for wi in range(N))
    except ImportError:
        results = [_one(wi) for wi in range(N)]

    freqs = results[0][0]
    if freqs is None:
        print("[ERR] All coherence failed"); sys.exit(1)
    spectra = np.array([r[1] for r in results if r[1] is not None])
    print(f"  Done ({time.time()-t0:.1f}s), valid {len(spectra)}/{N}, freq bins {len(freqs)}")

    # ---- 频段积分 ----
    band_vals = {name: np.array([band_integrate(freqs, s, lo, hi) for s in spectra])
                 for name, (lo, hi) in BANDS.items()}

    # ---- IAAFT surrogate thresholds (全局) ----
    print(f"\n[INFO] Computing IAAFT surrogate thresholds (n={a.n_surr})...")
    # 用所有窗口的平均信号做 surrogate (更快且稳定)
    A_mean = A_all.mean(axis=0).T  # (T, half)
    B_mean = B_all.mean(axis=0).T
    thresholds = iaaft_surrogate_coherence(A_mean, B_mean, a.hz, a.nperseg, n_surr=a.n_surr)
    print(f"  IAAFT 95th %ile thresholds:")
    for name, th in thresholds.items():
        print(f"    {name}: {th:.4f}")

    # ---- 全局频段分布 ----
    print(f"\n== Global band coherence ==")
    print(f"  {'Band':<15} {'Mean':>8} {'Median':>8} {'SD':>8} {'Surr 95th':>10} {'Exceeds?':>8}")
    order = sorted(BANDS.items(), key=lambda x: -band_vals[x[0]].mean())
    for name, _ in order:
        v = band_vals[name]
        th = thresholds[name]
        exceeds = "YES" if v.mean() > th else "NO"
        star = " ★" if name == order[0][0] else ""
        print(f"  {name:<15} {v.mean():>8.4f} {np.median(v):>8.4f} {v.std():>8.4f} {th:>10.4f} {exceeds:>8}{star}")

    # Friedman test (window-level, exploratory)
    if len(spectra) >= 10:
        try:
            from scipy.stats import friedmanchisquare
            fr, p = friedmanchisquare(*[band_vals[n] for n in BANDS])
            print(f"  Friedman (window-level): χ²={fr:.2f}, p={p:.4f}")
        except Exception as e:
            print(f"  Friedman failed: {e}")

    # ---- 保存 CSV (含 dyad, label, same_song, band columns) ----
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    hdr = "window,label,dyad,same_song," + ",".join(BANDS.keys()) + ",nperseg"
    out = [hdr]
    for k in range(len(spectra)):
        row = f"{k},{int(labels[k])},{int(dyads[k])},{int(sym[k])}"
        for name in BANDS:
            row += f",{band_vals[name][k]:.4f}"
        row += f",{a.nperseg}"
        out.append(row)
    with open(a.out, "w") as f:
        f.write("\n".join(out))
    print(f"\n[DONE] Saved: {a.out}")
    print(f"  Columns: window, label, dyad, same_song, low, rhythm, fast, nperseg")
    print(f"  Forward this output to 虎博 for manuscript insertion.")


if __name__ == "__main__":
    main()
