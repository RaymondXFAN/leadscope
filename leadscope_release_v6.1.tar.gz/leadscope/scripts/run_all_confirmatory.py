#!/usr/bin/env python3
"""
run_all_confirmatory.py — 一键运行全部确认性统计实验

运行顺序:
  1. sw_sensitivity_v2.py     → sw_sensitivity.csv (§4.3 多窗长敏感性)
  2. song_influence_lag.py    → song_influence.csv (§4.4 same vs diff music)
  3. sw_subwindow_lag.py      → subwindow_lag.csv (§4.7/4.8 子窗级时滞)
  4. coherence_analysis_v2.py → coherence_both.csv (§4.5/4.6 both_cond)
  5. coherence_analysis_v2.py → coherence_vis.csv  (§4.6 vis_only cross-val)
  6. dyad_aggregate_stats_v2.py → 完整确认性统计报告

用法:
  cd /root/autodl-tmp/leadscope
  python scripts/run_all_confirmatory.py

输出:
  results/sw_sensitivity.csv
  results/song_influence.csv
  results/subwindow_lag.csv
  results/coherence_both.csv
  results/coherence_vis.csv
  (以及 stdout 中的完整统计报告, 复制粘贴进论文)
"""

import os
import subprocess
import sys

RESULTS_DIR = "/root/autodl-tmp/leadscope/results"
os.makedirs(RESULTS_DIR, exist_ok=True)

SCRIPTS = [
    ("§4.3 Sliding-window sensitivity (25/50/100 frames)",
     "python scripts/sw_sensitivity_v2.py"),
    ("§4.4 Song influence (same vs different music)",
     "python scripts/song_influence_lag.py"),
    ("§4.7/4.8 Sliding-window lag (sub-window level)",
     "python scripts/sw_subwindow_lag.py"),
    ("§4.5/4.6 Coherence both_cond (nperseg=32, IAAFT)",
     "python scripts/coherence_analysis_v2.py --out results/coherence_both.csv"),
    ("§4.6 Coherence vis_only (nperseg=32, IAAFT)",
     "python scripts/coherence_analysis_v2.py --data-dir dyadic_dance/data/vis_only --out results/coherence_vis.csv"),
    ("§4.9 Dyad-level confirmatory stats",
     "python scripts/dyad_aggregate_stats_v2.py --results-dir results"),
]


def run_step(title, cmd):
    print("\n" + "=" * 68)
    print(f"STEP: {title}")
    print(f"CMD:  {cmd}")
    print("=" * 68)
    ret = subprocess.call(cmd, shell=True)
    if ret != 0:
        print(f"[WARN] Step returned non-zero exit code: {ret}")
        print(f"[WARN] Continuing to next step...")
    return ret


def main():
    print("# LeadScope Confirmatory Experiment Pipeline")
    print(f"Results directory: {RESULTS_DIR}")
    
    for title, cmd in SCRIPTS:
        run_step(title, cmd)
    
    print("\n" + "=" * 68)
    print("ALL STEPS COMPLETE")
    print("=" * 68)
    print(f"\nOutput files in {RESULTS_DIR}:")
    for f in sorted(os.listdir(RESULTS_DIR)):
        if f.endswith(".csv"):
            print(f"  - {f}")
    print(f"\nNext steps:")
    print(f"  1. Copy the stdout from the last step (dyad_aggregate_stats_v2.py)")
    print(f"  2. Paste into manuscript §4.x tables")
    print(f"  3. Copy sw_sensitivity.csv values into §4.3 Table 3")
    print(f"  4. Copy coherence_both.csv IAAFT thresholds into §4.5 Table 4")


if __name__ == "__main__":
    main()
