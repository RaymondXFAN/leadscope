#!/usr/bin/env python3
"""
sw_sensitivity_v2.py — §4.3 滑窗敏感性分析 (多窗长)

跑 25/50/100 帧三种子窗长, 计算:
  - |τ| mean, IQR
  - dominant peak proportion (显著子段中 |τ|<500ms 的比例)
  - peak r stability (跨子段 peak_r 的 SD)

用法:
  cd /root/autodl-tmp/leadscope
  python scripts/sw_sensitivity_v2.py
"""

import argparse
import os
import pickle
import sys
import time
import traceback

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from lagcc import lagged_cross_corr

REPO = "/root/autodl-tmp/Dyadic-dance-coordination"


def to_np(t):
    if hasattr(t, "detach"):
        t = t.detach().cpu().numpy()
    return np.asarray(t)


def prep_signal(seg, mode="energy"):
    s = np.asarray(seg, dtype=np.float64)
    if mode == "energy":
        return np.sqrt((s ** 2).sum(axis=1, keepdims=True))
    if mode == "raw":
        return s
    raise ValueError(mode)


def refine_parabola(curve, lags):
    i = int(np.nanargmax(curve))
    if i <= 0 or i >= len(curve) - 1:
        return float(lags[i])
    y0, y1, y2 = curve[i - 1], curve[i], curve[i + 1]
    denom = y0 - 2 * y1 + y2
    if abs(denom) < 1e-12:
        return float(lags[i])
    delta = 0.5 * (y0 - y2) / denom
    if not np.isfinite(delta) or abs(delta) > 1:
        return float(lags[i])
    return float(lags[i] + delta)


def estimate_one(A, B, max_lag, mode="energy"):
    a, b = prep_signal(A, mode), prep_signal(B, mode)
    n = min(a.shape[0], b.shape[0])
    a, b = a[:n], b[:n]
    curves = []
    for d in range(a.shape[1]):
        try:
            _, c, _ = lagged_cross_corr(a[:, d], b[:, d], max_lag)
            curves.append(c)
        except ValueError:
            continue
    if not curves:
        return 0.0, 0.0
    curve = np.nanmean(np.vstack(curves), axis=0)
    lags = np.arange(-max_lag, max_lag + 1)
    return refine_parabola(curve, lags), float(np.nanmax(curve))


def analyze_window_length(X, y, sub_window, max_lag, hz, mode="energy"):
    """分析给定子窗长的滞后分布和稳定性。"""
    N, C, T = X.shape
    half = C // 2
    n_sub = T // sub_window
    ms = 1000.0 / hz
    
    A_all, B_all = X[:, :half, :], X[:, half:2*half, :]
    
    # 收集所有子段结果
    all_lags = []
    all_peaks = []
    all_widx = []
    
    for wi in range(N):
        for si in range(n_sub):
            s, e = si * sub_window, (si + 1) * sub_window
            lag, peak = estimate_one(A_all[wi, :, s:e].T, B_all[wi, :, s:e].T, max_lag, mode)
            all_lags.append(lag * ms)
            all_peaks.append(peak)
            all_widx.append(wi)
    
    all_lags = np.array(all_lags)
    all_peaks = np.array(all_peaks)
    all_widx = np.array(all_widx)
    
    # 基本统计
    abs_tau = np.abs(all_lags)
    mean_tau = np.mean(abs_tau)
    iqr = np.percentile(abs_tau, 75) - np.percentile(abs_tau, 25)
    
    # dominant peak: |τ| < 500ms 的比例 (合理人类 leader-follower 范围)
    dominant_prop = np.mean(abs_tau < 500)
    
    # peak r stability: 跨子段 peak_r 的 SD
    peak_r_sd = np.std(all_peaks)
    
    # 每窗口 peak_r 的 SD (更细粒度稳定性)
    window_peak_sd = []
    for wi in range(N):
        m = all_widx == wi
        if m.sum() > 1:
            window_peak_sd.append(np.std(all_peaks[m]))
    mean_window_peak_sd = np.mean(window_peak_sd) if window_peak_sd else np.nan
    
    return {
        "sub_window": sub_window,
        "sub_sec": sub_window / hz,
        "n_sub": n_sub,
        "n_total": len(all_lags),
        "mean_abs_tau_ms": mean_tau,
        "median_abs_tau_ms": np.median(abs_tau),
        "iqr_ms": iqr,
        "dominant_peak_prop": dominant_prop,
        "peak_r_sd": peak_r_sd,
        "mean_window_peak_sd": mean_window_peak_sd,
    }


def main():
    ap = argparse.ArgumentParser(description="Sliding-window sensitivity (multi-length)")
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--data-dir", default="dyadic_dance/data/both_cond_only")
    ap.add_argument("--file", default="raw_velocities_ds.pkl")
    ap.add_argument("--hz", type=float, default=5.0)
    ap.add_argument("--max-lag", type=int, default=5)
    ap.add_argument("--mode", default="energy")
    ap.add_argument("--out", default="/root/autodl-tmp/leadscope/results/sw_sensitivity.csv")
    a = ap.parse_args()

    print("=" * 68)
    print("Sliding-Window Sensitivity Analysis (Multi-Length)")
    print("=" * 68)

    fp = os.path.join(a.repo, a.data_dir, a.file)
    with open(fp, "rb") as f:
        head = f.read(200)
    if head.startswith(b"version https://git-lfs"):
        print("[ERR] LFS pointer not downloaded"); sys.exit(1)
    
    t0 = time.time()
    try:
        with open(fp, "rb") as f:
            X, y = pickle.load(f)
    except Exception:
        traceback.print_exc(); sys.exit(1)
    X, y = to_np(X), to_np(y)
    print(f"[OK] Loaded ({time.time()-t0:.1f}s) X{X.shape}")

    # 分析三种窗长
    window_lengths = [25, 50, 100]
    results = []
    
    for wl in window_lengths:
        print(f"\n[INFO] Analyzing sub-window = {wl} frames ({wl/a.hz:.1f}s)...")
        t1 = time.time()
        res = analyze_window_length(X, y, wl, a.max_lag, a.hz, a.mode)
        results.append(res)
        print(f"  Done ({time.time()-t1:.1f}s)")
    
    # 打印表格
    print(f"\n{'=' * 68}")
    print("RESULTS: Table 3 — Sub-window length sensitivity")
    print(f"{'=' * 68}")
    print(f"{'Window':<12} {'|τ| mean':<12} {'|τ| IQR':<12} {'Dominant':<12} {'peak r SD':<12}")
    print(f"{'(frames)':<12} {'(ms)':<12} {'(ms)':<12} {'peak prop':<12} {'(stability)':<12}")
    print("-" * 68)
    for r in results:
        print(f"{r['sub_window']:<12} {r['mean_abs_tau_ms']:<12.1f} {r['iqr_ms']:<12.1f} "
              f"{r['dominant_peak_prop']:<12.3f} {r['peak_r_sd']:<12.4f}")
    
    # 保存 CSV
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    hdr = "sub_window,sub_sec,n_sub,n_total,mean_abs_tau_ms,median_abs_tau_ms,iqr_ms,dominant_peak_prop,peak_r_sd,mean_window_peak_sd"
    out = [hdr]
    for r in results:
        out.append(f"{r['sub_window']},{r['sub_sec']:.1f},{r['n_sub']},{r['n_total']},"
                   f"{r['mean_abs_tau_ms']:.4f},{r['median_abs_tau_ms']:.4f},{r['iqr_ms']:.4f},"
                   f"{r['dominant_peak_prop']:.4f},{r['peak_r_sd']:.4f},{r['mean_window_peak_sd']:.4f}")
    with open(a.out, "w") as f:
        f.write("\n".join(out))
    print(f"\n[DONE] Saved: {a.out}")
    print("  Forward this output to 虎博 for §4.3 Table 3.")


if __name__ == "__main__":
    main()
